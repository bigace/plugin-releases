<?php
$LANG['written_at'] = 'Written at';
$LANG['design_by'] = 'by';
$LANG['powered_by'] = 'Powered by';
$LANG['login'] = 'Login';
$LANG['logout'] = 'Logout';
$LANG['admin'] = 'Administration';
$LANG['search'] = 'Search';
$LANG['search_empty'] = 'Your searchterm is empty, please enter at least 4 character!';
$LANG['search_short'] = 'Your searchterm is to short, please enter at least 4 character!';
?>