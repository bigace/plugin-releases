<?php
require_once(realpath(dirname(__FILE__).'/../../../system/libs/').'/init_session.inc.php');
//echo realpath(dirname(__FILE__).'/../../../system/libs/').'/init_session.inc.php';

import('classes.util.LinkHelper');
import('classes.util.links.MenuChooserLink');
import('classes.util.links.ImageChooserLink');

$imageLink = new ImageChooserLink();

$menulinkDialogLink = new MenuChooserLink();
$menulinkDialogLink->setCommand('application');
$menulinkDialogLink->setAction('util');
$menulinkDialogLink->setSubAction('jstree');
$menulinkDialogLink->setJavascriptCallback('setCmsUrl');
?>

FCKConfig.ToolbarSets["News"] = [
	['Preview',],
	['Cut','Copy','Paste','PasteText','PasteWord',],
	['Undo','Redo','-','Find','Replace','-','SelectAll','RemoveFormat'],
	'/',
	['Bold','Italic','Underline','StrikeThrough','-','Subscript','Superscript'],
	['Link','Unlink','Anchor'],
	['Image','Flash','Table','SpecialChar'],
	['Style','FontFormat']
] ;

function setCmsUrl(id,language,name) {
<?php
$tempLink = new CMSLink();
$tempLink->setCommand(_BIGACE_CMD_MENU);
$tempLink->setItemID('"+id+"');
$tempLink->setLanguageID('"+language+"');
echo '   SetUrl("'.LinkHelper::getUrlFromCMSLink($tempLink).'");  ';
?>

}

FCKConfig.FlashBrowser = false ;

FCKConfig.ImageBrowser = true ;
FCKConfig.ImageBrowserURL = '<?php echo LinkHelper::getUrlFromCMSLink($imageLink); ?>';
FCKConfig.ImageBrowserWindowWidth  = 760;
FCKConfig.ImageBrowserWindowHeight = 450;

FCKConfig.LinkBrowser = true ;
//FCKConfig.LinkBrowserURL = '<?php echo LinkHelper::getUrlFromCMSLink($menulinkDialogLink, array('w'=>'s')); ?>';
//FCKConfig.LinkBrowserWindowWidth    = '400' ;  // 70%
FCKConfig.LinkBrowserURL = FCKConfig.BasePath + 'filemanager/browser/bigace/browser.php?Connector=connectors/php/connector.php' ;
FCKConfig.LinkBrowserWindowWidth    = screen.width * 0.5 ;  // 70%
FCKConfig.LinkBrowserWindowHeight   = screen.height * 0.5 ; // 70%

FCKConfig.ImageUpload = false ;
FCKConfig.LinkUpload = false ;
FCKConfig.FlashUpload = false ;

FCKConfig.SpellChecker			= 'ieSpell' ;	// 'ieSpell' | 'SpellerPages'