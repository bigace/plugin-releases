<?php

require_once(dirname(__FILE__).'/../../system/libs/init_session.inc.php');

// load required smarty classes
import('classes.smarty.BigaceSmarty');
import('classes.smarty.SmartyTemplate');

// the template we use to render the rss feed
$tpl = ConfigurationReader::getConfigurationValue('news', 'rss.latest.template', 'News-RSS-Latest.tpl');
$SMARTY_TPL = new SmartyTemplate($tpl); 

// initialize smarty and siplay the feed
$smarty = BigaceSmarty::getSmarty();
$smarty->display($SMARTY_TPL->getFilename());

?>