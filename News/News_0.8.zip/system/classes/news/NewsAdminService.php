<?php
/**
 * BIGACE - a PHP and MySQL based Web CMS.
 * Copyright (C) Kevin Papst.
 *
 * BIGACE is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * BIGACE is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software Foundation,
 * Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 *
 * For further information visit {@link http://www.bigace.de http://www.bigace.de}.
 *
 * @package bigace.classes
 * @subpackage menu
 */

import('classes.menu.MenuAdminService');
import('classes.category.CategoryAdminService');

/**
 * Class used for administrating "News" entrys.
 *
 * @license http://opensource.org/licenses/gpl-license.php GNU Public License
 * @author Kevin Papst 
 * @copyright Copyright (C) Kevin Papst
 * @version $Id: NewsAdminService.php,v 1.1 2008/02/12 19:47:43 kpapst Exp $
 * @package bigace.classes
 * @subpackage news
 */
class NewsAdminService extends MenuAdminService
{

    /**
    * Instantiates a NewsAdminService.
    */
    function NewsAdminService()
    {
        $this->MenuAdminService();
    }
    
    /**
     * @access private
     */
    function prepareNewsDataArray($language, $title, $teaser, $metatags, $content, $imageID = null) {
    	return array(
    		'langid'		=> $language,
    		'template'		=> ConfigurationReader::getConfigurationValue("news", "template.news"),
    		'name'			=> $title,
    		'description'	=> $teaser,
    		'catchwords'	=> $metatags,
    		'content'		=> $content,
    		'num_1'			=> $imageID,
    		'num_3'			=> FLAG_NORMAL,
    		'parentid'		=> ConfigurationReader::getConfigurationValue("news", "root.id"),
    		'module'		=> 'displayContent'
    	);
    }

    /**
     * Deletes a News entry with the given ID and Language.
     *
     * @param int the News ID
     * @param String the Language locale
     */
    function deleteNews($id, $language) 
    {
    	return $this->deleteItemLanguage($id, $language);
    }
    
    /**
     * Updates a News entry with the given values.
     *
     * @return true on success, false on error
     */
    function updateNews($id, $language, $title, $teaser, $metatags, $content, $categories = array(), $imageID = null)
    {
    	$data = $this->prepareNewsDataArray($language, $title, $teaser, $metatags, $content, $imageID);
    	$this->updateItemContent($id, $language, $content, $data);

		// create all category links new 
    	$this->removeAllCategoryLinks($id);
    	
		// create all category links new 
        if(count($categories) > 0) 
    	{
	    	$cs = new CategoryAdminService();
	    	foreach($categories AS $catID) {
	    		$cs->createCategoryLink(_BIGACE_ITEM_MENU, $id, $catID);
	    	}
    	}
    	
    }
    
	/**
     * Creates a News entry with the given values.
     *
     * @return the new News ID or FALSE
     */
    function createNews($language, $title, $teaser, $metatags, $content, $categories = array(), $imageID = null)
    {
    	$data = $this->prepareNewsDataArray($language, $title, $teaser, $metatags, $content, $imageID);
    	
    	$id = $this->createMenu($data);
    	
    	if($id === FALSE) {
    		return false;
    	}
    	
    	if(count($categories) > 0) 
    	{
	    	$cs = new CategoryAdminService();
	    	foreach($categories AS $catID) {
	    		$cs->createCategoryLink(_BIGACE_ITEM_MENU, $id, $catID);
	    	}
    	}
    }


}

?>