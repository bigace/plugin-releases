<?php

import('classes.category.ItemCategoryEnumeration');

/*
 * Smarty plugin
 * -------------------------------------------------------------
 * File:     function.news_category.php
 * Type:     function
 * Name:     news_category
 * Purpose:  Returns the News categories, this Item is linked to.
 * -------------------------------------------------------------
 * - id
 * - item 
 * - assign
 */
function smarty_function_news_category($params, &$smarty)
{
	if(!isset($params['id']) && !isset($params['item'])) {
		$smarty->trigger_error("news_category: missing 'id' AND 'item' attribute");
		return;
	}

	if(!isset($params['assign'])) {
		$smarty->trigger_error("news_category: missing 'assign' attribute");
		return;
	}
	
	// one of ID and item must be set!
	$id = isset($params['id']) ? $params['id'] : $params['item']->getID();
	$rootCat = ConfigurationReader::getConfigurationValue("news", "category.id");
	
	$ice = new ItemCategoryEnumeration(_BIGACE_ITEM_MENU, $id);
	
	$cats = array();
	
	while($ice->hasNext()) {
		$t = $ice->next();
		if($t->getParentID() == $rootCat)
			$cats[] = $t;
	}

	$smarty->assign($params['assign'], $cats);
	
	return;
}

?> 