<?php

import('classes.category.CategoryTreeWalker');

/*
 * Smarty plugin
 * -------------------------------------------------------------
 * File:     function.news_categories.php
 * Type:     function
 * Name:     news_categories
 * Purpose:  Returns all available News categories   
 * -------------------------------------------------------------
 * Parameter:
 * - assign (optional)
 */
function smarty_function_news_categories($params, &$smarty)
{
	$entries = array();
	
	$catWalk = new CategoryTreeWalker( ConfigurationReader::getConfigurationValue("news", "category.id") );
	
	for($i=0; $i < $catWalk->count(); $i++)
		$entries[] = $catWalk->next();
	
	if(isset($params['assign'])) {
		$smarty->assign($params['assign'], $entries);
		return;
	}
	
	return $entries;
}

?> 