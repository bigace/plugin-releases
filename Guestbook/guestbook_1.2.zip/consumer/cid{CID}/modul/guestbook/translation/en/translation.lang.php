<?php
/**
* Translation file for Modul - Guestbook
*
* Language: english
* Locale:   en
*
* Copyright (C) Kevin Papst. 
*
* For further information go to http://www.bigace.de/ 
*
* @version $Id: translation.lang.php,v 1.6 2007/04/19 15:07:53 kpapst Exp $
* @author Kevin Papst 
* @package bigace.translation
*/

$LANG['gb_admin']         	  = 'Settings';
$LANG['gb_impressum']         = 'Email adress and Homepage are optional values and can be left empty. It is prohibited, to use posted Data for any commercial reason (like Spam). The Webmaster is not responsible for the Content of the posted Comments.';
$LANG['gb_save']              = 'Save';
$LANG['gb_homepage']          = 'Homepage';
$LANG['gb_comment']           = 'Comment';
$LANG['gb_email']             = 'eMail';
$LANG['gb_name']              = 'Name';
$LANG['gb_new_link']          = 'Your Guestbook entry';
$LANG['gb_wrote']             = 'wrote on';
$LANG['gb_create_entry']      = 'Create a new Guestbook entry here';
$LANG['gb_page']              = 'Page';
$LANG['gb_hp_link_alt']       = 'Link to Website';
$LANG['gb_captcha']           = 'Captcha';
$LANG['gb_captcha_info']      = 'Please enter the signs from the Image into the Textfield:';
$LANG['gb_captcha_alt']       = 'This is a captcha-picture. It is used to prevent mass-access by robots.';

$LANG['gb_captcha_failed']    = 'Your captcha verification failed, please try again.';
$LANG['gb_blackword']         = 'You entered a blocked Word, please correct you Message! The blocked phrase is:';
$LANG['gb_msg_enter_values']  = 'You have to enter at least a Name and Comment!';

?>