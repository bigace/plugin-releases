<?php
/**
* Translation file for Administration - Categorys
*
* Language: deutsch (default)
* Locale:   de
*
* Copyright (C) 2002-2006 Kevin Papst. 
*
* For further information go to http://www.bigace.de/ 
*
* @version $Id: guestbook.lang.php,v 1.3 2006/11/26 21:58:56 kpapst Exp $
* @author Kevin Papst 
* @package bigace.translation
*/

$LANG['menu_guestbook']   		= 'G&auml;stebuch';
$LANG['title_guestbook']        = 'G&auml;stebuch';
$LANG['description_guestbook']  = 'Hier k&ouml;nnen Sie die Eintr&auml;ge in Ihrem G&auml;stebuch bearbeiten.';

$LANG['gb_delete_entry']      	= 'Eintrag entfernen';
$LANG['gb_edit_entry']        	= 'Eintrag bearbeiten';

$LANG['gbUser']            		= 'Autor Name';
$LANG['gbHomepage']            	= 'Link';
$LANG['gbEmail']            	= 'Email';
$LANG['gbDate']            		= '&Auml;nderungsdatum';
$LANG['gbEntry']            	= 'Eintrag';

$LANG['gbEdit']            		= '&Auml;ndern';
$LANG['gbSave']            		= 'Speichern';
$LANG['gbDelete']            	= 'L&ouml;schen';

?>