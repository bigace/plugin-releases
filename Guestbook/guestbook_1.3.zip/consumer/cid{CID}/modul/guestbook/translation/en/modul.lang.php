<?php
/**
* Translation file for Modul - Guestbook
*
* Language: english
* Locale:   en
*
* Copyright (C) Kevin Papst. 
*
* For further information go to http://www.bigace.de/ 
*
* @version $Id: modul.lang.php,v 1.3 2006/11/26 21:58:50 kpapst Exp $
* @author Kevin Papst 
* @package bigace.translation
*/

$LANG['name']    		= 'Guestbook';
$LANG['title']    		= 'Guestbook';
$LANG['description']  	= 'Displays a Guestbook where anonymous User may post Comments.';

?>