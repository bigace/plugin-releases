INSERT INTO 
	{DB_PREFIX}gaestebuch (cid, name, email, homepage, eintrag, timestamp) 
	VALUES ({CID}, {NAME}, {EMAIL}, {HOMEPAGE}, {COMMENT}, {TIMESTAMP})

