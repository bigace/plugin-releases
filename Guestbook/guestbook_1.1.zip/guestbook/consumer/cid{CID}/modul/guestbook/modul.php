<?php
/**
* The BIGACE Guestbook
*
* This script needs some CSS classes!
*
* #guestbook .gbheader { margin-bottom:10px;padding-bottom:10px;border-bottom:2px solid #999999; }
* #guestbook .pagelink { margin:6px;padding:2px 5px 2px 0px;border:1px solid #000000;background-color:#F6F6F6; }
* #guestbook .pagelinkSelected { margin:6px;padding:2px 5px 2px 0px;border:1px solid #000000;color:#000000;background-color:#ffffff; }
* #guestbook .imglink { padding-right:5px; }
* #guestbook .gbpages { margin:20px 0px 10px 0px;text-align:center; }
* #guestbook .gbEntry { width:500px;border:1px solid #C6C6CC;background-color:#F6F6F6;padding:5px;margin-bottom:10px }
* #guestbook .gbEntryTitle { font-weight:bold;margin-top:0px; }
* #guestbook .gbEntryComment { margin-bottom:0px; }
*
* Copyright (C) Kevin Papst. 
*
* For further information go to http://www.kevinpapst.de/ 
* or contact bigace@kevinpapst.de.
*
* @version $Id: modul.php,v 1.2 2006/04/09 18:58:48 kpapst Exp $
* @author Kevin Papst <bigace@kevinpapst.de>
* @package bigace.modul
*/

loadClass('guestbook','Guestbook');
loadClass('guestbook','GuestbookEnumeration');
loadClass('guestbook','GuestbookAdminService');
require_once ($_BIGACE['DIR']['libs'].'htmlhelper.inc.php');

// some configuration values for the guestbook
define('GUESTBOOK_SHOW_LINKS_TOP',      true);
define('GUESTBOOK_SHOW_LINKS_BOTTOM',   false);
define('GUESTBOOK_USE_INNER_CSS',       true);
define('GUESTBOOK_PAGE_ENTRY_LIMIT',    5);
define('GUESTBOOK_PUBLIC_DIR',          $GLOBALS['_BIGACE']['DIR']['public'] . 'modul/guestbook/');
// -------------------------------------------

define('GUESTBOOK_MODE_CREATE',         'createEntry');
$mode = extractVar('mode', 'view');
$data = extractVar('data', array());


if (GUESTBOOK_USE_INNER_CSS)
{
    ?>
    <link rel="stylesheet" href="<?php echo GUESTBOOK_PUBLIC_DIR; ?>example.css" type="text/css">
    <?php
}

if ($mode == GUESTBOOK_MODE_CREATE) 
{
    /** 
    * Create new entry with posted data
    */
    $gb_admin = new GuestbookAdminService();
    $error = FALSE;

    if (isset($data['name']) && $data['name'] != '' && isset($data['comment']) && $data['comment'] != '') {
        $res = $gb_admin->createEntry($data['name'], $data['email'], $data['hp'], $data['comment']);
        viewEntrys( extractVar('start', '0') );
    } else {
        $error = TRUE;
    }

    if ($error)
    {
        echo '<br><br><p align="center">'.getTranslation('gb_msg_enter_values').'</p>' . editEntry($data);
    } 

    unset ($res);
    unset ($error);
    unset ($gb_admin);
}
else if ($mode == "new") 
{
    echo editEntry($data);
} 
else if ($mode == "view")
{
    viewEntrys( extractVar('start', '0') );
}
else 
{
    viewEntrys( '0' );
}

unset ( $mode );
unset ( $data );



/**
* Shows all Entrys
*/
function viewEntrys($from) 
{
    $gb_info = new GuestbookEnumeration($from,GUESTBOOK_PAGE_ENTRY_LIMIT);
    $entries = $gb_info->countEntrys();

    ?>
    <div id="guestbook">
        <div class="gbheader">
            <p class="gbimpressum">
                <img src="<?php echo GUESTBOOK_PUBLIC_DIR . 'title.gif'; ?>" align="left" style="margin-right:10px;" alt="">
                <?php echo getTranslation('gb_impressum'); ?>
            </p>
            <p align="right">
            <?php
            echo '<a href="'.createMenuLink($GLOBALS['_BIGACE']['PARSER']->getItemID(), array('mode'=>'new')).'" title="'.getTranslation('gb_new_link').'">';
            echo '<img src="'.GUESTBOOK_PUBLIC_DIR.'create.gif" style="margin-right:5px;" alt="">';
            echo getTranslation('gb_new_link');
            ?>
            </a>
            </p>
        </div>
        <?php
        if (GUESTBOOK_SHOW_LINKS_TOP || GUESTBOOK_SHOW_LINKS_BOTTOM)
        {
            $bla = $gb_info->countAllEntrys();
            $iitemp = $bla[0] / GUESTBOOK_PAGE_ENTRY_LIMIT;
            $links = '';
            if ($iitemp > 1 ) {
                for ($i=0; $i < $iitemp; $i++) 
                {
                    $links .= '<a href="'.createMenuLink( $GLOBALS['MENU']->getID(), array('start' => $i*GUESTBOOK_PAGE_ENTRY_LIMIT) ).'" title="" class="';
                    if ($i+1 > ($from / GUESTBOOK_PAGE_ENTRY_LIMIT) && $i < ($from / GUESTBOOK_PAGE_ENTRY_LIMIT)+1) {
                       $links .= 'pagelinkSelected';
                    } else {
                       $links .= 'pagelink';
                    }
                    
                    $links .= '"><img src="'.GUESTBOOK_PUBLIC_DIR.'arrow.gif" class="imglink" alt="'.getTranslation('gb_page').' '.($i+1).'">'.getTranslation('gb_page').' '.($i+1).'</a>';
                }
            }
            
            if (GUESTBOOK_SHOW_LINKS_TOP)
            {
                ?>
                <div class="gbpages">
                <p><?php echo $links; ?></p>
                </div>
                <?php
            }
        }
    
        for ($i = 0; $i < $entries; $i++) 
        {
            $current_gb = $gb_info->getNextEntry();
            
            $name = $current_gb->getName();
            if ($current_gb->getEmail() != "") {
                if ($name != "" && $name != "@") {
                    $name = '<a href="mailto:'.$current_gb->getEmail().'" title="">'.$name.'</a>';
                }
            }
    
            ?>
    
            <div class="gbEntry">
                <p class="gbEntryTitle">
                    <?php 
                    if ($current_gb->getHomepage() != "" && $current_gb->getHomepage() != "http://") {
                         echo '<a href="'.$current_gb->getHomepage().'" target="_blank" title="'.$current_gb->getHomepage().'"><img src="'.GUESTBOOK_PUBLIC_DIR.'home.gif" alt="'.getTranslation('gb_hp_link_alt').'"></a>';
                    }
                    echo ' ' . $name . ' ' . getTranslation('gb_wrote') . ' ' . date("d.m.Y", $current_gb->getEntryDate()); 
                    ?> 
                </p>
                <p class="gbEntryComment">
                    <?php echo str_replace("\n", "<br>", $current_gb->getComment()); ?>
                </p>
            </div>
    
            <?php
        }
        
        if(GUESTBOOK_SHOW_LINKS_BOTTOM)
        {
        ?>
        <div class="gbpages">
        <p><?php echo $links; ?></p>
        </div>
        <?php
        }
        ?>

    </div>
    <?php
}


/**
* Edit new Guestbook Entry
*/
function editEntry($data)
{
    if ( !isset($data['name']) )    { $data['name'] = ''; }
    if ( !isset($data['hp']) )      { $data['hp'] = 'http://'; }
    if ( !isset($data['email']) )   { $data['email'] = ''; }
    if ( !isset($data['comment']) ) { $data['comment'] = ''; }
    if ( !isset($data['title']) )   { $data['title'] = getTranslation('gb_create_entry'); }
    if ( !isset($data['gbid']) )    { $data['gbid'] = ''; }
    if ( !isset($data['mode']) )    { $data['mode'] = GUESTBOOK_MODE_CREATE; }
    if ( !isset($data['submit']) )  { $data['submit'] = getTranslation('gb_save'); }

    $config = array(
                    'width'         =>  '350',
                    'align'         =>  array (
                                            'table'     =>  'center',
                                            'left'      =>  'left'
                                        ),
                    'image'         =>  GUESTBOOK_PUBLIC_DIR . 'create.gif',
                    'title'         =>  $data['title'],
                    'form_action'   =>  createMenuLink($GLOBALS['MENU']->getID()),
                    'form_method'   =>  'post',
                    'form_hidden'   =>  array(
                                            'mode'              =>  $data['mode'],
                                            'data[gbid]'        =>  $data['gbid']
                                    ),
                    'entries'       =>  array(
                                            getTranslation('gb_name')          => createTextInputType('name', $data['name'], '255'),
                                            getTranslation('gb_email')         => createTextInputType('email', $data['email'], '255'),
                                            getTranslation('gb_homepage')    => createTextInputType('hp', $data['hp'], '255'),
                                            getTranslation('gb_comment')     => createTextArea('comment',$data['comment'],'10','40')
                                    ),
                    'form_submit'   =>  true,
                    'submit_label'  =>  $data['submit']
    );
    unset($data);
    return createTable($config);
}

?>