<?php
/**
* Translation file for Modul - Guestbook
*
* Language: deutsch (default)
* Locale:   de
*
* Copyright (C) Kevin Papst. 
*
* For further information go to http://www.kevinpapst.de/ 
* or contact bigace@kevinpapst.de.
*
* @version $Id: modul.lang.php,v 1.1 2006/04/06 21:50:08 kpapst Exp $
* @author Kevin Papst <bigace@kevinpapst.de>
* @package bigace.translation
*/

$LANG['modul_name_guestbook']    		= 'G�stebuch';
$LANG['modul_title_guestbook']    		= 'G�stebuch';
$LANG['modul_description_guestbook']  	= 'Hier k�nnen Sie einen Nachricht in unserem G�stebuch hinterlassen.';

?>