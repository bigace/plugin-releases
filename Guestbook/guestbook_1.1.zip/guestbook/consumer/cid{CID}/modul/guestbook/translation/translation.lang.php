<?php
/**
* Translation file for Modul - Guestbook
*
* Language: deutsch (default)
* Locale:   de
*
* Copyright (C) Kevin Papst. 
*
* For further information go to http://www.kevinpapst.de/ 
* or contact bigace@kevinpapst.de.
*
* @version $Id: translation.lang.php,v 1.1 2006/04/06 21:50:08 kpapst Exp $
* @author Kevin Papst <bigace@kevinpapst.de>
* @package bigace.translation
*/

$LANG['gb_impressum']         = 'Anmerkung (Haftungsausschlu�): Die Angabe von E-Mail Adresse und Homepage ist freiwillig. Es ist untersagt angegebene Daten f�r Werbe-eMails zu missbrauchen. Alle Eintragungen spiegeln die Beitr�ge der G�ste wieder, die f�r die jeweiligen Inhalte verantwortlich sind. Der Seitenbetreiber haftet nicht f�r Inhalte oder Richtigkeit der gemachten Angaben.';
$LANG['gb_save']              = 'Speichern';
$LANG['gb_homepage']          = 'Homepage';
$LANG['gb_comment']           = 'Kommentar';
$LANG['gb_email']             = 'eMail';
$LANG['gb_name']              = 'Name';
$LANG['gb_new_link']          = 'Ihr G&auml;stebuch Eintrag';
$LANG['gb_wrote']             = 'schrieb am';
$LANG['gb_create_entry']      = 'Hier k&ouml;nnen Sie einen neuen Eintrag hinterlassen';
$LANG['gb_page']              = 'Seite';
$LANG['gb_hp_link_alt']       = 'Link zur Webseite';

$LANG['gb_msg_enter_values']  = 'Sie m&uuml;ssen mindestens einen Namen und Ihren Kommentar eingeben!';

?>