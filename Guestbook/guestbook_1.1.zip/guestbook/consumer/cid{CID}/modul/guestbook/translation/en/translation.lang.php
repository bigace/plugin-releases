<?php
/**
* Translation file for Modul - Guestbook
*
* Language: deutsch (default)
* Locale:   de
*
* Copyright (C) Kevin Papst. 
*
* For further information go to http://www.kevinpapst.de/ 
* or contact bigace@kevinpapst.de.
*
* @version $Id: translation.lang.php,v 1.2 2006/04/09 18:58:04 kpapst Exp $
* @author Kevin Papst <bigace@kevinpapst.de>
* @package bigace.translation
*/

$LANG['gb_impressum']         = 'Email adress and Homepage are optional values that are not necessary to post a Comment. It is prohibited to use posted Data for any commercial reason (like Spam). The Webmaster is not responsible for the posted Comments!';
$LANG['gb_save']              = 'Save';
$LANG['gb_homepage']          = 'Homepage';
$LANG['gb_comment']           = 'Comment';
$LANG['gb_email']             = 'eMail';
$LANG['gb_name']              = 'Name';
$LANG['gb_new_link']          = 'Your Guestbook entry';
$LANG['gb_wrote']             = 'wrote on';
$LANG['gb_create_entry']      = 'Create a new Guestbook entry here';
$LANG['gb_page']              = 'Page';
$LANG['gb_hp_link_alt']       = 'Link to Website';

$LANG['gb_msg_enter_values']  = 'You have to enter at least a Name and Comment!';

?>