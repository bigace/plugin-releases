<?php
/**
* Translation file for Modul - Guestbook
*
* Language: english
* Locale:   en
*
* Copyright (C) Kevin Papst. 
*
* For further information go to http://www.kevinpapst.de/ 
* or contact bigace@kevinpapst.de.
*
* @version $Id: modul.lang.php,v 1.1 2006/04/06 21:50:07 kpapst Exp $
* @author Kevin Papst <bigace@kevinpapst.de>
* @package bigace.translation
*/

$LANG['modul_name_guestbook']    		= 'Guestbook';
$LANG['modul_title_guestbook']    		= 'Guestbook';
$LANG['modul_description_guestbook']  	= 'Displays a Guestbook where anonymous User may post Comments.';

?>