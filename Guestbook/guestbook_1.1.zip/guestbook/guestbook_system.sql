CREATE TABLE {DB_PREFIX}gaestebuch (
  id int(11) NOT NULL auto_increment,
  cid int(11) NOT NULL default '0',
  name varchar(255) NOT NULL default '',
  email varchar(255) NOT NULL default '',
  homepage varchar(255) NOT NULL default '',
  eintrag text NOT NULL,
  timestamp int(11) NOT NULL default '0',
  PRIMARY KEY  (id,cid)
) TYPE=MyISAM;