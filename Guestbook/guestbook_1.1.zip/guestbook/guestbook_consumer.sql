INSERT INTO {DB_PREFIX}gaestebuch (id, cid, name, email, homepage, eintrag, timestamp) VALUES 
(1, {CID}, 'Kevin Papst', 'bigace@kevinpapst.de', 'http://www.kevinpapst.de/', 'First test entry ;-)<br>Have fun with your Website and let me know if you like it!<br><br>Kevin', unix_timestamp());

# {-S-T-A-T-E-M-E-N-T--S-P-L-I-T-T-E-R-} #

INSERT INTO {DB_PREFIX}frights (cid,name,defaultvalue,description) VALUES 
({CID}, 'guestbook_admin', 'N', 'Allows to edit and delete all Guestbook Entrys.');
