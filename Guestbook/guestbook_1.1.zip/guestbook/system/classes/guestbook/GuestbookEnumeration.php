<?php
/**
 * BIGACE - a PHP and MySQL based Web CMS.
 * Copyright (C) 2003-2005 Kevin Papst.
 * 
 * BIGACE is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * BIGACE is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software Foundation, 
 * Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 * 
 * For further information visit {@link http://www.kevinpapst.de www.kevinpapst.de}.
 *
 * @version $Id: GuestbookEnumeration.php,v 1.1 2006/04/06 21:50:07 kpapst Exp $
 * @author Kevin Papst <bigace@kevinpapst.de>
 * @package bigace.classes.guestbook
 */

/**
 * Can be used to receive all or a list of Guestbook Entrys.
 * 
 * @package bigace.classes.guestbook
 */
class GuestbookEnumeration
{
	/**
	 * @access private
	 */
	var $all;
	
	function GuestbookEnumeration($from = '0', $limit = '-1')
	{
	    $LIM = '';
	    if ($limit != '-1') {
	        $LIM = " LIMIT ".$from.",".$limit;
	    }
	    $sql = $GLOBALS['_BIGACE']['SQL_HELPER']->loadAndPrepareStatement('guestbook_enum', array('CID' => _CID_, 'LIMIT' => $LIM));
		$this->all = $GLOBALS['_BIGACE']['SQL_HELPER']->execute($sql);
		unset ($sql);
	}

	function getAllEntrys()
	{
		return $this->all;
	}

	function getNextEntry()
	{
		$temp = $this->all->getNextResult();
		return new Guestbook($temp["id"]);
	}

	function countEntrys()
	{
	    if (is_object($this->all)) {
    		return $this->all->countResult();
	    } else {
	        return 0;
	    }
	}
	
	function countAllEntrys()
	{
	    $sql = $GLOBALS['_BIGACE']['SQL_HELPER']->loadAndPrepareStatement('guestbook_count_all', array('CID' => _CID_));
		$entrys = $GLOBALS['_BIGACE']['SQL_HELPER']->execute($sql);
		return $entrys->getNextResult();
	}
}


?>