<?php
/**
* Translation file for Administration - Categorys
*
* Language: deutsch (default)
* Locale:   de
*
* Copyright (C) 2003-2004 Kevin Papst. 
*
* For further information go to http://www.kevinpapst.de/ 
* or contact bigace@kevinpapst.de.
*
* @version $Id: translation.lang.php,v 1.1 2006/04/06 21:50:06 kpapst Exp $
* @author Kevin Papst <bigace@kevinpapst.de>
* @package bigace.translation
*/

$LANG['menu_guestbook']   		= 'G&auml;stebuch';
$LANG['title_guestbook']        = 'G&auml;stebuch';
$LANG['description_guestbook']  = 'Hier k&ouml;nnen Sie die Eintr�ge in Ihrem G�stebuch bearbeiten.';

$LANG['gb_delete_entry']      	= 'Eintrag entfernen';
$LANG['gb_edit_entry']        	= 'Eintrag bearbeiten';

$LANG['gbUser']            		= 'Autor Name';
$LANG['gbHomepage']            	= 'Link';
$LANG['gbEmail']            	= 'Email';
$LANG['gbDate']            		= '�nderungsdatum';
$LANG['gbEntry']            	= 'Eintrag';

$LANG['gbEdit']            		= '&Auml;ndern';
$LANG['gbSave']            		= 'Speichern';
$LANG['gbDelete']            	= 'L&ouml;schen';

?>