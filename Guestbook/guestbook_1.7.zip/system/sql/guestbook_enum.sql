SELECT id FROM {DB_PREFIX}gaestebuch WHERE cid={CID} ORDER BY timestamp DESC LIMIT {FROM}, {TO}
