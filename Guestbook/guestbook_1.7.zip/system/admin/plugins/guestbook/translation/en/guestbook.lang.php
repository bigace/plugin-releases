<?php
/**
* Translation file for Guestbook Administration
*
* Language: en
*
* Copyright (C) Kevin Papst. 
*
* For further information go to http://www.bigace.de/ 
*
* @version $Id: guestbook.lang.php,v 1.1 2009/05/11 21:48:28 kpapst Exp $
* @author Kevin Papst 
* @package bigace.translation
*/

$LANG['menu_guestbook']   		= 'Guestbook';
$LANG['title_guestbook']        = 'Guestbook';
$LANG['description_guestbook']  = 'Edit and delete your Guestbook entrys here.';

$LANG['gb_delete_entry']      	= 'Remove entry';
$LANG['gb_edit_entry']        	= 'Edit entry';

$LANG['gbUser']            		= 'Author Name';
$LANG['gbHomepage']            	= 'Link';
$LANG['gbEmail']            	= 'Email';
$LANG['gbDate']            		= 'Change date';
$LANG['gbEntry']            	= 'Comment';

$LANG['gbEdit']            		= 'Change';
$LANG['gbSave']            		= 'Save';
$LANG['gbDelete']            	= 'Delete';

?>