<?php
/**
* Translation file for Modul - Preview Submenu
*
* Language: deutsch (default)
* Locale:   de
*
* Copyright (C) 2002-2006 Kevin Papst. 
*
* For further information go to http://www.bigace.de/ 
*
* @version $Id: translation.lang.php,v 1.3 2006/11/26 21:58:51 kpapst Exp $
* @author Kevin Papst 
* @package bigace.translation
*/

$LANG['sitemap_title']       = 'Seite&nbsp;anzeigen';

?>