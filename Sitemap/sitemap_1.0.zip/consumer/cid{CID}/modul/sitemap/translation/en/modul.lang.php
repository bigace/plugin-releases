<?php
/**
* Translation file for Modul - Contact Mail
*
* Language: deutsch (default)
* Locale:   de
*
* Copyright (C) 2002-2006 Kevin Papst. 
*
* For further information go to http://www.bigace.de/ 
*
* @version $Id: modul.lang.php,v 1.2 2006/11/26 21:58:46 kpapst Exp $
* @author Kevin Papst 
* @package bigace.translation
*/

$LANG['name']    		= 'Sitemap';
$LANG['title']    		= 'Sitemap';
$LANG['description']  	= 'Display a Map of all Pages on your Site.';

?>