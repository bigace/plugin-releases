<?php
/**
* Translation file for Modul - Preview Submenu
*
* Language: deutsch (default)
* Locale:   de
*
* Copyright (C) 2002-2006 Kevin Papst. 
*
* For further information go to http://www.bigace.de/ 
*
* @version $Id: translation.lang.php 2 2011-01-31 13:29:57Z kevin $
* @author Kevin Papst 
* @package bigace.translation
*/

$LANG['sitemap_title']       = 'Seite&nbsp;anzeigen';

?>