<?php
/**
* Translation file for Modul - Preview Submenu
*
* Language: english
* Locale:   en
*
* Copyright (C) Kevin Papst. 
*
* For further information go to http://www.bigace.de/ 
*
* @version $Id: translation.lang.php 2 2011-01-31 13:29:57Z kevin $
* @author Kevin Papst 
* @package bigace.translation
*/

$LANG['sitemap_title']       = 'Show Menu';


?>