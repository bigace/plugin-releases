<?php
/**
* Translation file for Modul - Contact Mail
*
* Language: deutsch (default)
* Locale:   de
*
* Copyright (C) 2002-2006 Kevin Papst. 
*
* For further information go to http://www.bigace.de/ 
*
* @version $Id: modul.lang.php,v 1.5 2006/11/26 21:58:51 kpapst Exp $
* @author Kevin Papst 
* @package bigace.translation
*/

$LANG['name']    		= 'Sitemap';
$LANG['title']    		= 'Sitemap';
$LANG['description']  	= 'Hiermit k&ouml;nnen Sie eine &Uuml;bersicht ihrer Seite anzeigen.';

?>