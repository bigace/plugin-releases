<?php
/**
* Translation file for Modul - Preview Submenu
*
* Language: english
* Locale:   en
*
* Copyright (C) Kevin Papst. 
*
* For further information go to http://www.bigace.de/ 
*
* @version $Id: translation.lang.php,v 1.3 2006/11/26 21:58:46 kpapst Exp $
* @author Kevin Papst 
* @package bigace.translation
*/

$LANG['sitemap_title']       = 'Show Menu';


?>