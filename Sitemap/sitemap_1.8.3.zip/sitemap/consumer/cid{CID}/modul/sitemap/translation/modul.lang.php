<?php
/**
* Translation file for Modul - Contact Mail
*
* Language: deutsch (default)
* Locale:   de
*
* Copyright (C) 2003-2004 Kevin Papst. 
*
* For further information go to http://www.kevinpapst.de/ 
* or contact bigace@kevinpapst.de.
*
* @version $Id: modul.lang.php,v 1.1 2006/04/06 21:50:46 kpapst Exp $
* @author Kevin Papst <bigace@kevinpapst.de>
* @package bigace.translation
*/

$LANG['modul_name_sitemap']    			= 'Sitemap';
$LANG['modul_title_sitemap']    		= 'Sitemap';
$LANG['modul_description_sitemap']  	= 'Hiermit k�nnen Sie eine �bersicht ihrer Seite anzeigen.';

?>