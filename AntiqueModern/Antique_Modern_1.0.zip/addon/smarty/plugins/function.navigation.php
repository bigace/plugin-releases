<?php

import('classes.util.SmartyLink');
import('classes.util.LinkHelper');

/*
 * Smarty plugin
 * -------------------------------------------------------------
 * File:     function.navigation.php
 * Type:     function
 * Name:     navigation
 * Purpose:  Prints a configurable Navigation
 * -------------------------------------------------------------
 */
function smarty_function_navigation($params, &$smarty)
{
	$id = (isset($params['id']) ? $params['id'] : $GLOBALS['_BIGACE']['PARSER']->getItemID());	
	$lang = (isset($params['language']) ? $params['language'] : $GLOBALS['_BIGACE']['PARSER']->getLanguage());	
	$css = (isset($params['css']) ? ' class="'.$params['css'].'"' : '');	
	$selected = (isset($params['selected']) ? ' class="'.$params['selected'].'"' : '');
	$active = (isset($params['active']) ? $params['active'] : '');
	$pre = (isset($params['prefix']) ? $params['prefix'] : '');	
	$after = (isset($params['suffix']) ? $params['suffix'] : '');	
	$html = (isset($params['start']) ? $params['start'] : '');	
	
	$menu_info = $GLOBALS['MENU_SERVICE']->getLightTreeForLanguage($id, $lang);

	if(isset($params['counter']))
		$smarty->assign($params['counter'], $menu_info->count());

    for ($i=0; $i < $menu_info->count(); $i++) 
    {
		$class = $css;
		$prefix = $pre;
		$temp_menu = $menu_info->next();
		if ((isset($params['active']) || isset($params['selected'])) && 
			($temp_menu->getID() == $GLOBALS['_BIGACE']['PARSER']->getItemID() || 
				$GLOBALS['MENU_SERVICE']->isChildOf($temp_menu->getID(), $GLOBALS['_BIGACE']['PARSER']->getItemID()))
			) {
			$class = $selected;
			if(isset($params['active'])) $prefix = $active;
		}
		$link = new SmartyLink();
		$link->setItemID($temp_menu->getID());
		$link->setLanguageID($temp_menu->getLanguageID());
		$html .= $prefix . "<a href=\"".LinkHelper::getUrlFromCMSLink($link)."\"".$class.">".$temp_menu->getName()."</a>".$after."\n";
    }
    
    return $html . (isset($params['end']) ? $params['end'] : '');
}
?> 