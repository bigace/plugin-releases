<?php
/**
* Modul Translation file
*
* Language: deutsch (default)
* Locale:   de
*
* Copyright (C) Kevin Papst.
*
* For further information go to http://www.bigace.de/
*
* @version $Id: modul.lang.php,v 1.2 2006/11/26 21:58:47 kpapst Exp $
* @author Kevin Papst 
* @package bigace.translation
*/

$LANG['name']    		= 'IFrame';
$LANG['title']    		= 'Display IFrame';
$LANG['description']  	= 'Script to display an IFrame below the Pages Content.';

$LANG['unconfigured']   = "This Modul is not properly configured. Please contact your Administrator.";
$LANG['admin']          = "Configure IFrame";

?>