﻿<?php
 /**
 * Translation file for Modul - Display Content
 *
 * Language: Svenska
 * Locale:   se
 *
 * Copyright (C) Kevin Papst.
 *
 * For further information go to http://www.bigace.de/
 *
 * @version $Id: modul.lang.php,v 1.7 2009/03/10 15:00:07 dragonslayer_se Exp $
 * @author DragonSlayer
 * @package bigace.translation
 *
 */

$LANG['name']		= 'Visa Innehåll';
$LANG['title']		= 'Visa menyns HTML innehåll';
$LANG['description']	= 'Du kan visa ditt redigerbara HTML innehåll med denna modul.';

?>