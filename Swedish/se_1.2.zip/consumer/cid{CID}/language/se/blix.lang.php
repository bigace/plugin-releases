﻿<?php

$LANG['written_at'] = 'skriven:';
$LANG['written_by'] = 'av';
$LANG['search_button'] = 'Sök!';
$LANG['empty_searchterm'] = 'Du måste skriva in en sökterm, minst 4 tecken!';
$LANG['short_searchterm'] = 'Din sökterm är för kort, använd minst 4 tecken!';

?>