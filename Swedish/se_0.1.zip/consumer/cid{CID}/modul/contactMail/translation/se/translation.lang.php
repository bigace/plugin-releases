<?php
/**
* Translation file for Modul - Contact Mail
*
* Language: svenska
* Locale:   se
*

*/

$LANG['initial_message']    = '';
$LANG['initial_subject']    = '';
$LANG['create_new_msg']     = 'Skapa nytt epostmeddelande';
$LANG['contact_error_msg']  = '<p><b>Fel!</b></p><p>Ditt meddelande kunde inte levereras.<br>Prova att skicka igen!<br>Tack</p>';
$LANG['error_retry']        = 'Fel.. f�rs�k igen...';
$LANG['form_message']       = 'Meddelande';
$LANG['form_subject']       = '�mne';
$LANG['form_email']         = 'Din ePost adress';
$LANG['form_name']          = 'Ditt Namn';
$LANG['form_send']          = 'Skicka';
$LANG['form_title']         = 'Skriv meddelande:';
$LANG['missing_values']     = 'Du beh�ver fylla i de n�dv�ndiga f�lten.';
$LANG['required']           = 'N�dv�ndiga f�lt';
$LANG['unconfigured']       = 'Den h�r modulen �r inte konfigurerad.. kontakta din administrat�r.';
$LANG['email_intro']        = 'Detta meddelande skickades till dig med BIGACE Webmail Formular.';
$LANG['email_sent']     	= 'Ditt meddelande levererades.';

?>