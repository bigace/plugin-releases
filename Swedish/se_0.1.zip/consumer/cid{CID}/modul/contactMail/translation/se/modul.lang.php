<?php
/**
* Translation file for Modul - Contact Mail
* Language: svenska
* Locale:   se
*
*/

$LANG['name']		    = 'Kontakt formul�r';
$LANG['title']		    = 'skicka oss ett meddelande';                                                            
$LANG['description']	= 'skicka ett meddelande till en eller flera konfigurerade mottagare.';

?>