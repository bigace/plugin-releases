<?php
/**
* Modul Translation file 
*
* Language: svenska
* Locale:   se
*
*/

$LANG['name']    		= 'Foto Gallery';
$LANG['title']    		= 'Enkelt Foto Gallery';
$LANG['description']  	= 'Skript f�r att visa ett enkelt foto galleri. skapar en lista genom att v�lja objekt fr�n en kategori.';

?>