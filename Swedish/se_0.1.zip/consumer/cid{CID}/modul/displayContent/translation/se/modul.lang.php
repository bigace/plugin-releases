<?php
 /**
 * Translation file for Modul - Display Content
 *
 * Language: Svenska
 * Locale:   se
 *
 */

$LANG['name']    	    = 'Visa Inneh�ll';
$LANG['title']    		= 'Visa menyns HTML inneh�ll';
$LANG['description']  	= 'Du kan visa ditt redigerbara HTML ineh�ll med denna mudulen.';

?>