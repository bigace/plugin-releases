<?php
/**
* Modul Translation file
*
* Language: Svenska
* Locale:   sv

*/

$LANG['name']    		= 'IFrame';
$LANG['title']    		= 'Visa IFrame';
$LANG['description']  	= 'Skript f�r att visa ett IFrame nedanf�r sidans vanliga inneh�ll.';

$LANG['unconfigured']   = "Den h�r modulen �r inte ordentligt konfigurerad. Kontakta din Administrat�r.";
$LANG['admin']          = "Konfigurera IFrame";

?>