<?php

$LANG['written_at'] = 'skriven:';
$LANG['written_by'] = 'av';
$LANG['search_button'] = 'S�k!';
$LANG['empty_searchterm'] = 'Du m�ste skriva in en s�kterm, minst 4 tecken!';
$LANG['short_searchterm'] = 'Din s�kterm �r f�r kort, anv�nd minst 4 tecken!';

?>