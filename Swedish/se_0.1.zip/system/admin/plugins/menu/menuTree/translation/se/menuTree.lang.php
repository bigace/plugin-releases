<?php
/**
* Translation file for Administration - MenuTree
*
* Language: Svenska
* Locale:   se

*/

$LANG['title_menuTree']        = 'Meny Administration';
$LANG['description_menuTree']  = 'Administrera dina menyer h�r. Du kan skapa sidor, �ndra deras inst�llningar och inneh�ll, �ndra p� r�ttigheter och kategori l�nkar, titta p� och g� tillbaks till �ldre versioner och radera sidor.';

// title of main tab
$LANG['tree_tab_title']        = 'Meny Tr�d';

// top menu
$LANG['tree_action_focusOnSelect']  = 'Fokus p� Val';
$LANG['tree_action_focusOnOpen']    = 'Focus vid �ppna';
$LANG['tree_action_openOnSelect']   = '�ppna vid val';
// action buttons
$LANG['tree_action_reloadTree']     = 'Ladda om Meny tr�det';
$LANG['tree_action_reInsert']       = 'S�tt in menyn p� original plats';
$LANG['tree_action_expandAll']      = 'Expandera alla synbara meny-mappar';
$LANG['tree_action_Cut']            = '<b>Klipp ut Meny</b><br/>(kommer inte att raderas)';
$LANG['tree_action_Copy']           = '<b>Kopiera Meny</b>';
$LANG['tree_action_Paste']          = '<b>Klistra in Meny</b><br/>(S�tts in under markering)';

// item menu
$LANG['item_action_newpage_same']   = 'Skapa sidan p� samma niv�';
$LANG['item_action_newpage_below']  = 'Skapa sidan under';
$LANG['item_languages']             = 'Spr�k';
$LANG['item_reorder_childs']        = 'Sortera undermenyer';

$LANG['item_state_hidden']          = 'Dold';
$LANG['item_state_workflow']        = 'I Arbetsfl�de';

$LANG['item_not_loaded']            = 'Sidan kunde inte laddas!';

// reorder pages
$LANG['sort_tab_title']        = 'Sortera Menuyer';
$LANG['sort_childs_of']        = '�ndra position p� sidor nedanf�r';
$LANG['sort_button']           = 'Spara';

// delete pages
$LANG['confirm_delete_node']   = 'Vill du verkligen radera den h�r menyn: ';
$LANG['confirm_delete_tree']   = 'Om du raderar denna meny, kommer �ven under-menyer att raderas!';

?>