<?php
/**
* Translation file for Administration - MenuReorder
*
* Language: svenska
* Locale:   se
*

*/


$LANG['title_menuReorder']        = '�ndra meny ordningen';
$LANG['description_menuReorder']  = '�ndra positionen p� alla undermenyer under en given sida.';

// reorder pages
$LANG['sort_tab_title']        = 'Sortera Menyer';
$LANG['sort_childs_of']        = '�ndra position p� sidor nedan';
$LANG['sort_button']           = 'Spara';

