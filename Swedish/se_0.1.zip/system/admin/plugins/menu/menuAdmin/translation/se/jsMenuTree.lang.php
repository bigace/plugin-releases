<?php
/**
* Translation file for Menu Administration JS Tree
*
* Locale: se
*
*/

$LANG['title_menuAdminNavi']        = 'Menyer';
$LANG['description_menuAdminNavi']  = 'Administrera dina sidor.';

// action buttons
$LANG['tree_action_openOnSelect']   = '�ppna meny-administrationen vid markering.';
$LANG['tree_action_reloadTree']     = 'Ladda om Meny tr�det';
$LANG['tree_action_reInsert']       = 'S�tt in menyn p� original plats';
$LANG['tree_action_expandAll']      = 'Expandera alla synbara meny-mappar';
$LANG['tree_action_Cut']            = '<b>Klipp ut Meny</b><br/>(kommer inte att raderas)';
$LANG['tree_action_Copy']           = '<b>Kopiera Meny</b>';
$LANG['tree_action_Paste']          = '<b>Klistra in Meny</b><br/>(S�tts in under markering)';

// item menu
$LANG['item_action_newpage_same']   = 'Skapa sidan p� samma niv�';
$LANG['item_action_newpage_below']  = 'Skapa sidan under';
$LANG['item_languages']             = 'Spr�k';
$LANG['item_reorder_childs']        = 'Sortera undermenyer';

$LANG['item_state_hidden']          = 'Dold';
$LANG['item_state_workflow']        = 'I Arbetsfl�de';

$LANG['item_not_loaded']            = 'Sidan kunde inte laddas!';

// editor
$LANG['edit_content']            	= '�ndra sidans inneh�ll';

// delete pages
$LANG['confirm_delete_node']   = 'Vill du verkligen radera den h�r menyn: ';
$LANG['confirm_delete_tree']   = 'Om du raderar denna meny, kommer �ven under-menyer att raderas!';
