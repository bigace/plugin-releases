<?php
/**
 * BIGACE - a PHP and MySQL based Web CMS.
 * Copyright (C) Kevin Papst.
 *
 * BIGACE is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * BIGACE is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software Foundation,
 * Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 *
 * For further information visit {@link http://www.bigace.de http://www.bigace.de}.
 *
 * @version $Id: fckeditor.php,v 1.1 2008/03/13 01:05:46 kpapst Exp $
 * @author Kevin Papst 
 * @package bigace.editor
 */

/**
 * This script is used for loading and handling the FCKEditor.
 */

loadLanguageFile('fckeditor',_ULC_);

$FCK_PATH['NAME']   = 'FCKeditor';
$FCK_PATH['BASE']   = '/' . _BIGACE_DIR_PATH . 'addon/' . $FCK_PATH['NAME'] . '/';
$FCK_PATH['PUBLIC'] = $_BIGACE['DOMAIN'] . _BIGACE_DIR_PATH . 'addon/' . $FCK_PATH['NAME'] . '/';

if (file_exists($EDITOR_DIRECTORY) && file_exists($GLOBALS['_BIGACE']['DIR']['addon'].$FCK_PATH['NAME'].'/fckeditor.php'))
{
    if ($mode == 'customConfig')
    {
        include_once ($EDITOR_DIRECTORY.'javascript.php');
    }
    else
    {
        require_once($GLOBALS['_BIGACE']['DIR']['addon'].$FCK_PATH['NAME'].'/fckeditor.php');

        showEditorHeader();

        ?>
        <script type="text/javascript">
        <!--
        // receive the FCKeditor instance that is used to edit the content
        function getFCKInstance() {
            return FCKeditorAPI.GetInstance('<?php echo CONTENT_PARAMETER; ?>');
        }
        
        // =================================================
        // Required methods for the BIGACE Editor Framework.
        // =================================================
        
        function getEditorContent() {
            return getFCKInstance().GetXHTML(false);
        }
        function setEditorContent(myHtml) {
            getFCKInstance().SetHTML(myHtml);
        }
        function isDirtyEditor() {
            return getFCKInstance().IsDirty();
        }
        function resetIsDirtyEditor() {
        	return getFCKInstance().ResetIsDirty();
        }
        // -->
        </script>
        <?php

            $oFCKeditor = new FCKeditor( CONTENT_PARAMETER );
            $oFCKeditor->ToolbarSet         = 'Bigace';
            $oFCKeditor->Width              = '100%';
            $oFCKeditor->Height             = '100%';
            $oFCKeditor->DefaultLanguage    = $LANGUAGE->getLocale();
            $oFCKeditor->DefaultLanguageID  = $LANGUAGE->getID();
            $oFCKeditor->Value              = $content;
    		$oFCKeditor->BasePath           = $FCK_PATH['BASE'] ;
            $oFCKeditor->Config             = array('CustomConfigurationsPath' => createEditorLink(EDITOR_FCKEDITOR, $MENU->getID(), $MENU->getLanguageID(), 'customConfig', array(), 'editor.js'));
            $oFCKeditor->Create();

        showEditorFooter();
    }
}
else
{
    // FCKEDITOR IS NOT INSTALLED
    echo '<p><b>The FCKEditor seems not to be installed on your System!</b></p>';
}
