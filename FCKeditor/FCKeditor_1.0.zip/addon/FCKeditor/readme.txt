This directory must contain the FCKeditor!
Otherwise the FCKeditor Plugin for BIGACE is not able to work.
