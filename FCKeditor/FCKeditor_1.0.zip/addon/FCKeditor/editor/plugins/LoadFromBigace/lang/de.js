
FCKLang['DlgLoadFromBigaceTitle']		= 'Lade Seite' ;
