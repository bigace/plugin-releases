
FCKLang['DlgLoadFromBigaceTitle']		= 'Load Page' ;
