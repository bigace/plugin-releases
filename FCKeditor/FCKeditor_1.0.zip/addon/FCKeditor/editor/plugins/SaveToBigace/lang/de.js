
FCKLang['DlgSaveToBigaceTitle']		= 'Seite speichern' ;
