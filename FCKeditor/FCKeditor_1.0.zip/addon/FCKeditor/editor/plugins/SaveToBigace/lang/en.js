
FCKLang['DlgSaveToBigaceTitle']		= 'Save Page' ;
