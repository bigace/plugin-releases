INSERT INTO {DB_PREFIX}frights (id,cid,name,defaultvalue,description) VALUES 
({CID}, 'fotoalbum_admin', 'N', 'Allow User to administrate the Fotoalbum settings.');
