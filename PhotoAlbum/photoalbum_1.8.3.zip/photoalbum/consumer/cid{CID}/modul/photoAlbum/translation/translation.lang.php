<?php
/**
* Translation file for Modul - Photo Album
*
* Language: deutsch (default)
* Locale:   de
*
* Copyright (C) Kevin Papst. 
*
* For further information go to http://www.kevinpapst.de/ 
* or contact bigace@kevinpapst.de.
*
* @version $Id: translation.lang.php,v 1.2 2006/04/09 22:00:05 kpapst Exp $
* @author Kevin Papst <bigace@kevinpapst.de>
* @package bigace.translation
*/

$LANG['fotoalbum_showpicture']     = 'Bild anzeigen';
$LANG['fotoalbum_showlist']        = 'Zur �bersicht';
$LANG['album_unconfigured']        = 'Dieses Modul ist nicht vollst�ndig konfiguriert. Bitte kontaktieren Sie Ihren Administrator.';

?>