<?php
/**
* Translation file for Modul - Photo Album
*
* Language: deutsch (default)
* Locale:   de
*
* Copyright (C) Kevin Papst. 
*
* For further information go to http://www.kevinpapst.de/ 
* or contact bigace@kevinpapst.de.
*
* @version $Id: modul.lang.php,v 1.1 2006/04/06 21:48:20 kpapst Exp $
* @author Kevin Papst <bigace@kevinpapst.de>
* @package bigace.translation
*/

$LANG['modul_name_photoAlbum']    		= 'Photo Album';
$LANG['modul_title_photoAlbum']    		= 'Photo Album';
$LANG['modul_description_photoAlbum']  	= 'Displays a Photo Album. The displayed Images will be calculated by a configured Category. All Images that are linked to this Category will be shown.';

?>