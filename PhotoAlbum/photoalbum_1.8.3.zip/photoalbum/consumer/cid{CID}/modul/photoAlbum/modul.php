<?php
/**
* FOTOALBUM
* The Fotoalbum displays all Images of a choosen Category in a List.
* The List shows a resized version of the original Image on the left and
* the description on the right. 
*
* This script needs at last one CSS entry like this:
*
* #fotoalbumEntry { margin-bottom:10px;border:1px dashed #cccccc;width:100%; }
*
* Copyright (C) Kevin Papst
*
* For further information go to http://www.kevinpapst.de/ 
* or contact bigace@kevinpapst.de.
*
* @version $Id: modul.php,v 1.6 2006/04/17 09:47:29 kpapst Exp $
* @author Kevin Papst <bigace@kevinpapst.de>
* @package bigace.modul
*/

loadClass('image', 'ImageService');
loadClass('image', 'Image');
loadClass('category', 'Category');
loadClass('category', 'CategoryService');
loadClass('item', 'ItemProjectService');
loadClass('fright', 'FrightService');

require_once ($_BIGACE['DIR']['libs'].'htmlhelper.inc.php');

/**
* Configuration array for the Picture Gallery
*/
$_FOTOALBUM = array();

$_FOTOALBUM['MODE_LIST']    = 1;            // Show List of all categorized Images
$_FOTOALBUM['MODE_DETAIL']  = 2;            // Show selected image
$_FOTOALBUM['MODE_ADMIN']   = 3;            // Show Administration
$_FOTOALBUM['MODE_SAVE']    = 4;            // Save category settings
$_FOTOALBUM['PRE_WIDTH']    = '150';        // width for the preview image

define('ALBUM_ADMIN_FRIGHT',      'fotoalbum_admin'); // fright for the administration
define('MODUL_ADMIN_FRIGHT',      'module_all_rights'); // fright for every modul administration

$FRIGHTSERVICE = new FrightService();
define('IS_FOTO_ADMIN', $FRIGHTSERVICE->hasFright($USER->getID(), ALBUM_ADMIN_FRIGHT) || $FRIGHTSERVICE->hasFright($USER->getID(), MODUL_ADMIN_FRIGHT));
unset($FRIGHTSERVICE);

$CAT_SERVICE    = new CategoryService();
$IMG_SERVICE    = new ImageService();
$projectService = new ItemProjectService(_BIGACE_ITEM_MENU);

$mode           = extractVar('mode', $_FOTOALBUM['MODE_LIST']);
$isConfigured   = false;
$CUR_CAT        = -1;

/* Check for URL passed values! */
if ($mode == $_FOTOALBUM['MODE_ADMIN'] || $mode == $_FOTOALBUM['MODE_SAVE']) {
    if (!IS_FOTO_ADMIN) {
        $mode = $_FOTOALBUM['MODE_LIST'];
    }
}

/* Show Administration Link */
if ($mode != $_FOTOALBUM['MODE_ADMIN'] && $mode != $_FOTOALBUM['MODE_DETAIL'] && IS_FOTO_ADMIN)
{
    echo '<center><a href="'.createMenuLink($GLOBALS['MENU']->getID(),array('mode' => $_FOTOALBUM['MODE_ADMIN'])).'">'.getTranslation('admin','Administration').'</a></center>';
    echo '<br/>';
}

if($projectService->existsProjectNum($MENU->getID(), $MENU->getLanguageID(), '1'))
{
    $CUR_CAT = $projectService->getProjectNum($MENU->getID(), $MENU->getLanguageID(), '1');
    $isConfigured = true;
}


/* #########################################################################
 * ###########################  Show Administration  #######################
 * ######################################################################### 
 */
if ($mode == $_FOTOALBUM['MODE_ADMIN'])
{
   if (IS_FOTO_ADMIN)
   {
        $opts = array();
        loadClass('category', 'CategoryList');
        $CAT_LIST = new CategoryList();
        for ($a = 0; $a < $CAT_LIST->count(); $a++)  {
            $temp = $CAT_LIST->next();
            $opts[$temp->getName()] = $temp->getID();
            unset ($temp);
        }
        
        $html = array(
                        'width'         =>  '500',
                        'align'         =>  array (
                                                'table'     =>  'center',
                                                'left'      =>  'left'
                                            ),
                        'title'         =>  getTranslation('admin','Administration'),
                        'form_action'   =>  createMenuLink($GLOBALS['MENU']->getID()),
                        'form_method'   =>  'post',
                        'form_hidden'   =>  array(
                                                'mode' => '4'
                                        ),
                        'entries'       =>  array(
                                                'Category'  => createSelectBox('category', $opts, $CUR_CAT, '')
                                        ),
                        'form_submit'   =>  true,
                        'form_reset'    =>  "location.href='".createMenuLink($GLOBALS['MENU']->getID())."'",
                        'reset_label'   =>  getTranslation('back','Back'),
                        'submit_label'  =>  getTranslation('save','Save')
        );
        echo createTable($html) . '<br/>';
        unset($opts);
        unset($CAT_LIST);
        unset($html);
    } 
    else 
    {
        $mode = $_FOTOALBUM['MODE_LIST'];
    }
}


/* #########################################################################
 * #######################  4: Save category settings  #####################
 * ######################################################################### 
 */
if ($mode == 4) 
{
    if (IS_FOTO_ADMIN)
    {
        $data = extractVar('data', array('category' => $CUR_CAT));
        $title = 'Settings did not change!';
        $temp = $CAT_SERVICE->getCategory($CUR_CAT);
        $entrys = array('Old:' => $temp->getName() .' (' . $temp->getID() . ')');
        $temp = $CAT_SERVICE->getCategory($data['category']);
        $entrys['New:'] = $temp->getName() .' (' . $temp->getID() . ')';

        if (isset($data['category'])) 
        {
            if ($data['category'] != $CUR_CAT) 
            {
                loadClass('item', 'ItemAdminService');
                $ADMIN_SERVICE = new ItemAdminService(_BIGACE_ITEM_MENU);
                if ( $ADMIN_SERVICE->setProjectNum($GLOBALS['MENU']->getID(),$GLOBALS['MENU']->getLanguageID(),'1',$data['category']) ) 
                {
                    $title =  'Saved settings successful!';
                    $isConfigured = true;
                }
                unset($ADMIN_SERVICE);
                $CUR_CAT = $data['category'];
            }
        } else {
            $title =  'Saving failed!';
        }

        $config = array(
                        'width'         =>  '80%',
                        'align'         =>  array (
                                                'table'     => 'center',
                                                'left'      => 'left',
                                                'bottom'    => 'left'
                                            ),
                        'title'         =>  $title,
                        'form_hide'     =>  true,
                        'entries'       =>  $entrys
        );
        echo createTable($config) . '<br/>';
        unset($title);
        unset($config);
        unset($entrys);
        unset($temp);
        unset($data);
    } // hasFright
    $mode = $_FOTOALBUM['MODE_LIST'];
} // ($mode == 4) 



/* #########################################################################
 * ###########################  Show selected image  #######################
 * ######################################################################### 
 */
if ($mode == $_FOTOALBUM['MODE_DETAIL'])
{
    $temp_image = $IMG_SERVICE->getClass( extractVar('imageid', '1') );
    
    $entry = '<center><img src="'.createCommandLink('image', $temp_image->getID(), array(), $temp_image->getOriginalName()).'" style="border-width:0px" alt="'.$temp_image->getName().'"></center>';
    $entry .= '<br>'.$temp_image->getDescription().'<br><br>';

    $config = array(
                    'width'         =>  '',
                    'align'         =>  array (
                                            'table'     => 'center',
                                            'left'      => 'left',
                                            'bottom'    => 'left'
                                        ),
                    'title'         =>  $temp_image->getName(),
                    'form_hide'     =>  true,
                    'entries'       =>  array(
                                            $entry => 'empty'
                                    ),
                    'submit_label'  =>  '<a href="'.createMenuLink($MENU->getID(), array('mode'=>$_FOTOALBUM['MODE_LIST'].'#image'.$temp_image->getID())).'" title="'.getTranslation('fotoalbum_showlist').'"><img src="'.$GLOBALS['_BIGACE']['DIR']['public'].'modul/images/fotoalbum_back.gif" border="0"> '.getTranslation('fotoalbum_showlist').'</a>',
    );
    echo '<br/>' . createTable($config);
}


/* #########################################################################
 * ##################  Show List of all categorized Images  ################
 * ######################################################################### 
 */
if ($mode != $_FOTOALBUM['MODE_ADMIN'] && $mode != $_FOTOALBUM['MODE_DETAIL'])
{
    if(!$isConfigured)
    {
        echo '<br><b>'.getTranslation('album_unconfigured').'</b><br>';
    }
    else
    {
        $search = $CAT_SERVICE->getItemsForCategory($IMG_SERVICE->getItemtype(), $CUR_CAT);
        
        ?>
        
        <p><?php echo $MENU->getContent(); ?></p>
        
        <?php
        
        while ($search->hasNext())
        {
            $temp = $search->next();
            $temp_image = $IMG_SERVICE->getClass($temp['itemid']);
            
            ?> 
            <div id="fotoalbumEntry">
            <table width="100%" cellpadding="2" cellspacing="2" align="center">
                <tr>
                    <td width="<?php echo $_FOTOALBUM['PRE_WIDTH']; ?>" align="center" valign="top" rowspan="2">
                        <img src="<?php echo createCommandLink('image', $temp_image->getID(), array('resize' => $_FOTOALBUM['PRE_WIDTH']), $temp_image->getOriginalName()); ?>" border="0" alt="<?php echo htmlspecialchars($temp_image->getDescription()); ?>" width="<?php echo $_FOTOALBUM['PRE_WIDTH']; ?>">
                    </td>
                    <td valign="top">
                        <table border="0" width="100%">
                        <tr><th align="center"><a href="<?php echo createMenuLink($GLOBALS['MENU']->getID(), array('mode' => $_FOTOALBUM['MODE_DETAIL'], 'imageid' => $temp_image->getID())); ?>" title="<?php echo getTranslation('fotoalbum_showpicture'); ?>"><?php echo $temp_image->getName(); ?></a></th></tr>
                        <tr><td><p><?php echo $temp_image->getDescription(); ?></p></td></tr>
                        </table>
                    </td>
                </tr>
                <tr>
                    <td valign="bottom" align="right">
                        <p><a href="<?php echo createMenuLink($GLOBALS['MENU']->getID(), array('mode' => $_FOTOALBUM['MODE_DETAIL'], 'imageid' => $temp_image->getID())); ?>" title="<?php echo getTranslation('fotoalbum_showpicture'); ?>"><?php echo getTranslation('fotoalbum_showpicture'); ?></a></p>
                    </td>
                </tr>
            </table>
            </div>
            <?php
        }
    } // isConfigured

} // ($mode == $_FOTOALBUM['MODE_LIST']) 


?>