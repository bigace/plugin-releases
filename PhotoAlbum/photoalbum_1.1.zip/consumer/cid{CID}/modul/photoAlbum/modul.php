<?php
/**
* FOTOALBUM
* The Fotoalbum displays all Images of a choosen Category in a List.
* The List shows a resized version of the original Image on the left and
* the description on the right.
*
* This script needs at last one CSS entry like this:
*
* #fotoalbumEntry { margin-bottom:10px;border:1px dashed #cccccc;width:100%; }
*
* Copyright (C) Kevin Papst
*
* For further information go to http://www.bigace.de/
*
* @version $Id: modul.php,v 1.9 2006/11/26 21:58:58 kpapst Exp $
* @author Kevin Papst 
* @package bigace.modul
*/

import('classes.image.ImageService');
import('classes.image.Image');
import('classes.category.Category');
import('classes.category.CategoryService');
import('classes.item.ItemProjectService');
import('classes.util.html.FormularHelper');

/**
* Configuration array for the Picture Gallery
*/
$_FOTOALBUM = array();

$_FOTOALBUM['MODE_LIST']    = 1;            // Show List of all categorized Images
$_FOTOALBUM['MODE_DETAIL']  = 2;            // Show selected image
$_FOTOALBUM['PRE_WIDTH']    = '150';        // width for the preview image

define('MODUL_ALBUM_IMG_CATEGORY', 'photoalbum_image_category');
define('MODUL_ALBUM_THUMB_HEIGHT', 'photoalbum_thumb_height_px');

$modul          = new Modul($MENU->getModulID());
$CAT_SERVICE    = new CategoryService();
$IMG_SERVICE    = new ImageService();
$projectService = new ItemProjectService(_BIGACE_ITEM_MENU);

$mode           = extractVar('mode', $_FOTOALBUM['MODE_LIST']);
$CUR_CAT        = null;

/* #########################################################################
 * ############################  Show Admin Link  ##########################
 * #########################################################################
 */
if ($modul->isModulAdmin())
{
    import('classes.util.links.ModulAdminLink');
    import('classes.util.LinkHelper');
    $mdl = new ModulAdminLink();
    $mdl->setItemID($MENU->getID());
    $mdl->setLanguageID($MENU->getLanguageID());

    ?>
    <script type="text/javascript">
    <!--
    function openAdmin()
    {
        fenster = open("<?php echo LinkHelper::getUrlFromCMSLink($mdl); ?>","ModulAdmin","menubar=no,toolbar=no,statusbar=no,directories=no,location=no,scrollbars=yes,resizable=no,height=350,width=400,screenX=0,screenY=0");
        bBreite=screen.width;
        bHoehe=screen.height;
        fenster.moveTo((bBreite-400)/2,(bHoehe-350)/2);
    }
    // -->
    </script>
    <?php

    echo '<div align="left"><a onClick="openAdmin(); return false;" href="'.LinkHelper::getUrlFromCMSLink($mdl).'"><img src="'.$GLOBALS['_BIGACE']['DIR']['public'].'system/images/preferences.gif" border="0" align="top"> '.getTranslation('album_admin').'</a></div>';
}

/* #########################################################################
 * ###########################  CHECK CONFIGURATION  #######################
 * #########################################################################
 */
if($projectService->existsProjectNum($MENU->getID(), $MENU->getLanguageID(), MODUL_ALBUM_IMG_CATEGORY))
{
    $CUR_CAT = $projectService->getProjectNum($MENU->getID(), $MENU->getLanguageID(), MODUL_ALBUM_IMG_CATEGORY);
	if($projectService->existsProjectNum($MENU->getID(), $MENU->getLanguageID(), MODUL_ALBUM_THUMB_HEIGHT)) {
		$temp = $projectService->getProjectNum($MENU->getID(), $MENU->getLanguageID(), MODUL_ALBUM_THUMB_HEIGHT);
		if($temp != 0)
    		$_FOTOALBUM['PRE_WIDTH'] = $temp;
	}
}
else
{
    echo '<br><b>'.getTranslation('album_unconfigured').'</b><br>';
}

/* #########################################################################
 * ###########################  Show selected image  #######################
 * #########################################################################
 */
if ($mode == $_FOTOALBUM['MODE_DETAIL'])
{
    $temp_image = $IMG_SERVICE->getClass( extractVar('imageid', _BIGACE_TOP_LEVEL) );

    $entry = '<center><img src="'.createCommandLink('image', $temp_image->getID(), array(), $temp_image->getOriginalName()).'" style="border-width:0px" alt="'.$temp_image->getName().'"></center>';
    $entry .= '<br>'.$temp_image->getDescription().'<br><br>';

    $config = array(
                    'width'         =>  '',
                    'align'         =>  array (
                                            'table'     => 'center',
                                            'left'      => 'left',
                                            'bottom'    => 'left'
                                        ),
                    'title'         =>  $temp_image->getName(),
                    'form_hide'     =>  true,
                    'entries'       =>  array(
                                            $entry => 'empty'
                                    ),
                    'submit_label'  =>  '<a href="'.createMenuLink($MENU->getID(), array('mode'=>$_FOTOALBUM['MODE_LIST'].'#image'.$temp_image->getID())).'" title="'.getTranslation('fotoalbum_showlist').'"><img src="'.$GLOBALS['_BIGACE']['DIR']['public'].'modul/images/fotoalbum_back.gif" border="0"> '.getTranslation('fotoalbum_showlist').'</a>',
    );
    echo '<br/>' . createTable($config);
}


/* #########################################################################
 * ##################  Show List of all categorized Images  ################
 * #########################################################################
 */
if ($mode != $_FOTOALBUM['MODE_DETAIL'] && $CUR_CAT != null)
{
    $search = $CAT_SERVICE->getItemsForCategory($IMG_SERVICE->getItemtype(), $CUR_CAT);

    ?>

    <p><?php echo $MENU->getContent(); ?></p>

    <?php

    if($search->count() > 0)
    {
        while ($search->hasNext())
        {
            $temp = $search->next();
            $temp_image = $IMG_SERVICE->getClass($temp['itemid']);

            ?>
            <div id="fotoalbumEntry">
            <table width="100%" cellpadding="2" cellspacing="2" align="center">
                <tr>
                    <td width="<?php echo $_FOTOALBUM['PRE_WIDTH']; ?>" align="center" valign="top" rowspan="2">
                        <img src="<?php echo createCommandLink('image', $temp_image->getID(), array('resize' => $_FOTOALBUM['PRE_WIDTH']), $temp_image->getOriginalName()); ?>" border="0" alt="<?php echo htmlspecialchars($temp_image->getDescription()); ?>" width="<?php echo $_FOTOALBUM['PRE_WIDTH']; ?>">
                    </td>
                    <td valign="top">
                        <table border="0" width="100%">
                        <tr><th align="center"><a href="<?php echo createMenuLink($GLOBALS['MENU']->getID(), array('mode' => $_FOTOALBUM['MODE_DETAIL'], 'imageid' => $temp_image->getID())); ?>" title="<?php echo getTranslation('fotoalbum_showpicture'); ?>"><?php echo $temp_image->getName(); ?></a></th></tr>
                        <tr><td><p><?php echo $temp_image->getDescription(); ?></p></td></tr>
                        </table>
                    </td>
                </tr>
                <tr>
                    <td valign="bottom" align="right">
                        <p><a href="<?php echo createMenuLink($GLOBALS['MENU']->getID(), array('mode' => $_FOTOALBUM['MODE_DETAIL'], 'imageid' => $temp_image->getID())); ?>" title="<?php echo getTranslation('fotoalbum_showpicture'); ?>"><?php echo getTranslation('fotoalbum_showpicture'); ?></a></p>
                    </td>
                </tr>
            </table>
            </div>
            <?php
        }
    }
    else
    {
        echo '<b>'.getTranslation('album_empty').'</b>';
    }
} // ($mode == $_FOTOALBUM['MODE_LIST'])


?>