<?php
/*
Plugin Name: Social Bookmarks
Plugin URI: http://wiki.bigace.de/bigace:extensions:addon:socialbookmark
Description: This plugins displays a beautyful social bookmark menu.
Author: Kevin Papst
Version: 0.3
Author URI: http://www.kevinpapst.de/
$Id: social-bookmark-menu.php,v 1.4 2009/11/19 22:52:49 kpapst Exp $
*/

if(!defined('_BIGACE_ID'))
    die('Ooops');

Hooks::add_action('social_bookmark_plugin', 'social_bookmark_version', 10, 1);
Hooks::add_action('smarty_tpl_header', 'social_bookmark_header', 10, 3);
Hooks::add_action('smarty_tpl_footer', 'social_bookmark_footer', 10, 3);

function social_bookmark_version()
{
    return "0.3";
}

function social_bookmark_header()
{
    echo '
    <link rel="stylesheet" href="'.BIGACE_URL_PLUGINS.'socialbookmark/social-bookmark-menu.css" type="text/css" media="screen, projection" >
    <!--[if IE]>
    <style type="text/css">
    ul.socials a {
    color:#fff; /* Change this color to match the background color the menu will be placed over */
    }
    </style>
    <![endif]-->
    <!--[if lt IE 7]>
    <script src="'.BIGACE_URL_PLUGINS.'socialbookmark/IE7.js" type="text/javascript"></script>
    <![endif]-->
    ';
}

function social_bookmark_footer($MENU)
{
	$url = urlencode(LinkHelper::itemUrl($MENU));
	$title = $MENU->getName();
    echo '
    <ul class="socials">
	    <li class="digg"><a target="_blank" rel="nofollow" href="http://digg.com/submit?phase=2&url='.$url.'&title='.$title.'" title="Digg this!"> </a></li>
	    <li class="reddit"><a target="_blank" rel="nofollow" href="http://reddit.com/submit?url='.$url.'&title='.$title.'" title="Share this on Reddit"> </a></li>
	    <li class="stumble"><a target="_blank" rel="nofollow" href="http://www.stumbleupon.com/submit?url='.$url.'&title='.$title.'" title="Stumble upon something good? Share it on StumbleUpon"> </a></li>
	    <li class="delicious"><a target="_blank" rel="nofollow" href="http://del.icio.us/post?url='.$url.'&title='.$title.'" title="Share this on del.icio.us"> </a></li>
	    <li class="technorati"><a target="_blank" rel="nofollow" href="http://technorati.com/faves?add='.$url.'" title="Share this on Technorati"> </a></li>
	    <li class="furl"><a target="_blank" rel="nofollow" href="http://www.furl.net/storeIt.jsp?t='.$title.'&u='.$url.'" title="Share this on Furl"> </a></li>
	    <li class="facebook"><a target="_blank" rel="nofollow" href="http://www.facebook.com/share.php?u='.$url.'&amp;t='.$title.'" title="Share this on Facebook"> </a></li>
	    <li class="myspace"><a target="_blank" rel="nofollow" href="http://www.myspace.com/Modules/PostTo/Pages/?u='.$url.'&amp;t='.$title.'" title="Post this to MySpace"> </a></li>
	    <li class="yahoo"><a target="_blank" rel="nofollow" href="http://myweb2.search.yahoo.com/myresults/bookmarklet?t='.$title.'&u='.$url.'" title="Save this to Yahoo MyWeb"> </a></li>
	    <li class="script-style"><a target="_blank" rel="nofollow" href="http://scriptandstyle.com/submit?url='.$url.'&title='.$title.'" title="Submit this to Script & Style"> </a></li>
	    <li class="blinklist"><a target="_blank" rel="nofollow" href="http://www.blinklist.com/index.php?Action=Blink/addblink.php&Url='.$url.'&Title='.$title.'" title="Share this on Blinklist"> </a></li>
	    <li class="mixx"><a target="_blank" rel="nofollow" href="http://www.mixx.com/submit?page_url='.$url.'&amp;title='.$title.'" title="Share this on Mixx"> </a></li>
	    <li class="designfloat"><a target="_blank" rel="nofollow" href="http://www.designfloat.com/submit.php?url='.$url.'&amp;title='.$title.'" title="Submit this to DesignFloat"> </a></li>
	</ul>
	<div class="socialclear">&nbsp;</div>
    ';
}
