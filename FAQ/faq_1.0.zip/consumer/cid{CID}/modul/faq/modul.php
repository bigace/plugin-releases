<?php
/**
 * Copyright (C) Kevin Papst. 
 *
 * For further information go to http://www.bigace.de/ 
 *
 * @version $Id: modul.php,v 1.2 2008/08/11 14:54:49 kpapst Exp $
 * @author Kevin Papst 
 * @package bigace.modul
 */

import('classes.modul.ModulService');
import('classes.modul.Modul');

define('FAQ_SEC_DEFAULT', '1');

$modulService = new ModulService();
$modul = new Modul($MENU->getModulID());
$config = $modulService->getModulProperties($MENU, $modul, array());

$tplName = (isset($config['faq_template']) && strlen(trim($config['faq_template'])) > 0) ? trim($config['faq_template']) : "FAQ-Default";
$adminUrl = null;

/* #########################################################################
 * ############################  Show Admin Link  ##########################
 * #########################################################################
 */
if ($modul->isModulAdmin())
{
    import('classes.util.links.ModulAdminLink');
    import('classes.util.LinkHelper');
    $mdl = new ModulAdminLink();
    $mdl->setItemID($MENU->getID());
    $mdl->setLanguageID($MENU->getLanguageID());
	$adminUrl = LinkHelper::getUrlFromCMSLink($mdl);
}

$section = isset($config['faq_section']) ? $config['faq_section'] : FAQ_SEC_DEFAULT;
if(isset($config['faq_get_param']) && strlen(trim($config['faq_get_param'])) > 0 && isset($_GET[$config['faq_get_param']])) {
	$section = $_GET[$config['faq_get_param']];
}

// if we are not in a smarty context, create it
if(!isset($smarty))
{
	import('classes.smarty.SmartyDesign');
	import('classes.smarty.BigaceSmarty');
	$smarty = BigaceSmarty::getSmarty();
}

$smarty->assign('MENU', 	 $MENU);
$smarty->assign('CONFIG', 	 $config);
$smarty->assign('ADMIN_URL', $adminUrl);

$tpl = new SmartyTemplate($tplName); 
$smarty->assign("SECTION", $section);
$smarty->display( $tpl->getFilename() );

?>