<?php

/*
 * Parameter:
 * =============
 * - assign
 * 
 * - order (ASC, DESC)
 * - orderBy (name, amount, id)
 */
function smarty_function_faq_sections($params, &$smarty)
{	
	if(!isset($params['assign'])) {
		$smarty->trigger_error("faq_sections: missing 'assign' attribute");
		return;
	}
	
	$order = (isset($params['order']) && strtolower($params['order']) == 'desc' ? 'DESC' : 'ASC');
	$orderBy = (isset($params['orderBy']) && ($params['orderBy'] == 'name' || $params['orderBy'] == 'amount') ? $params['orderBy'] : 'id');
	
    $sqlString = "SELECT sections.*, count(mappings.cid) as amount FROM {DB_PREFIX}faq_sections sections 
    				LEFT JOIN {DB_PREFIX}faq_mappings mappings ON
    					sections.id = mappings.section_id
    				AND
    					sections.cid = mappings.cid
    				WHERE 
    					sections.cid = {CID}
					GROUP BY sections.id ORDER BY sections." . $orderBy . " " . $order;
    $replacer = array(
		'ORDER'		=> $order,
		'ORDER_BY'	=> $orderBy
    );
		
    $sqlString = $GLOBALS['_BIGACE']['SQL_HELPER']->prepareStatement($sqlString, $replacer, true);
    $res = $GLOBALS['_BIGACE']['SQL_HELPER']->execute($sqlString);
	
    $results = array();
    for($i=0; $i < $res->count(); $i++) {
    	$results[] = $res->next();
    }
    $smarty->assign($params['assign'], $results);
    return;
}
?>