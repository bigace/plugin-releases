<?php

/*
 * Parameter:
 * =============
 * - assign
 * - id
 */
function smarty_function_faq_section($params, &$smarty)
{	
	if(!isset($params['assign'])) {
		$smarty->trigger_error("faq_section: missing 'assign' attribute");
		return;
	}
	if(!isset($params['id'])) {
		$smarty->trigger_error("faq_section: missing 'id' attribute");
		return;
	}
    $sqlString = "SELECT * FROM {DB_PREFIX}faq_sections sections WHERE 
    					sections.cid = {CID} AND sections.id = {SECTION}";
    $sqlString = $GLOBALS['_BIGACE']['SQL_HELPER']->prepareStatement($sqlString, array( 'SECTION' => $params['id'] ), true);
    $res = $GLOBALS['_BIGACE']['SQL_HELPER']->execute($sqlString);
	
    $results = null;
    if($res->count() > 0) {
    	$results = $res->next();
    }
    $smarty->assign($params['assign'], $results);
    return;
}
?>