<?php

/*
 * Parameter:
 * =============
 * - assign
 * - section
 * 
 * - order (ASC, DESC)
 * - orderBy (id, name, timestamp)
 * - start
 * - end
 */
function smarty_function_faq_entries($params, &$smarty)
{	
	if(!isset($params['assign'])) {
		$smarty->trigger_error("faq_entries: missing 'assign' attribute");
		return;
	}
	if(!isset($params['section'])) {
		$smarty->trigger_error("faq_entries: missing 'section' attribute");
		return;
	}
	
	$order = (isset($params['order']) && strtolower($params['order']) == 'desc' ? 'DESC' : 'ASC');
	$orderBy = (isset($params['orderBy']) && ($params['orderBy'] == 'timestamp' || $params['orderBy'] == 'name') ? $params['orderBy'] : 'id');
	$orderBy = (isset($params['orderBy']) ? $params['orderBy'] : 'id');
	$start = (isset($params['start']) ? $params['start'] : null);
	$end = (isset($params['end']) ? $params['end'] : null);
	
    $sqlString = "SELECT * FROM {DB_PREFIX}faq_entries entries 
    				LEFT JOIN {DB_PREFIX}faq_mappings mappings ON
    				entries.id = mappings.entry_id
    				AND
    				entries.cid = mappings.cid 
    				WHERE 
    				entries.cid = {CID}
    				AND 
    				mappings.section_id = {SECTION} 
	";
    $sqlString .= " ORDER BY entries." . $orderBy . " " . $order;
    if(!is_null($start) && !is_null($end)) {
    	$sqlString .= " LIMIT {START}, {END}";
    }
    $replacer = array(
    	'SECTION' 	=> $params['section'], 
		'START'		=> intval($start),
		'END'		=> intval($end),
		'ORDER'		=> $order,
		'ORDER_BY'	=> $orderBy
    );
		
    $sqlString = $GLOBALS['_BIGACE']['SQL_HELPER']->prepareStatement($sqlString, $replacer, true);
    $res = $GLOBALS['_BIGACE']['SQL_HELPER']->execute($sqlString);
	
    $results = array();
    for($i=0; $i < $res->count(); $i++) {
    	$results[] = $res->next();
    }
    $smarty->assign($params['assign'], $results);
    return;
}
?>