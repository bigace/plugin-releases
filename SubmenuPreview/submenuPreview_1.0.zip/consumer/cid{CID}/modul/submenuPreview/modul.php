<?php
/*
* Displays a Preview of all SubMenus
*
* Copyright (C) Kevin Papst. 
*
* For further information go to http://www.bigace.de/ 
*
* @version $Id: modul.php,v 1.5 2007/05/04 20:52:15 kpapst Exp $
* @author Kevin Papst 
* @package bigace.modul
*/

	import('classes.menu.MenuService');
	$mService = new MenuService(); 
    echo $GLOBALS['MENU']->getContent();
    
    echo '<div id="preview">';

    $menus = $mService->getLightTreeForLanguage($GLOBALS['MENU']->getID(), $GLOBALS['_BIGACE']['SESSION']->getLanguageID());

    for ($i=0; $i < $menus->count(); $i++) 
    {
        $temp_menu = $menus->next();
        echo '<div id="nextLevelPreview"><h2>';
        echo '<a href="'.createMenuLink( $temp_menu->getID() ).'" title="'.getTranslation('list_link_title').'">';
        echo $temp_menu->getName();
        echo '</a></h2><p>';
        echo $temp_menu->getDescription() . ' <a href="'.createMenuLink( $temp_menu->getID() ).'" title="'.getTranslation('list_link_title').'"><img border="0" src="'.$GLOBALS['_BIGACE']['DIR']['public'].'modul/images/3arrows.gif" alt="'.getTranslation('list_img_alt').'"></a>';
        echo '</p></div><br />';
    }

	echo '</div>';
	
	unset($meService);
	
?>