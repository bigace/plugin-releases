<?php
/**
* Translation file for Modul - Preview Submenu
*
* Language: deutsch (default)
* Locale:   de
*
* Copyright (C) Kevin Papst. 
*
* For further information go to http://www.bigace.de/ 
*
* @version $Id: translation.lang.php,v 1.3 2006/11/26 21:58:50 kpapst Exp $
* @author Kevin Papst 
* @package bigace.translation
*/

$LANG['list_img_alt']        = 'Lesen Sie mehr';
$LANG['list_link_title']     = 'Link zur Seite';
$LANG['sitemap_title']       = 'Seite&nbsp;anzeigen';

?>