<?php
/**
* Translation file for Modul - Submenu Preview
*
* Language: deutsch (default)
* Locale:   de
*
* Copyright (C) Kevin Papst. 
*
* For further information go to http://www.kevinpapst.de/ 
*
* @version $Id: modul.lang.php,v 1.4 2006/11/26 21:58:50 kpapst Exp $
* @author Kevin Papst 
* @package bigace.translation
*/

$LANG['name']    		= 'Seiten &Uuml;bersicht';
$LANG['title']    		= 'Seiten &Uuml;bersicht';
$LANG['description']  	= 'Hiermit k&ouml;nnen Sie eine &Uuml;bersicht aller Kinder der aktuellen Seite anzeigen.';

?>