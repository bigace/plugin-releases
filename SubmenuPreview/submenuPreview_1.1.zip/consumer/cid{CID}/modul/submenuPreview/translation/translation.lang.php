<?php
/**
* Translation file for Modul - Preview Submenu
*
* Language: deutsch (default)
* Locale:   de
*
* Copyright (C) Kevin Papst. 
*
* For further information go to http://www.bigace.de/ 
*
* @version $Id: translation.lang.php,v 1.4 2008/03/09 00:41:06 kpapst Exp $
* @author Kevin Papst 
* @package bigace.translation
*/

$LANG['empty_description']   = 'Lesen Sie weiter';
$LANG['list_img_alt']        = 'Lesen Sie mehr';
$LANG['list_link_title']     = 'Link zu: ';
$LANG['modul_admin_link']    = 'Einstellungen';

?>