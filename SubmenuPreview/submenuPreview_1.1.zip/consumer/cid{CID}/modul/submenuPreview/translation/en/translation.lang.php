<?php
/**
* Translation file for Modul - Preview Submenu
*
* Language: english
* Locale:   en
*
* Copyright (C) Kevin Papst. 
*
* For further information go to http://www.bigace.de/ 
*
* @version $Id: translation.lang.php,v 1.4 2008/03/09 00:41:05 kpapst Exp $
* @author Kevin Papst 
* @package bigace.translation
*/

$LANG['empty_description']   = 'Read more about it';
$LANG['list_img_alt']        = 'Read more';
$LANG['list_link_title']     = 'Link to: ';
$LANG['modul_admin_link']    = 'Configure settings';


?>