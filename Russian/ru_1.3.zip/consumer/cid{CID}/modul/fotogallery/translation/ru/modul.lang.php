<?php
/**
* Modul Translation file 
*
* Language: russian
* Locale:   ru
*
* Copyright (C) Kevin Papst. 
*
* For further information go to http://www.bigace.de/ 
*
* @version $Id: modul.lang.php 47 2011-04-22 10:54:10Z oleg $
* @author $Author: oleg $ 
* @package bigace.translation
*/

$LANG['name']    		= 'Фотогалерея';
$LANG['title']    		= 'Простая фотогалерея';
$LANG['description']  	= 'Скрипт для отображения простой фотогалереи. Создает список из изображений объединенных в одну категорию.';

?>