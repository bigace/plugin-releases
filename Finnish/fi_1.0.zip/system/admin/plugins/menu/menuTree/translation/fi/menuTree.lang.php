<?php
/**
* Translation file for Administration - MenuTree
*
* Language: Finnish
* Locale:   fi

*/

$LANG['title_menuTree']        = 'Valikko Hallinto';
$LANG['description_menuTree']  = 'Valikkojen hallinto. Voit luoda sivuja, muokata niiden asetuksia ja sis�lt��, muokata oikeuksia ja kategoria linkkej�, tarkistaa ja palauttaa edellisi� versioita sek� poistaa sivuja.';

// title of main tab
$LANG['tree_tab_title']        = 'Valikko rakenne';

// top menu
$LANG['tree_action_focusOnSelect']  = 'Merkitse kun valitaan';
$LANG['tree_action_focusOnOpen']    = 'Merkitse kun avataan';
$LANG['tree_action_openOnSelect']   = 'Avaa kun valitaan';
// action buttons
$LANG['tree_action_reloadTree']     = 'P�ivit� valikko-rakenne';
$LANG['tree_action_reInsert']       = 'Lis�� valikko alkuper�iseen paikkaan';
$LANG['tree_action_expandAll']      = 'Avaa kaikki n�kyv�t valikko-kansiot';
$LANG['tree_action_Cut']            = '<b>Leikkaa Valikko</b><br/>(ei poisteta)';
$LANG['tree_action_Copy']           = '<b>Kopioi Valikko</b>';
$LANG['tree_action_Paste']          = '<b>Liit� Valikko</b><br/>(lis�t��n valitun alle)';

// item menu
$LANG['item_action_newpage_same']   = 'Luo sivu samalla tasolla';
$LANG['item_action_newpage_below']  = 'Luo sivu alle';
$LANG['item_languages']             = 'Kieli';
$LANG['item_reorder_childs']        = 'Lajittele alavalikkoja';

$LANG['item_state_hidden']          = 'Piilotettu';
$LANG['item_state_workflow']        = 'Ty�virrassa';

$LANG['item_not_loaded']            = 'Sivua ei voinut ladata!';

// reorder pages
$LANG['sort_tab_title']        = 'Lajittele valikkoja';
$LANG['sort_childs_of']        = 'Vaihda alla olevien sivujen sijaintia';
$LANG['sort_button']           = 'Tallenna';

// delete pages
$LANG['confirm_delete_node']   = 'Haluatko todella poistaa t�m�n valikon: ';
$LANG['confirm_delete_tree']   = 'Jos poistat t�m�n valikon, my�s ala-valikot poistetaan!';

?>