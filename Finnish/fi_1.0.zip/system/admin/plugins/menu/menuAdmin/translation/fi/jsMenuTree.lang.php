<?php
/**
* Translation file for Menu Administration JS Tree
*
* Locale: fi
*
*/

$LANG['title_menuAdminNavi']        = 'Valikot';
$LANG['description_menuAdminNavi']  = 'Sivujen hallinto.';

// action buttons
$LANG['tree_action_openOnSelect']   = 'Avaa valikko-hallinto valitsemalla.';
$LANG['tree_action_reloadTree']     = 'P�ivit� valikko-rakenne';
$LANG['tree_action_reInsert']       = 'Lis�� valikko alkuper�iseen paikkaan';
$LANG['tree_action_expandAll']      = 'Avaa kaikki n�kyv�t valikko-kansiot';
$LANG['tree_action_Cut']            = '<b>Leikkaa Valikko</b><br/>(ei poisteta)';
$LANG['tree_action_Copy']           = '<b>Kopioi Valikko</b>';
$LANG['tree_action_Paste']          = '<b>Liit� Valikko</b><br/>(lis�t��n valitun alle)';

// item menu
$LANG['item_action_newpage_same']   = 'Luo sivu samalla tasolla';
$LANG['item_action_newpage_below']  = 'Luo sivu alle';
$LANG['item_languages']             = 'Kieli';
$LANG['item_reorder_childs']        = 'Lajittele alavalikkoja';

$LANG['item_state_hidden']          = 'Piilotettu';
$LANG['item_state_workflow']        = 'Ty�virrassa';

$LANG['item_not_loaded']            = 'Sivua ei voinut ladata!';

// editor
$LANG['edit_content']            	= 'Muokkaa sivun sis�lt��';

// delete pages
$LANG['confirm_delete_node']   = 'Haluatko todella poistaa t�m�n valikon: ';
$LANG['confirm_delete_tree']   = 'Jos poistat t�m�n valikon, my�s ala-valikot poistetaan!';
