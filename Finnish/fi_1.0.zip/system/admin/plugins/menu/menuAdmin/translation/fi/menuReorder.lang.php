<?php
/**
* Translation file for Administration - MenuReorder
*
* Language: Finnish
* Locale:   fi
*

*/


$LANG['title_menuReorder']        = 'Vaihda valikkoj�rjestys';
$LANG['description_menuReorder']  = 'Vaihda valitun sivun kaikkien ala-valikkojen sijainti.';

// reorder pages
$LANG['sort_tab_title']        = 'Lajittele valikkoja';
$LANG['sort_childs_of']        = 'Vaihda alla olevien sivujen sijainti';
$LANG['sort_button']           = 'Tallenna';

