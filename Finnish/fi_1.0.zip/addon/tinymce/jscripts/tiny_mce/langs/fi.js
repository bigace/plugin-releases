tinyMCE.addI18n({fi:{
common:{
edit_confirm:"Haluatko k�ytt�� WYSIWYG toimintoja t�lle tekstialueelle?",
apply:"K�yt�",
insert:"Tallenna",
update:"P�ivit�",
cancel:"Keskeyt�",
close:"Sulje",
browse:"Selaa",
class_name:"Luokka",
not_set:"-- Ei asetettu --",
clipboard_msg:"Kopioi/Leikkaa/Liit� ei ole k�ytett�viss� Mozilla ja Firefox selaimissa.\nHaluatko saada lis�� tietoa t�st� asiasta?",
clipboard_no_support:"T�ll� hetkell� selaimesi ei tue t�t� toimintoa, k�yt� n�pp�imist�n saatavilla olevia oikotietoimintoja.",
popup_blocked:"Olemme pahoillamme, mutta huomasimme ett� selaimesi on est�nyt ponnahdusikkunan joka sis�lt�� ohjelmatoimintoja. Hy�dynt��ksesi t�m�n ty�kalun kaikkia toimintoja, sinun on m��ritelt�v� ett� selaimesi sallii ponnahdusikkunoita t�ll� sivustolla.",
invalid_data:"Virhe: Virheellisi� arvoja sy�tetty, n�m� ovat merkitty punaisella.",
more_colors:"Lis�� v�rej�"
},
contextmenu:{
align:"Sijoitus",
left:"Vasen",
center:"Keskitetty",
right:"Oikea",
full:"Kokosivu"
},
insertdatetime:{
date_fmt:"%Y-%m-%d",
time_fmt:"%H:%M:%S",
insertdate_desc:"Lis�� p�iv�m��r�",
inserttime_desc:"Lis�� aika",
months_long:"Tammikuu,Helmikuu,Maaliskuu,Huhtikuu,Toukokuu,Kes�kuu,Hein�kuu,Elokuu,Syyskuu,Lokakuu,Marraskuu,Joulukuu",
months_short:"Tammi,Helmi,Maalis,Huhti,Touko,Kes�,Hein�,Elo,Syys,Loka,Marras,Joulu",
day_long:"Sunnuntai,Maanantai,Tiistai,Keskiviikko,Torstai,Perjantai,Lauantai",
day_short:"Su,Ma,Ti,Ke,To,Pe,La,Su"
},
print:{
print_desc:"Tulosta"
},
preview:{
preview_desc:"Esikatselu"
},
directionality:{
ltr_desc:"Suunta vasemmalta oikeaan",
rtl_desc:"Suunta oikealta vasempaan"
},
layer:{
insertlayer_desc:"Lis�� uusi taso",
forward_desc:"Siirr� eteenp�in",
backward_desc:"Siirr� taakse",
absolute_desc:"Toggle absolute positioning",
content:"Uusi taso..."
},
save:{
save_desc:"Tallenna",
cancel_desc:"Peruuta kaikki muutokset"
},
nonbreaking:{
nonbreaking_desc:"Insert non-breaking space character"
},
iespell:{
iespell_desc:"Run spell checking",
download:"ieSpell ei havaitu. Haluatko asentaa sen nyt?"
},
advhr:{
advhr_desc:"Horizontale rule"
},
emotions:{
emotions_desc:"Emotions"
},
searchreplace:{
search_desc:"Etsi",
replace_desc:"Etsi/Korvaa"
},
advimage:{
image_desc:"Lis��/Muokkaa kuva"
},
advlink:{
link_desc:"Lis��/Muokkaa linkki"
},
xhtmlxtras:{
cite_desc:"Lainaus",
abbr_desc:"Lyhenne",
acronym_desc:"Acronym",
del_desc:"Poista merkki",
ins_desc:"Lis�� merkki",
attribs_desc:"Lis�ys/Muokkaus Attribuutit"
},
style:{
desc:"Muokkaa CSS tyyli�"
},
paste:{
paste_text_desc:"Liit� tekstin�",
paste_word_desc:"Liit� Word:ist�",
selectall_desc:"Valitse kaikki"
},
paste_dlg:{
text_title:"K�yt� n�pp�imist�si CTRL+V liitt��ksesi teksti ikkunaan.",
text_linebreaks:"Keep linebreaks",
word_title:"K�yt� n�pp�imist�si CTRL+V liitt��ksesi teksti ikkunaan."
},
table:{
desc:"Lis�� uusi taulukko",
row_before_desc:"Lis�� rivi eteen",
row_after_desc:"Lis�� rivi j�lkeen",
delete_row_desc:"Poista rivi",
col_before_desc:"Lis�� sarake eteen",
col_after_desc:"Lis�� sarake j�lkeen",
delete_col_desc:"Poista sarake",
split_cells_desc:"Erota yhdistetyt taulukkosolut",
merge_cells_desc:"Yhdist� taulukkosolut",
row_desc:"Taulukkorivi-ominaisuudet",
cell_desc:"Taulukkosolu-ominaisuudet",
props_desc:"Taulukko-ominaisuudet",
paste_row_before_desc:"Liit� taulukkorivi eteen",
paste_row_after_desc:"Liit� taulukkorivi j�lkeen",
cut_row_desc:"Leikkaa taulukkorivi",
copy_row_desc:"Kopioi taulukkorivi",
del:"Poista taulukko",
row:"Rivi",
col:"Sarake",
cell:"Solu"
},
autosave:{
unload_msg:"Tekem�si muutokset h�vi�v�t jos vaihdat sivua."
},
fullscreen:{
desc:"Vaihda kokoruutu tilaa"
},
media:{
desc:"Insert / edit embedded media",
edit:"Edit embedded media"
},
fullpage:{
desc:"Asiakirja-ominaisuudet"
},
template:{
desc:"Hae sis�lt� tallennetusta mallista"
},
visualchars:{
desc:"Visual control characters on/off."
},
spellchecker:{
desc:"Toggle spellchecker",
menu:"Spellchecker settings",
ignore_word:"Ignore word",
ignore_words:"Ignore all",
langs:"Kielet",
wait:"Ole hyv� odota...",
sug:"Ehdotukset",
no_sug:"Ei ehdotuksia",
no_mpell:"No misspellings found."
},
pagebreak:{
desc:"Lis�� sivutus."
}}});