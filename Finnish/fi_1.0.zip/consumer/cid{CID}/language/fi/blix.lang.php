<?php

$LANG['written_at'] = 'Viimeksi p�ivitetty:';
$LANG['written_by'] = '';
$LANG['search_button'] = 'Hae!';
$LANG['empty_searchterm'] = 'Sy�t� hakutermi, v�hint��n 4 merkki�!';
$LANG['short_searchterm'] = 'Hakutermi on liian lyhyt, k�yt� v�hint��n 4 merkki�!';

?>