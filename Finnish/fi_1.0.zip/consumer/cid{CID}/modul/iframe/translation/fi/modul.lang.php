<?php
/**
* Modul Translation file
*
* Language: finnish
* Locale:   fi

*/

$LANG['name']    		= 'IFrame';
$LANG['title']    		= 'N�yt� IFrame';
$LANG['description']  	= 'Toiminto jolla n�yt�t IFrame:n normaalin sivusis�ll�n alla.';

$LANG['unconfigured']   = "T�m� moduuli ei ole viel� konfiguroitu. Ota yhteytt� p��k�ytt�j��n.";
$LANG['admin']          = "Konfiguroi IFrame";

?>