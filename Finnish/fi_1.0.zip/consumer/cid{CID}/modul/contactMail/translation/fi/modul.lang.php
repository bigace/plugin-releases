<?php
/**
* Translation file for Modul - Contact Mail
* Language: finnish
* Locale:   fi
*
*/

$LANG['name']		    = 'Yhteyslomake';
$LANG['title']		    = 'Ota yhteytt�';                                                            
$LANG['description']	= 'L�het� yhdelle tai monelle vastaanottajalle viesti.';

?>