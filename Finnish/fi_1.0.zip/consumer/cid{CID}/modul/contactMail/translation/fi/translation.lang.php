<?php
/**
* Translation file for Modul - Contact Mail
*
* Language: finnish
* Locale:   fi
*

*/

$LANG['initial_message']    = '';
$LANG['initial_subject']    = '';
$LANG['create_new_msg']     = 'Luo uusi s�hk�postiviesti';
$LANG['contact_error_msg']  = '<p><b>Virhe!</b></p><p>Viestisi ei voitu l�hett��.<br>Yrit� uudelleen!<br>Kiitos</p>';
$LANG['error_retry']        = 'Virhe.. yrit� uudelleen...';
$LANG['form_message']       = 'Viestisi';
$LANG['form_subject']       = 'Aihe';
$LANG['form_email']         = 'S�hk�posti-osoitteesi';
$LANG['form_name']          = 'Nimesi';
$LANG['form_send']          = 'L�het�';
$LANG['form_title']         = 'Kirjoita viesti:';
$LANG['missing_values']     = 'Ole hyv� t�yt� pakolliset viestit.';
$LANG['required']           = 'Pakolliset viestit';
$LANG['unconfigured']       = 'T�m� moduuli ei ole viel� konfiguroitu.. Ota yhteytt� p��k�ytt�j��n.';
$LANG['email_intro']        = 'T�m� viesti l�hetetettiin sinulle BIGACE Webmail Lomakkeella.';
$LANG['email_sent']     	= 'Viestisi on l�hetetty.';

?>