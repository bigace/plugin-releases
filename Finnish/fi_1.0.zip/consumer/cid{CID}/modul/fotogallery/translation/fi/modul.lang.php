<?php
/**
* Modul Translation file 
*
* Language: finnish
* Locale:   fi
*
*/

$LANG['name']    		= 'Kuva-Galleria';
$LANG['title']    		= 'Yksinkertainen Kuva-Galleria';
$LANG['description']  	= 'Toiminto jolla n�yt�t yksinkertaisen kuva-gallerian sivustollasi. Luo lista valitsemalla kategoriasta kohde.';

?>