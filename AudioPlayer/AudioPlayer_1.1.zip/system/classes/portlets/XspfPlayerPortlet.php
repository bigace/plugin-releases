<?php
/**
 * BIGACE - a PHP and MySQL based Web CMS.
 * Copyright (C) Kevin Papst.
 *
 * BIGACE is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * BIGACE is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software Foundation,
 * Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 *
 * For further information visit {@link http://www.bigace.de http://www.bigace.de}.
 *
 * @author Oleg Selin 
 */

import('api.portlet.TranslatedPortlet');
import('classes.item.Item');
import('classes.item.ItemEnumeration');

class XspfPlayerPortlet extends TranslatedPortlet
{
    function XspfPlayerPortlet()
    {
        $this->loadBundle('xspfplayerportlet');
        $this->setParameter( 'slim', false );
        $this->setParameter( 'width', '400' );
        $this->setParameter( 'xspftitle', 'My music' );
        $this->setParameter( 'playlist_url', '' );
    }

    function getTitle()
    {
        return $this->getTranslation('title', 'Audio Player');
    }

    function getIdentifier()
    {
        return 'XspfPlayerPortlet';
    }

    function getHtml()
    {
        if ($this->getParameter('slim')){
            $html = '<object classid="clsid:d27cdb6e-ae6d-11cf-96b8-444553540000" codebase="http://fpdownload.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=7,0,0,0" width="'.$this->getParameter('width').'"height="15" id="xspf_player" align="middle">
            <param name="allowScriptAccess" value="sameDomain" />
            <param name="movie" value="'._BIGACE_DIR_PUBLIC_WEB.'cid'._CID_.'/xspf_player/xspf_player_slim.swf?playlist_url='.$this->getPlaylistURL().'&xn_auth=no&autoload=true" />
            <param name="quality" value="high" />
            <param name="bgcolor" value="#e6e6e6" />
            <embed src="'._BIGACE_DIR_PUBLIC_WEB.'cid'._CID_.'/xspf_player/xspf_player_slim.swf?playlist_url='.$this->getPlaylistURL().'&xn_auth=no&autoload=true" quality="high" bgcolor="#e6e6e6" width="'.$this->getParameter('width').'"height="15" name="xspf_player" align="middle" allowScriptAccess="sameDomain" type="application/x-shockwave-flash" pluginspage="http://www.macromedia.com/go/getflashplayer" />
            </object>';
        } else {
            $html = '<object classid="clsid:d27cdb6e-ae6d-11cf-96b8-444553540000" codebase="http://fpdownload.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=7,0,0,0" width="'.$this->getParameter('width').'" id="xspf_player" align="middle">
            <param name="allowScriptAccess" value="sameDomain" />
            <param name="movie" value="'._BIGACE_DIR_PUBLIC_WEB.'cid'._CID_.'/xspf_player/xspf_player.swf?playlist_url='.$this->getPlaylistURL().'&xn_auth=no&autoload=true" />
            <param name="quality" value="high" />
            <param name="bgcolor" value="#e6e6e6" />
            <embed src="'._BIGACE_DIR_PUBLIC_WEB.'cid'._CID_.'/xspf_player/xspf_player.swf?playlist_url='.$this->getPlaylistURL().'&xn_auth=no&autoload=true" quality="high" bgcolor="#e6e6e6" width="'.$this->getParameter('width').'" name="xspf_player" align="middle" allowScriptAccess="sameDomain" type="application/x-shockwave-flash" pluginspage="http://www.macromedia.com/go/getflashplayer" />
            </object>';
        }
        return $html;
    }

    function getParameterType($key)
    {
        switch($key) {
            case 'slim':
                return PORTLET_TYPE_BOOLEAN;
            default:
                return PORTLET_TYPE_STRING;
        }
    }
 
    function getParameterName($key) {
        switch($key) {
            case 'slim':
                return $this->getTranslation('slim', 'Use slim interface');
            case 'width':
                return $this->getTranslation('width', 'Set player width');
            case 'xspftitle':
                return $this->getTranslation('xspftitle', 'Set playlist title');
            case 'playlist_url':
                return $this->getTranslation('playlist_url', 'XSPF playlist URL (without http://)');
        }
    }

    function getPlaylistURL()
    {
        if (trim(strlen($this->getParameter('playlist_url'))) > 0) {
            $url = trim($this->getParameter('playlist_url'));
            if (stripos($url, 'http://') === false)
                $url = 'http://' . $url;
            return $url;
        }
        
        $link = new CMSLink();
        $link->setCommand('audioplayer');
        $link->setItemID('0');
        $link->setFilename('playlist.xspf');
        $link->addParameter('title', urlencode($this->getParameter('xspftitle')));
        
        return LinkHelper::getUrlFromCMSLink($link);
    }

    // Transliteration needed for player coz lack of russian symbols support
    function ru2Lat($str)
    {
        $tr = array("А"=>"A","Б"=>"B","В"=>"V","Г"=>"G",
            "Д"=>"D","Е"=>"E","Ж"=>"J","З"=>"Z","И"=>"I",
            "Й"=>"Y","К"=>"K","Л"=>"L","М"=>"M","Н"=>"N",
            "О"=>"O","П"=>"P","Р"=>"R","С"=>"S","Т"=>"T",
            "У"=>"U","Ф"=>"F","Х"=>"H","Ц"=>"TS","Ч"=>"CH",
            "Ш"=>"SH","Щ"=>"SCH","Ъ"=>"","Ы"=>"YI","Ь"=>"",
            "Э"=>"E","Ю"=>"YU","Я"=>"YA","а"=>"a","б"=>"b",
            "в"=>"v","г"=>"g","д"=>"d","е"=>"e","ж"=>"j",
            "з"=>"z","и"=>"i","й"=>"y","к"=>"k","л"=>"l",
            "м"=>"m","н"=>"n","о"=>"o","п"=>"p","р"=>"r",
            "с"=>"s","т"=>"t","у"=>"u","ф"=>"f","х"=>"h",
            "ц"=>"ts","ч"=>"ch","ш"=>"sh","щ"=>"sch","ъ"=>"y",
            "ы"=>"yi","ь"=>"","э"=>"e","ю"=>"yu","я"=>"ya");
        return strtr($str,$tr);
    }
}
