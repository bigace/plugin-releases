<?php
/**
* Translation file for Modul - Contact Mail
*
* Language: deutsch (default)
* Locale:   de
*
* Copyright (C) Kevin Papst. 
*
* For further information go to http://www.bigace.de/ 
*
* @version $Id: translation.lang.php,v 1.4 2008/03/14 00:35:33 kpapst Exp $
* @author Kevin Papst 
* @package bigace.translation
*/

$LANG['initial_message']    = '';
$LANG['initial_subject']    = '';
$LANG['contact_error_msg']  = '<p><b>Fehler!</b></p><p>Entschuldigen Sie, Ihre Email konnte leider nicht versendet werden.<br>Bitte versuchen Sie es erneut.<br>Vielen Dank f&uuml;r Ihr Verst&auml;ndniss!</p>';
$LANG['error_retry']        = 'Bitte versuchen Sie den Versand erneut...';
$LANG['form_message']       = 'Nachricht';
$LANG['form_subject']       = 'Betreff';
$LANG['form_email']         = 'Ihre Email Adresse';
$LANG['form_name']          = 'Name';
$LANG['form_send']          = 'Versenden';
$LANG['form_title']         = 'Nachricht verfassen:';
$LANG['missing_values']     = 'Bitte erg&auml;nzen Sie die fehlenden Daten.';
$LANG['required']           = ' Pflichtfelder m&uuml;ssen ausgef&uuml;llt werden!';
$LANG['unconfigured']       = 'Dieses Modul ist nicht vollst&auml;ndig konfiguriert. Bitte kontaktieren Sie Ihren Administrator.';
$LANG['email_intro']        = 'Die folgende Nachricht wurde Ihnen mit dem BIGACE Webmail Formular zugesandt.';
$LANG['email_sent']     	= 'Ihre Email wurde erfolgreich versendet.';

?>