<?php
/**
* Translation file for Modul - Contact Mail
* Language: deutsch
* Locale:   de
*
* Copyright (C) Kevin Papst. 
*
* For further information go to http://www.bigace.de/ 
*
* @version $Id: modul.lang.php,v 1.4 2006/11/26 21:58:51 kpapst Exp $
* @author Kevin Papst 
*/

$LANG['name']		    = 'Send contact email';
$LANG['title']		    = 'Send us a Message';                                                            
$LANG['description']	= 'Leave a message for one or more configured Recipients.';

?>