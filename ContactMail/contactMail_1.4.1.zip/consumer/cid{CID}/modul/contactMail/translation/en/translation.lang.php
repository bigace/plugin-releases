<?php
/**
* Translation file for Modul - Contact Mail
*
* Language: english
* Locale:   en
*
* Copyright (C) Kevin Papst. 
*
* For further information go to http://www.bigace.de/ 
*
* @version $Id: translation.lang.php,v 1.3 2008/03/14 00:32:59 kpapst Exp $
* @author Kevin Papst 
* @package bigace.translation
*/

$LANG['initial_message']    = '';
$LANG['initial_subject']    = '';
$LANG['create_new_msg']     = 'Create new eMail';
$LANG['contact_error_msg']  = '<p><b>Error!</b></p><p>Sorry, your Email could not be delivered.<br>Please try again to send your message!<br>Thank you</p>';
$LANG['error_retry']        = 'Please retry to send...';
$LANG['form_message']       = 'Message';
$LANG['form_subject']       = 'Subject';
$LANG['form_email']         = 'Your Email adress';
$LANG['form_name']          = 'Your Name';
$LANG['form_send']          = 'Send';
$LANG['form_title']         = 'Compose Email:';
$LANG['missing_values']     = 'Please fill out the required fields.';
$LANG['required']           = ' Mandatory fields';
$LANG['unconfigured']       = 'This module is not properly configured. Please contact your Administrator.';
$LANG['email_intro']        = 'The following message is sent to you with the BIGACE Webmail Formular.';
$LANG['email_sent']     	= 'Your email was successful delivered.';

?>