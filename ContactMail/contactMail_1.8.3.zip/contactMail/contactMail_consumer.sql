INSERT INTO {DB_PREFIX}frights (cid,name,defaultvalue,description) VALUES 
({CID}, 'webmail_admin', 'N', 'Allow User to administrate the Mail Contact settings.');
