<?php
/**
* Translation file for Modul - Contact Mail
*
* Language: deutsch (default)
* Locale:   de
*
* Copyright (C) Kevin Papst. 
*
* For further information go to http://www.kevinpapst.de/ 
* or contact bigace@kevinpapst.de.
*
* @version $Id: modul.lang.php,v 1.1 2006/04/06 21:51:15 kpapst Exp $
* @author Kevin Papst <bigace@kevinpapst.de>
* @package bigace.translation
*/

$LANG['modul_name_contactMail']    		= 'Kontakt Mail versenden';
$LANG['modul_title_contactMail']    	= 'Senden Sie uns eine Nachricht';
$LANG['modul_description_contactMail']  = 'Hier k�nnen Sie eine Nachricht an einen oder mehrere konfigurierbare Empf�nger versenden.';

?>