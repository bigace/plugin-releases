<?php
/**
* Translation file for Modul - Contact Mail
*
* Language: deutsch (default)
* Locale:   de
*
* Copyright (C) Kevin Papst. 
*
* For further information go to http://www.kevinpapst.de/ 
* or contact bigace@kevinpapst.de.
*
* @version $Id: modul.lang.php,v 1.2 2006/04/09 20:56:34 kpapst Exp $
* @author Kevin Papst <bigace@kevinpapst.de>
* @package bigace.translation
*/

$LANG['modul_name_contactMail']    		= 'Send contact email';
$LANG['modul_title_contactMail']    	= 'Send us a Message';
$LANG['modul_description_contactMail']  = 'Leave a message for one or more configured Recipients.';

?>