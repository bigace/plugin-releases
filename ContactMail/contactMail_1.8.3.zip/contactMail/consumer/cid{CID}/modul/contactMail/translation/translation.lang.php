<?php
/**
* Translation file for Modul - Contact Mail
*
* Language: deutsch (default)
* Locale:   de
*
* Copyright (C) Kevin Papst. 
*
* For further information go to http://www.kevinpapst.de/ 
* or contact bigace@kevinpapst.de.
*
* @version $Id: translation.lang.php,v 1.1 2006/04/06 21:51:15 kpapst Exp $
* @author Kevin Papst <bigace@kevinpapst.de>
* @package bigace.translation
*/

$LANG['initial_message']    = '';
$LANG['initial_subject']    = '';
$LANG['create_new_msg']     = 'Erstellen einer neuen Nachricht';
$LANG['contact_error_msg']  = '<p><b>Fehler!</b></p><p>Die Email konnte leider nicht verschickt werden.<br>Bitte entschuldigen Sie diesen Vorfall!<br>Bitte versuchen Sie erneut die Mail zu versenden. Sollte das Problem weiterhin bestehen, schreiben Sie bitte eine manuelle Email.<br>Vielen Dank f�r Ihr Verst�ndniss!</p><br>';
$LANG['error_retry']        = 'Bitte versuchen Sie den Versand erneut...';
$LANG['form_message']       = 'Nachricht';
$LANG['form_subject']       = 'Thema';
$LANG['form_email']         = 'Ihre Email Adresse';
$LANG['form_name']          = 'Name';
$LANG['form_send']          = 'Versenden';
$LANG['form_title']         = 'Nachricht verfassen:';
$LANG['missing_values']     = 'Bitte erg�nzen Sie vor dem Versand die fehlenden Daten!';
$LANG['webmail_admin']      = 'Email Einstellungen vornehmen';
$LANG['admin_answer']       = 'Antwort Text';
$LANG['admin_sendto']       = 'Senden an';
$LANG['save_true']          = 'Einstellungen erfolgreich gespeichert!';
$LANG['save_false']         = 'Einstellungen konnten nicht gespeichert werden!';
$LANG['required']           = ' Pflichtfelder m�ssen ausgef�llt werden!';
$LANG['unconfigured']       = 'Dieses Email Formular ist nicht vollst�ndig konfiguriert. Bitte kontaktieren Sie Ihren Administrator.';

?>