<?php
/**
 * BIGACE - a PHP and MySQL based Web CMS.
 * Copyright (C) Kevin Papst.
 * 
 * BIGACE is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * BIGACE is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software Foundation, 
 * Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 * 
 * For further information visit {@link http://www.kevinpapst.de www.kevinpapst.de}.
 *
 * @version $Id: modul.php,v 1.4 2006/04/17 09:47:27 kpapst Exp $
 * @author Kevin Papst <bigace@kevinpapst.de>
 * @package bigace.modul
 */

loadClass('item', 'ItemAdminService');
loadClass('item', 'ItemProjectService');
loadClass('email', 'TextEmail');
loadClass('userdata', 'UserData');
loadClass('fright', 'FrightService');

require_once ($_BIGACE['DIR']['libs'].'htmlhelper.inc.php');

define('WEBMAIL_ADMIN_FRIGHT',      'webmail_admin'); // fright for the administration
define('MODUL_ADMIN_FRIGHT',        'module_all_rights'); // fright for every modul administration

define('WEBMAIL_MODE_FORMULAR',     1); // Show Overview mit Input Values (if user has WebMail Admin Fright show link to Admin Box)
define('WEBMAIL_MODE_SEND',         2); // Send email if all required fields are submitted, otherwise show formular
define('WEBMAIL_MODE_SETTINGS',     3); // Show Admin Box
define('WEBMAIL_MODE_SAVE',         4); // Update Settings (Answer Text and Recipients)
define('WEBMAIL_PRJ_FIELD_ANSWER',  '1'); // save the answer text in this project field
define('WEBMAIL_PRJ_FIELD_SENDTO',  '2'); // save the email recipients in this project field

/**
 * This modul displays a Mail Formular, that can send Emails to a 
 * configured List of recipients.
 * 
 * It also displays a Feedback message to the User when successful sended,
 * or otherwise a Error message.
 */

// holds the formular values submitted by the user
$MYMAIL = extractVar('MYMAIL', array());
// the mode to decide what to do
$mode = extractVar('mode', WEBMAIL_MODE_FORMULAR);

// get the email configuration
$projectService = new ItemProjectService(_BIGACE_ITEM_MENU);
$WEBMAIL = array(
            'ANSWER'    => $projectService->getProjectText($MENU->getID(), $MENU->getLanguageID(), WEBMAIL_PRJ_FIELD_ANSWER),
            'SEND_TO'   => $projectService->getProjectText($MENU->getID(), $MENU->getLanguageID(), WEBMAIL_PRJ_FIELD_SENDTO)
);

// defines if this webmail page is properly configured!
$configured = true;
if (strlen(trim($WEBMAIL['ANSWER'])) == 0 || strlen(trim($WEBMAIL['SEND_TO'])) < 3) {
    // one of the values is not set
    $configured = false;
} else {
    // one of the values is not valid
    if (strpos($WEBMAIL['SEND_TO'], '@') === false)
        $configured = false;
}

$FRIGHTSERVICE = new FrightService();
// this key defines if the current user is allowed to administrate the webmail settings
$isAllowedToAdministrate = $FRIGHTSERVICE->hasFright($USER->getID(), WEBMAIL_ADMIN_FRIGHT) || $FRIGHTSERVICE->hasFright($USER->getID(), MODUL_ADMIN_FRIGHT);
unset($FRIGHTSERVICE);

function saveWebmailSettings($data) 
{
    if (isset($data['answer']) && $data['answer'] != '' && isset($data['sendto']) && $data['sendto'] != '') 
    {
        $ADMIN_SERVICE = new ItemAdminService(_BIGACE_ITEM_MENU);
        $ADMIN_SERVICE->setProjectText($GLOBALS['MENU']->getID(), $GLOBALS['MENU']->getLanguageID(), WEBMAIL_PRJ_FIELD_ANSWER, $data['answer']);
        return $ADMIN_SERVICE->setProjectText($GLOBALS['MENU']->getID(), $GLOBALS['MENU']->getLanguageID(), WEBMAIL_PRJ_FIELD_SENDTO, $data['sendto']);
    } else {
        return false;
    }
}

/*
* Show Email Formular and - if user has the rights - show link to the admin box
*/
function showMailFormular($mode, $title, $MYMAIL)
{

    if (!$GLOBALS['USER']->isAnonymous()) {
        $USERDATA = $GLOBALS['USER']->getUserData();
    }

    if (!isset($MYMAIL['text'])) {
        $MYMAIL['text'] = getTranslation('initial_message','Your message in here...');
    }

    if (!isset($MYMAIL['name'])) {
        if (!$GLOBALS['USER']->isAnonymous()) {
            $MYMAIL['name'] = $USERDATA->getFirstName() . ' ' . $USERDATA->getLastName();
        } else {
            $MYMAIL['name'] = '';
        }
    }

    if (!isset($MYMAIL['from']) || $MYMAIL['from'] == '') {
        if (!$GLOBALS['USER']->isAnonymous()) {
            $MYMAIL['from'] = $USERDATA->getEmail();
        } else {
            $MYMAIL['from'] = '';
        }
    }

    if (!isset($MYMAIL['subject'])) {
        $MYMAIL['subject'] = getTranslation('initial_subject','Your subject in here...');
    }

	$config = array(
					'width'		    =>	'500',
					'align'		    =>	array (
					                        'table'     =>  'center',
					                        'left'      =>  'left'
					                    ),
					'image'		    => 	$GLOBALS['_BIGACE']['DIR']['public'] . 'modul/images/mail.gif',
					'title'			=> 	$title,
					'form_action'	=>	createMenuLink($GLOBALS['MENU']->getID()),
					'form_method'	=>	'post',
					'form_hidden'	=>	array(
											'mode'			    =>	$mode
									),
					'entries'		=> 	array(
                                            getTranslation('form_name','Name').'*'        => '<input type="text" size="40" name="MYMAIL[name]" value="'.$MYMAIL['name'].'">',
                                            getTranslation('form_email','eMail')            => '<input type="text" size="40" name="MYMAIL[from]" value="'.$MYMAIL['from'].'">',
                                            getTranslation('form_subject','Subject')        => '<input type="text" size="40" name="MYMAIL[subject]" value="'.$MYMAIL['subject'].'">',
                                            getTranslation('form_message','Message').'*'  => '<textarea name="MYMAIL[text]" cols="50" rows="10">'.$MYMAIL['text'].'</textarea>',
                                            'empty'                                         => 'none',
                                            '(*) '.getTranslation('required','Required')    => 'empty'
									),
					'form_submit'	=>	true,
					'submit_label'	=>	getTranslation('form_send','Send')
	);

    // show admin link
    if ($GLOBALS['isAllowedToAdministrate'])
    {
        echo '<table border="0" align="center"><tr><td>';
        echo '<a href="'.createMenuLink($GLOBALS['MENU']->getID(),array('mode'=>WEBMAIL_MODE_SETTINGS)).'">'.getTranslation('webmail_admin','Administration').'</a>';
        echo '</td></tr></table>';
    }
    
    if($GLOBALS['configured']) 
    {
        echo createTable($config);
    }
    else
    {
        echo '<p><b>';
        echo getTranslation('unconfigured', 'This formular is not properly configured. Please call your Administrator.');
        echo '</b></p>';
    }

}

/*********************************************
* START OUTPUT
*********************************************/

echo $MENU->getContent();

// Check if user manipulated URL Parameter
if ($mode == WEBMAIL_MODE_SETTINGS || $mode == WEBMAIL_MODE_SAVE) {
    if (!$isAllowedToAdministrate) {
        $mode = WEBMAIL_MODE_FORMULAR;
    }
}


// If user is allowed to administrate the Modul settings go on, otherwise...
if ($isAllowedToAdministrate)
{
    if ($mode == WEBMAIL_MODE_SAVE)
    {
        /*
        * Save new Settings.
        */
        $success = saveWebmailSettings(extractVar('ADMIN',$WEBMAIL));
        
        if ($success) {
            echo '<br><center><b>'.getTranslation('save_true','Saved wEbMail settings!').'</b></center><br>';
        } else {
            echo '<br><center><b>'.getTranslation('save_false','Could not save wEbMail settings!').'</b></center><br>';
        }
        $mode = WEBMAIL_MODE_FORMULAR;
    } 
    else if ($mode == WEBMAIL_MODE_SETTINGS) 
    {
        /*
        * Show Administration
        */
    	$html = array(
    					'width'		    =>	'500',
    					'align'		    =>	array (
    					                        'table'     =>  'center',
    					                        'left'      =>  'left'
    					                    ),
    					'title'			=> 	getTranslation('webmail_admin','Administration'),
    					'form_action'	=>	createMenuLink($GLOBALS['MENU']->getID()),
    					'form_method'	=>	'post',
    					'form_hidden'	=>	array( 'mode' => WEBMAIL_MODE_SAVE ),
    					'entries'		=> 	array(
                                                getTranslation('admin_sendto')  => '<input type="text" size="40" name="ADMIN[sendto]" value="'.$WEBMAIL['SEND_TO'].'">',
                                                getTranslation('admin_answer')  => '<textarea name="ADMIN[answer]" cols="50" rows="10">'.$WEBMAIL['ANSWER'].'</textarea>'
    									),
    					'form_submit'	=>	true,
    					'form_reset'	=>	"location.href='".createMenuLink($GLOBALS['MENU']->getID())."'",
    					'reset_label'	=>	getTranslation('back','Back'),
    					'submit_label'	=>	getTranslation('save','Save')
    	);
    	echo createTable($html);
    }
}

if ($mode == WEBMAIL_MODE_SEND)
{
    if (!isset($MYMAIL['text']) || $MYMAIL['text'] == '' || !isset($MYMAIL['name']) || $MYMAIL['name'] == '' )
    {
        /*
        * Show input values again till all required fields are filled
        */
        showMailFormular(WEBMAIL_MODE_SEND, getTranslation('missing_values','Please fill out the missing fields!'), $MYMAIL);
    } 
    else 
    {
        /*
        * Send email
        */
        $email = new TextEmail();
        $email->setTo( $GLOBALS['WEBMAIL']['SEND_TO'] );
        $email->setFromName( $MYMAIL['name']  );
        $email->setFromEmail( $MYMAIL['from'] );
        $email->setSubject( 'BIGACE-FORMULAR: '.$MYMAIL['subject'] );
        $email->setContent( 'Am '.date("d.m.Y", time()) . ' um ' . date("g:i", time()).' wurde folgende Nachricht �ber das WebMail-Modul versendet:'."\r\n".$MYMAIL['text'] );
        $didMail = $email->sendMail();
    
        echo '<table border="0" align="center" width="75%">';
        echo '<tr>';
        echo '<td colspan="2">';
        echo '<p>&nbsp;</p>';
        if ($didMail) {
            echo $GLOBALS['WEBMAIL']['ANSWER'];
        }
        else {
            echo getTranslation('contact_error_msg','Error while sending eMail!');
            showMailFormular(WEBMAIL_MODE_SEND, getTranslation('error_retry','Error... Please retry!'), $MYMAIL);
        }
        echo '</td>';
        echo '</tr>';
        echo '</table>';
    }
}
else if ($mode == WEBMAIL_MODE_FORMULAR)
{
    showMailFormular(WEBMAIL_MODE_SEND, getTranslation('form_title','Your message:'), $MYMAIL);
}

unset($projectService);
unset($configured);
unset($isAllowedToAdministrate);
unset($WEBMAIL);
unset($MYMAIL);
unset($mode);

?>