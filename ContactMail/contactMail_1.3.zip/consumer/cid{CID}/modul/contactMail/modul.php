<?php
/**
 * BIGACE - a PHP and MySQL based Web CMS.
 * Copyright (C) Kevin Papst.
 * 
 * BIGACE is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * BIGACE is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software Foundation, 
 * Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 * 
 * For further information visit {@link http://www.kevinpapst.de www.kevinpapst.de}.
 *
 * @version $Id: modul.php,v 1.9 2006/11/26 21:58:55 kpapst Exp $
 * @author Kevin Papst 
 * @package bigace.modul
 */

import('classes.modul.ModulService');
import('classes.modul.Modul');
import('classes.email.TextEmail');
import('classes.util.html.FormularHelper');

define('WEBMAIL_MODE_FORMULAR',     1); // Show Overview mit Input Values (if user has WebMail Admin Fright show link to Admin Box)
define('WEBMAIL_MODE_SEND',         2); // Send email if all required fields are submitted, otherwise show formular

define('WEBMAIL_PRJ_FIELD_ANSWER',  'contactMail_answer'); // save the answer text in this project field
define('WEBMAIL_PRJ_FIELD_SENDTO',  'contactMail_sendto'); // save the email recipients in this project field

Translations::loadGlobal('applications');

/**
 * This modul displays a Mail Formular, that can send an Email to a 
 * configured List of recipients.
 * 
 * It also displays a Feedback message to the User when successful sended,
 * or otherwise a Error message.
 */

// holds the formular values submitted by the user
$MYMAIL = extractVar('MYMAIL', array());
// the mode to decide what to do
$mode = extractVar('mode', WEBMAIL_MODE_FORMULAR);

// get the email configuration
$modul = new Modul($MENU->getModulID());
$modulService = new ModulService();
$config = $modulService->getModulProperties($MENU, $modul);

// defines if this webmail page is properly configured!
$configured = false;
if (isset($config[WEBMAIL_PRJ_FIELD_SENDTO]) && strlen(($config[WEBMAIL_PRJ_FIELD_SENDTO])) >= 3 && strpos($config[WEBMAIL_PRJ_FIELD_SENDTO], '@') !== false) {
    $configured = true;
}

/* #########################################################################
 * ############################  Show Admin Link  ##########################
 * #########################################################################
 */
if ($modul->isModulAdmin())
{
    import('classes.util.links.ModulAdminLink');
    import('classes.util.LinkHelper');
    $mdl = new ModulAdminLink();
    $mdl->setItemID($MENU->getID());
    $mdl->setLanguageID($MENU->getLanguageID());

    ?>
    <script type="text/javascript">
    <!--
    function openAdmin()
    {
        fenster = open("<?php echo LinkHelper::getUrlFromCMSLink($mdl); ?>","ModulAdmin","menubar=no,toolbar=no,statusbar=no,directories=no,location=no,scrollbars=yes,resizable=no,height=350,width=400,screenX=0,screenY=0");
        bBreite=screen.width;
        bHoehe=screen.height;
        fenster.moveTo((bBreite-400)/2,(bHoehe-350)/2);
    }
    // -->
    </script>
    <?php

    echo '<div align="left"><a onClick="openAdmin(); return false;" href="'.LinkHelper::getUrlFromCMSLink($mdl).'"><img src="'.$GLOBALS['_BIGACE']['DIR']['public'].'system/images/preferences.gif" border="0" align="top"> '.Translations::translateGlobal('modul_admin').'</a></div>';
}

if(!$configured) 
{
    echo '<p><b>';
    echo getTranslation('unconfigured', 'This formular is not properly configured. Please call your Administrator.');
    echo '</b></p>';
}
else
{
	/*********************************************
	* START OUTPUT
	*********************************************/
	
	echo $MENU->getContent();
	
	if ($mode == WEBMAIL_MODE_SEND)
	{
	    if (!isset($MYMAIL['text']) || $MYMAIL['text'] == '' || !isset($MYMAIL['name']) || $MYMAIL['name'] == '' )
	    {
	        // Show input values again till all required fields are filled
	        showMailFormular(WEBMAIL_MODE_SEND, getTranslation('missing_values','Please fill in required fields!'), $MYMAIL);
	    } 
	    else 
	    {
	    	$inludeSystemInfo = true;	
	    
	        // Send email
	        $email = new TextEmail();
	        $email->setTo( $config[WEBMAIL_PRJ_FIELD_SENDTO] );
	        $email->setFromName( $MYMAIL['name']  );
	        $email->setFromEmail( $MYMAIL['from'] );
	        $email->setSubject( 'BIGACE-FORMULAR: '.$MYMAIL['subject'] );
	        // TODO translate
	        // TODO add system infos
	        $dateToSend = date("d.m.Y g:i", time());
	        $contentToSend  = 'The following message was sent via the BIGACE-Webmail-Modul!';
	        $contentToSend .= "\r\n\r\n-----------------------------------------------------\r\n\r\n";
	        $contentToSend .= $MYMAIL['text'];
	        if ($inludeSystemInfo) {
		        $contentToSend .= "\r\n\r\n-----------------------------------------------------\r\n\r\n";
		        $contentToSend .= 'System Information:' . "\r\n\r\n";
		        $contentToSend .= 'URL : '. $GLOBALS['_BIGACE']['DOMAIN'] . "\r\n";
		        $contentToSend .= 'CID : '. _CID_ . "\r\n";
		        $contentToSend .= 'CMS : BIGACE '. _BIGACE_ID . "\r\n";
		        $contentToSend .= 'DATE: '. $dateToSend . "\r\n";
	        }
	        
	        $email->setContent( $contentToSend );
	        $didMail = $email->sendMail();
	    
	        echo '<table border="0" align="center" width="75%">';
	        echo '<tr>';
	        echo '<td colspan="2">';
	        echo '<p>&nbsp;</p>';
	        if ($didMail) {
                if(isset($config[WEBMAIL_PRJ_FIELD_ANSWER]))
    				echo $config[WEBMAIL_PRJ_FIELD_ANSWER];
                else
                    echo 'Your Mail has been send';
	        }
	        else {
	            echo getTranslation('contact_error_msg','Error while sending eMail!');
	            showMailFormular(WEBMAIL_MODE_SEND, getTranslation('error_retry','Error... Please retry!'), $MYMAIL);
	        }
	        echo '</td>';
	        echo '</tr>';
	        echo '</table>';
	    }
	}
	else
	{
	    showMailFormular(WEBMAIL_MODE_SEND, getTranslation('form_title','Your message:'), $MYMAIL);
	}
}

unset($configured);
unset($MYMAIL);
unset($mode);


/*
* Show Email Formular and - if user has the rights - show link to the admin box
*/
function showMailFormular($mode, $title, $MYMAIL)
{

    if (!isset($MYMAIL['text']))
        $MYMAIL['text'] = getTranslation('initial_message','Your message in here...');

    if (!isset($MYMAIL['name']))
        $MYMAIL['name'] = '';

    if (!isset($MYMAIL['from']))
        $MYMAIL['from'] = '';

    if (!isset($MYMAIL['subject'])) {
        $MYMAIL['subject'] = getTranslation('initial_subject','Your subject in here...');
    }

	$config = array(
					'width'		    =>	'100%',
					'align'		    =>	array (
					                        'table'     =>  'center',
					                        'left'      =>  'left'
					                    ),
					'image'		    => 	$GLOBALS['_BIGACE']['DIR']['public'] . 'modul/images/mail.gif',
					'title'			=> 	$title,
					'form_action'	=>	createMenuLink($GLOBALS['MENU']->getID()),
					'form_method'	=>	'post',
					'form_hidden'	=>	array( 'mode' => $mode ),
					'entries'		=> 	array(
                                            getTranslation('form_name','Name').'*'        => '<input type="text" size="40" name="MYMAIL[name]" value="'.$MYMAIL['name'].'">',
                                            getTranslation('form_email','eMail')            => '<input type="text" size="40" name="MYMAIL[from]" value="'.$MYMAIL['from'].'">',
                                            getTranslation('form_subject','Subject')        => '<input type="text" size="40" name="MYMAIL[subject]" value="'.$MYMAIL['subject'].'">',
                                            getTranslation('form_message','Message').'*'  => '<textarea name="MYMAIL[text]" cols="50" rows="10">'.$MYMAIL['text'].'</textarea>',
                                            'empty'                                         => 'none',
                                            '(*) '.getTranslation('required','Required')    => 'empty'
									),
					'form_submit'	=>	true,
					'submit_label'	=>	getTranslation('form_send','Send')
	);
    
    echo createTable($config);
}


?>