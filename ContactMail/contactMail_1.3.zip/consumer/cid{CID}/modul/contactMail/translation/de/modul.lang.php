<?php
/**
* Translation file for Modul - Contact Mail
* Language: deutsch
* Locale:   de
*
* Copyright (C) Kevin Papst. 
*
* For further information go to http://www.bigace.de/ 
*
* @version $Id: modul.lang.php,v 1.2 2006/11/26 21:58:45 kpapst Exp $
* @author Kevin Papst 
*/

$LANG['name']		    = 'Kontakt Mail versenden';
$LANG['title']		    = 'Senden Sie uns eine Nachricht';                                                            
$LANG['description']	= 'Hier k&ouml;nnen Sie eine Nachricht an einen oder mehrere konfigurierbare Empf&auml;nger versenden.';

?>