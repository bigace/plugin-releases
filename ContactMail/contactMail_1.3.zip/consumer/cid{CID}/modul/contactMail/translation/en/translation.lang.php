<?php
/**
* Translation file for Modul - Contact Mail
*
* Language: english
* Locale:   en
*
* Copyright (C) Kevin Papst. 
*
* For further information go to http://www.bigace.de/ 
*
* @version $Id: translation.lang.php,v 1.2 2006/11/26 21:58:51 kpapst Exp $
* @author Kevin Papst 
* @package bigace.translation
*/

$LANG['initial_message']    = '';
$LANG['initial_subject']    = '';
$LANG['create_new_msg']     = 'Create new eMail';
$LANG['contact_error_msg']  = '<p><b>Fehler!</b></p><p>Your Email could not be delivered.<br>Sorry about that, please try again to send your message! If the problem remains, please send a manual Email!<br>Thank you for your comprehension!</p><br>';
$LANG['error_retry']        = 'Please retry to send...';
$LANG['form_message']       = 'Message';
$LANG['form_subject']       = 'Subject';
$LANG['form_email']         = 'Your Email adress';
$LANG['form_name']          = 'Your Name';
$LANG['form_send']          = 'Send';
$LANG['form_title']         = 'Your Email in here:';
$LANG['missing_values']     = 'Please fill out the missing fields!';
$LANG['webmail_admin']      = 'Configure email settings';
$LANG['admin_answer']       = 'Answer text';
$LANG['admin_sendto']       = 'Send to';
$LANG['save_true']          = 'Saved settings!';
$LANG['save_false']         = 'Could not save settings!';
$LANG['required']           = ' are required fields!';
$LANG['unconfigured']       = 'This Email Formular is not properly configured. Please call your Administrator.';

?>