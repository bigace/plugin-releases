DELETE FROM {DB_PREFIX}design WHERE cid='{CID}';
DELETE FROM {DB_PREFIX}smarty_history WHERE cid='{CID}';
DELETE FROM {DB_PREFIX}stylesheet WHERE cid='{CID}';
DELETE FROM {DB_PREFIX}template WHERE cid='{CID}';

