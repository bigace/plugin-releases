<?php
/*
* Displays a language dependend Sitemap with 3 Levels.
*
* Copyright (C) Kevin Papst. 
*
* For further information go to http://www.bigace.de/ 
*
* @version $Id: modul.php,v 1.4 2007/05/05 19:08:25 kpapst Exp $
* @author Kevin Papst 
* @package bigace.modul
*/

define('SITEMAP_LANGUAGE', 	$MENU->getLanguageID());
define('SITEMAP_PUBLIC',   	$GLOBALS['_BIGACE']['DIR']['public'] . 'modul/sitemap/');
define('SITEMAP_OWN_CSS',	true);

import('classes.menu.MenuService');
import('classes.modul.ModulService');
import('classes.modul.Modul');

$modul = new Modul($MENU->getModulID());
$modulService = new ModulService();
$config = $modulService->getModulProperties($MENU, $modul);

/* #########################################################################
 * ############################  Show Admin Link  ##########################
 * #########################################################################
 */
if ($modul->isModulAdmin())
{
    import('classes.util.links.ModulAdminLink');
    import('classes.util.LinkHelper');
    $mdl = new ModulAdminLink();
    $mdl->setItemID($MENU->getID());
    $mdl->setLanguageID($MENU->getLanguageID());

    ?>
    <script type="text/javascript">
    <!--
    function openAdmin()
    {
        fenster = open("<?php echo LinkHelper::getUrlFromCMSLink($mdl); ?>","ModulAdmin","menubar=no,toolbar=no,statusbar=no,directories=no,location=no,scrollbars=yes,resizable=no,height=350,width=400,screenX=0,screenY=0");
        bBreite=screen.width;
        bHoehe=screen.height;
        fenster.moveTo((bBreite-400)/2,(bHoehe-350)/2);
    }
    // -->
    </script>
    <?php

    echo '<div align="left"><a onClick="openAdmin(); return false;" href="'.LinkHelper::getUrlFromCMSLink($mdl).'"><img src="'.$GLOBALS['_BIGACE']['DIR']['public'].'system/images/preferences.gif" border="0" align="top"> '.$modul->translate('admin_link').'</a></div>';
}

	$startID 	= $config['sitemap2_startID'];
	$depth 		= $config['sitemap2_menuDepth'];
	$useCss     = $config['sitemap2_useCss'];

    //$TEMP_MENU_RIGHT = $RIGHT_SERVICE->getMenuRight($GLOBALS['_BIGACE']['SESSION']->getUserID(), $startID);
    //if (!$TEMP_MENU_RIGHT->canRead()) {
    //    $startID = _BIGACE_TOP_LEVEL;
    //}
    $MENU_SERVICE = new MenuService();
    $SITEMAP_MENU = $MENU_SERVICE->getMenu($startID, $MENU->getLanguageID());

    function createMenuRecurse($startMenu, $level, $max) {
    	if($level < $max) 
    	{	
    		$childs = $startMenu->getChilds();
    		if($childs->count() > 0) {
    			echo '<ul>';
				for($i=0; $i < $childs->count(); $i++)
				{
					$tempMenu = $childs->next();
    				echo '<li><a href="'.createMenuLink($tempMenu->getID()).'">' . $tempMenu->getName() . "</a>\n";
                    createMenuRecurse($tempMenu, $level+1, $max);
                    echo '</li>' . "\n";
				}
    			echo '</ul>';
    		}
    	}
    }
	    
	/*
	 * Use internal CSS definitions.
	 */
	if ($useCss)
	{
		?>
		<style type="text/css">
		#sitemap h1 a {
			font-size:14px; 
            font-weight:bold;
            color: #000000;
            border-width:0px;
            margin:0px 0px 0px 0px;
            padding:0px 0px 0px 0px;
		}
		#sitemap h1 a:hover {
			font-size:14px; 
            font-weight:bold;
            color: #666666;
            border-width:0px;
            margin:0px 0px 0px 0px;
            padding:0px 0px 0px 0px;
		}
		#sitemap h1 {
			font-size:14px; 
            background-color: #eeeeee;
            border:1px solid #cccccc;
            margin:5px 0px 0px 0px;
            padding:0px 0px 0px 5px;
		}
		#sitemap ul {
			font-size:14px; 
            list-style-type:none;
            //text-decoration:underline; 
            font-weight:bold;
            color: #000000;
            border-width:0px;
		}
		#sitemap li {
			font-size:12px; 
            //text-decoration:underline; 
            //font-weight:bold;
            color: #000000;
            border-width:0px;
		}
		</style>
		<?php
	}
	
	?>

	<div id="sitemap">
		<?php

    		$childs1 = $SITEMAP_MENU->getChilds();
			for($i=0; $i < $childs1->count(); $i++) {
				$tempMenu1 = $childs1->next();
    			echo '<h1><a href="'.createMenuLink($tempMenu1->getID()).'">'.$tempMenu1->getName().'</a></h1>' . "\n";
				createMenuRecurse($tempMenu1, 1, $depth);
			}
		?>
	</div>
