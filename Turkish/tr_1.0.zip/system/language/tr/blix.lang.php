﻿<?php

$LANG['written_at'] = 'Yazilma tarihi:';
$LANG['written_by'] = '';
$LANG['search_button'] = 'Arama!';
$LANG['empty_searchterm'] = 'Arama kriteri bos lütfen en az 4 karakter girin!';
$LANG['short_searchterm'] = 'Arama kriteriniz çok kisa lütfen en az 4 karakterden olusan bir sorgu gönderin!';

?>