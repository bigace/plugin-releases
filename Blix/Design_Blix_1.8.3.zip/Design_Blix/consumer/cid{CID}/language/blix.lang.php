<?php

$LANG['search_button'] = 'Suchen!';

?>