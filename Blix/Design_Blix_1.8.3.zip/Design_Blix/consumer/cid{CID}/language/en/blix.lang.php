<?php

$LANG['search_button'] = 'Search!';

?>