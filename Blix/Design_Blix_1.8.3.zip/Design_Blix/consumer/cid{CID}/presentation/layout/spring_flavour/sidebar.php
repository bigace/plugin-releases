<hr class="low" />

<div id="subcontent">
<?php
    foreach($_BLIX['PORTLETS'] AS $currentPortlet)
    {
        echo '<h2><em>'.$currentPortlet->getTitle().'</em></h2>';
        echo $currentPortlet->getHtml();
    }
?>	
</div>