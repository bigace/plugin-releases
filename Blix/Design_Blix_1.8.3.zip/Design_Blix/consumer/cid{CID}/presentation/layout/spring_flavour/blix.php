<?php include_once('environment.php'); ?>
<?php include_once('header.php'); ?>

<div id="content">
<h2><?php echo $MENU->getName(); ?></h2>
<?php include($GLOBALS['_BIGACE']['DIR']['include'].'loadModul.php'); ?>
</div>

<?php 
if(!IS_SINGLE_COLUMN) {
    include_once('sidebar.php'); 
}
?>

<?php include_once('footer.php'); ?>