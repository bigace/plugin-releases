<?php
/**
 * BIGACE - a PHP and MySQL based Web CMS.
 * Copyright (C) Kevin Papst.
 * -------------------------------------------------
 * The BLIX Layout for BIGACE.
 */
 
 
/*
 * This is the TOP LEVEL Item of the Blix Design.
 */
define('_BLIX_HOME',    _BIGACE_TOP_LEVEL);
/*
 * Below this Item the TOP Menu Items resist.
 * All Children of the given ID will be shown in the top navigation.
 */
define('_BLIX_TOP_MENU', _BLIX_HOME);
/**
 * Will be shown in the footer as Copyright holder.
 */
define('_BLIX_COPYRIGHT_BY', 'Kevin Papst');
/**
 * Show the Login/Logout Linkwithin the Footer?
 */
define('_BLIX_SHOW_STATUS', true);
/**
 * Show the TOP-LEVEL Link in the Menu?
 */
define('_BLIX_HOME_IN_MENU', false);
/**
 * Show the Google Search Form?
 */
define('_BLIX_SEARCH_WITH_GOOLGE', false);

/*
 * -------------------------------------------
 * ! NO FURTHER EDITING NECESSARY !
 * -------------------------------------------
 *
 * The following values are calculated by the 
 * script itself. DON'T MODIFY!
 */
 
loadClass('portlet', 'PortletParser');
loadLanguageFile('blix');

define('_BLIX_WEB_DIR', $GLOBALS['_BIGACE']['DIR']['public'].'spring_flavour/');
define('_IS_ANONYMOUS', $USER->isAnonymous());
define('IS_SINGLE_COLUMN', false);

// ---- [start] get Portlets for this Page ----
$portlets = array();
$portletParser = new PortletParser('10');
$portlets = $portletParser->getPortlets(_BIGACE_ITEM_MENU, $MENU->getID(), $MENU->getLanguageID());
unset($portletParser);
// ---- [stop] get Portlets for this Page ----

$_BLIX = array( 
                'LANGUAGE'  => new Language($MENU->getLanguageID()),
                'TOP_LEVEL' => $MENU_SERVICE->getMenu(_BLIX_HOME, $MENU->getLanguageID()),
                'PORTLETS'  => $portlets
);


?>