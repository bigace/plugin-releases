<?php include_once('environment.php'); ?>
<?php include_once('header.php'); ?>

<div id="content">
<?php include_once('searchmask.php'); ?>
</div>

<?php  include_once('sidebar.php'); ?>

<?php include_once('footer.php'); ?>