<?php
/**
 * BIGACE - a PHP and MySQL based Web CMS.
 * Copyright (C) Kevin Papst.
 * 
 * BIGACE is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * BIGACE is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software Foundation, 
 * Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 * 
 * For further information visit {@link http://www.kevinpapst.de www.kevinpapst.de}.
 *
 * @version $Id: LoginMaskPortlet.php,v 1.1 2006/04/17 20:32:42 kpapst Exp $
 * @author Kevin Papst <bigace@kevinpapst.de>
 * @package bigace.classes.portlet
 */

loadClass('portlet', 'Portlet');

/**
 * This portlets shows a Login Form.
 *  
 * @package bigace.classes.portlet
 */
class LoginMaskPortlet extends Portlet
{
    
    function LoginMaskPortlet() 
    {
    }
    
    function getIdentifier() {
        return 'LoginMaskPortlet';
    }
        
    function getTitle() {
        return 'Login Formular';
    }
    
    function getHtml() {
        $pubDir = $GLOBALS['_BIGACE']['DIR']['public'].'system/images/';
        return '
            <form action="' . createCommandLink('login', $GLOBALS['MENU']->getID()) . '" method="post" name="loginForm" onSubmit="javascript:return checkLogin();">
                        <img src="' . $pubDir . 'login.gif" border="0"> <b>' . getTranslation('login', 'Login') . '</b>
                        <br><img height="4" width="1" src="' . $pubDir . 'empty.gif">
                        <table cellpadding="0" cellspacing="0" border="0" width="90%">
                            <tbody>
                        	<tr>
                        		<td>' . getTranslation('username', 'Username') . '</td><td><input size="6" style="width:150px" name="UID" type="text" value=""></td>
                        	</tr>
                            <tr>
                              <td>' . getTranslation('password', 'Password'). '</td><td><input size="6" name="PW" style="width:150px" type="password"></td>
                        	</tr>
                        	<tr>
                            	<td colspan="2" align="right">
                        			<img height="2" width="0" src="' . $pubDir . 'empty.gif"><br>
                        			<input height="17" width="31" value="' . getTranslation('login', 'Login') . '" name="Submit" border="0" type="submit">
                        	    </td>
                            </tr>
                            </tbody>
                        </table>
                        </form>
                    ';
    }

    function needsJavascript() {
        return true;
    }

    function getJavascript() {
        return "
            <script type=\"text/javascript\">
                function checkLogin() 
                {
                    if (document.loginForm.UID.value == '')
                    {
                        alert('" . getTranslation('error_username', 'Please enter a valid Username!') . "');
                        document.loginForm.UID.focus();
                        return false;
                    }
                    
                    if (document.loginForm.PW.value == '')
                    {
                        alert('" . getTranslation('error_password', 'Please enter a valid Password!') . "');
                        document.loginForm.PW.focus();
                        return false;
                    }
                    
                    return true;
                }
            </script>
        ";
    }

    function displayPortlet() {
        return $GLOBALS['USER']->isAnonymous();
    }

}

?>
