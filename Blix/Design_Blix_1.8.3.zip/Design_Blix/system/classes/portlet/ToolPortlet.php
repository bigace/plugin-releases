<?php
/**
 * BIGACE - a PHP and MySQL based Web CMS.
 * Copyright (C) Kevin Papst.
 * 
 * BIGACE is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * BIGACE is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software Foundation, 
 * Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 * 
 * For further information visit {@link http://www.kevinpapst.de www.kevinpapst.de}.
 *
 * @version $Id: ToolPortlet.php,v 1.6 2006/04/16 14:42:35 kpapst Exp $
 * @author Kevin Papst <bigace@kevinpapst.de>
 * @package bigace.classes.portlet
 */

loadClass('portlet', 'Portlet');
loadClass('util', 'applications');

define('TOOLPORTLET_PARAM_CSS', 	'css');
define('TOOLPORTLET_PARAM_STATUS', 	'login');
define('TOOLPORTLET_PARAM_HOME', 	'home');

/**
 * This portlets shows the Application Links in a List.
 *  
 * @package bigace.classes.portlet
 */
class ToolPortlet extends Portlet
{
    var $application;
    
    function ToolPortlet() 
    {
        $this->setCSS("tools");
        $this->setShowLogin(true);
        $this->setHomeID('');

        $APPS = new applications();
        
        // configure the application links
        $APPS->setShowText(true);
        $APPS->setAddPreDelim(true);
        $APPS->setAddPostDelim(true);
        $APPS->setPreDelimiter("<li>");
        $APPS->setPostDelimiter("</li>\n");
        
        if (isset($GLOBALS['USER_MENU_RIGHT']) && !$GLOBALS['USER_MENU_RIGHT']->canWrite()) {
            $APPS->hide($APPS->EDITOR);
        }
        
        $this->application = $APPS;
    }
    
    function getIdentifier() {
        return 'ToolPortlet';
    }
        
    function getTitle() {
        return 'Tools';
    }
    
    function getHtml() {
        $app = $this->application;
        
        // prepare status html
        if($this->getHomeID() != '')
        	$app->setHomeID($this->getHomeID());
        if(!$this->getShowLogin())
            $app->hide($app->STATUS);
        	
        return '<ul class="'.$this->getCSS().'">' . "\n" . $app->getAllLink() . "\n" . '</ul>';
    }

    function needsJavascript() {
        return true;
    }

    function getJavascript() {
        $app = $this->application;
        return $app->getAllJavascript();
    }

    function getParameterType($key) {
        switch ($key) {
            case TOOLPORTLET_PARAM_CSS:
                return PORTLET_TYPE_STRING;
            case TOOLPORTLET_PARAM_STATUS:
                return PORTLET_TYPE_BOOLEAN;
            case TOOLPORTLET_PARAM_HOME:
                return PORTLET_TYPE_MENUID_OPTIONAL;
        }
        return PORTLET_TYPE_STRING;
    }
    
    // --------------------------------------------------

    function getShowLogin() {
    	return $this->getParameter(TOOLPORTLET_PARAM_STATUS, true);
    }

    function setShowLogin($show = true) {
        $this->setParameter(TOOLPORTLET_PARAM_STATUS, $show);
    }
    
    function getHomeID() {
    	return $this->getParameter(TOOLPORTLET_PARAM_HOME, '');
    }
    
    function setHomeID($id) {
        $this->setParameter(TOOLPORTLET_PARAM_HOME, $id);
    }

    function getCSS() {
        return $this->getParameter(TOOLPORTLET_PARAM_CSS, '');
    }
    
    function setCSS($css = '') {
        $this->setParameter(TOOLPORTLET_PARAM_CSS, $css);
    }
        
}

?>
