<?php
/**
 * BIGACE - a PHP and MySQL based Web CMS.
 * Copyright (C) Kevin Papst.
 * 
 * BIGACE is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * BIGACE is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software Foundation, 
 * Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 * 
 * For further information visit {@link http://www.kevinpapst.de www.kevinpapst.de}.
 *
 * @version $Id: LastEditedItemsPortlet.php,v 1.4 2006/04/14 12:09:20 kpapst Exp $
 * @author Kevin Papst <bigace@kevinpapst.de>
 * @package bigace.classes.portlet
 */

loadClass('portlet', 'Portlet');

define('LAST_EDITED_PARAM_CSS', 'css');
define('LAST_EDITED_PARAM_AMOUNT',   'amount');
define('LAST_EDITED_PARAM_LANGUAGE', 'language');

define('LAST_EDITED_DEFAULT_AMOUNT', '5');

/**
 * Shows a configurable amount of Items that were last edited in the System.
 *  
 * @package bigace.classes.portlet
 */
class LastEditedItemsPortlet extends Portlet
{

    function LastEditedItemsPortlet() 
    {
        $this->setCSS("categories");
		$this->setLanguageID('');
		$this->setAmount(LAST_EDITED_DEFAULT_AMOUNT);
    }

    function getIdentifier() {
        return 'LastEditedItemsPortlet';
    }
        
    function getParameterType($key) {
        switch ($key) {
            case LAST_EDITED_PARAM_AMOUNT:
                return PORTLET_TYPE_INT_POSITIVE;
            case LAST_EDITED_PARAM_LANGUAGE:
                return PORTLET_TYPE_LANGUAGE_OPTIONAL;
            case LAST_EDITED_PARAM_CSS:
                return PORTLET_TYPE_STRING;
        }
        return PORTLET_TYPE_STRING;
    }

    function getTitle() {
        return 'Last Edited Items';
    }
    
    function needsJavascript() {
        return false;
    }
    
    function getHtml() 
    {
        $temp = $GLOBALS['MENU_SERVICE']->getLastEditedItems( $this->getLanguageID(), 0, $this->getAmount() );
        $html = '<ul class="'.$this->getCSS().'">';
        
        for ($i=0; $i < $temp->count(); $i++)
        {
            $lastEdited = $temp->next();
            $html .= '<li><a href="' . createMenuLink( $lastEdited->getID() ) . '">' . $lastEdited->getName() . '</a>';
            if (strlen($lastEdited->getDescription()) > 0) {
                $html .= substr ( $lastEdited->getDescription(), 0, 50);
                if (strlen($lastEdited->getDescription()) > 53)
                    $html .= '...';
                $html .= '<br />';
            }
            $html .= '<i>' . date("d.m.Y", $lastEdited->getLastDate()) . '</i>';
            $html .= '</li>';
        }
        return $html . "</ul>\n";
    }

	// ------------------------------------------------------------

    function getCSS() {
        return $this->getParameter(LAST_EDITED_PARAM_CSS, '');
    }
    
    function setCSS($css = '') {
        $this->setParameter(LAST_EDITED_PARAM_CSS, $css);
    }

    function setLanguageID($id = '') {
        $this->setParameter( LAST_EDITED_PARAM_LANGUAGE, $id );
    }

    function getLanguageID() {
        $id = $this->getParameter( LAST_EDITED_PARAM_LANGUAGE );
        if ($id == '')
            return $GLOBALS['MENU']->getLanguageID();
        return $id;
    }

    function setAmount($amount = '') {
        $this->setParameter( LAST_EDITED_PARAM_AMOUNT, $amount );
    }

    function getAmount() {
        $id = $this->getParameter( LAST_EDITED_PARAM_AMOUNT );
        if ($id == '')
            return LAST_EDITED_DEFAULT_AMOUNT;
        return $id;
    }

}

?>
