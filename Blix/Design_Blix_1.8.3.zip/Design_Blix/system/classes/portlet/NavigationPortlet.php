<?php
/**
 * BIGACE - a PHP and MySQL based Web CMS.
 * Copyright (C) Kevin Papst.
 * 
 * BIGACE is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * BIGACE is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software Foundation, 
 * Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 * 
 * For further information visit {@link http://www.kevinpapst.de www.kevinpapst.de}.
 *
 * @version $Id: NavigationPortlet.php,v 1.4 2006/04/14 12:09:20 kpapst Exp $
 * @author Kevin Papst <bigace@kevinpapst.de>
 * @package bigace.classes.portlet
 */

loadClass('portlet', 'Portlet');

define('NAVI_PARAM_CSS',      'css');
define('NAVI_PARAM_ID',       'id');
define('NAVI_PARAM_LANGUAGE', 'language');

/**
 * Shows the Children navigation of this portlet.
 *  
 * @package bigace.classes.portlet
 */
class NavigationPortlet extends Portlet
{
    
    function NavigationPortlet() 
    {
        $this->setCSS("categories");
        $this->setLanguageID('');
        $this->setStartID('');
    }

    function getIdentifier() {
        return 'NavigationPortlet';
    }

    function getParameterType($key) {
        switch ($key) {
            case NAVI_PARAM_ID:
                return PORTLET_TYPE_MENUID_OPTIONAL;
            case NAVI_PARAM_LANGUAGE:
                return PORTLET_TYPE_LANGUAGE_OPTIONAL;
            case NAVI_PARAM_CSS:
                return PORTLET_TYPE_STRING;
        }
        return PORTLET_TYPE_STRING;
    }

    function getTitle() {
        return 'Menu';
    }
    
    function getHtml() {
        $all = $this->buildMenuLevel($this->getStartID(), $this->getLanguageID());
        if (strlen($all) > 0)
            return '<ul class="'.$this->getCSS().'">' . "\n" . $all . '</ul>';
        return '<b>Site has no Children</b>';
    }
    
    function needsJavascript() {
        return false;
    }
    
    function buildMenuLevel($id, $langid)
    {
        $link = '';
        $menu_info = $GLOBALS['MENU_SERVICE']->getLightTreeForLanguage($id, $langid);
        
        for ($i=0; $i < $menu_info->count(); $i++) 
        {
            $menu = $menu_info->next();
        
            $link .= '<li><a href="' . createMenuLink( $menu->getID() ) . '">' . $menu->getName() . '</a>';
            if ($menu->hasChilds()) {
                $link .= '<ul>' . $this->buildMenuLevel($menu->getID(), $menu->getLanguageID()) . '</ul>';
            }
            $link .= "</li>\n";
        }
        return $link;
    }    

	// ------------------------------------------------------------
    
    function getCSS() {
        return $this->getParameter(NAVI_PARAM_CSS, '');
    }
    
    function setCSS($css = '') {
        $this->setParameter(NAVI_PARAM_CSS, $css);
    }

    function setStartID($id = '') {
        $this->setParameter( NAVI_PARAM_ID, $id );
    }

    function getStartID() {
        $id = $this->getParameter( NAVI_PARAM_ID );
        if ($id == '')
            return $GLOBALS['MENU']->getID();
        return $id;
    }

    function setLanguageID($id = '') {
        $this->setParameter( NAVI_PARAM_LANGUAGE, $id );
    }

    function getLanguageID() {
        $id = $this->getParameter( NAVI_PARAM_LANGUAGE );
        if ($id == '')
            return $GLOBALS['MENU']->getLanguageID();
        return $id;
    }
    
}

?>
