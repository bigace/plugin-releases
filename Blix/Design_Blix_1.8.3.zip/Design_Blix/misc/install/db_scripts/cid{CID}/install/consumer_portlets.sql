INSERT INTO {DB_PREFIX}item_project_text (itemtype, id, cid, language, project_key, project_value) VALUES 
(1, -1, {CID}, 'de', 10, '<?xml version=''1.0''?>\n <Portlets>\n    <ToolPortlet css="tools" login="1" home="" />\n    <NavigationPortlet css="categories" language="" id="" />\n    <LastEditedItemsPortlet css="categories" language="" amount="5" />\n </Portlets>\n'),
(1, -1, {CID}, 'en', 10, '<?xml version=''1.0''?>\n <Portlets>\n    <ToolPortlet css="tools" login="1" home="" />\n    <NavigationPortlet css="categories" language="" id="" />\n    <LastEditedItemsPortlet css="categories" language="" amount="5" />\n </Portlets>\n');

# {-S-T-A-T-E-M-E-N-T--S-P-L-I-T-T-E-R-} #
