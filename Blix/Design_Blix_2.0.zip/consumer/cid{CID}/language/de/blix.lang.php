<?php

$LANG['written_at'] = 'Geschrieben am:';
$LANG['written_by'] = 'von';
$LANG['search_button'] = 'Suchen!';
$LANG['empty_searchterm'] = 'Ihr Suchbefehl ist leer, bitte geben Sie mindestens 4 Buchstaben ein!';
$LANG['short_searchterm'] = 'Ihr Suchbefehl ist zu kurz, bitte geben Sie mindestens 4 Buchstaben ein!';

?>