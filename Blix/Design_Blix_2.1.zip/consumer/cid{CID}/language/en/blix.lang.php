<?php

$LANG['written_at'] = 'Written at:';
$LANG['written_by'] = 'by';
$LANG['search_button'] = 'Search!';
$LANG['empty_searchterm'] = 'Your searchterm is empty, please enter at least 4 character!';
$LANG['short_searchterm'] = 'Your searchterm is too short, please enter at least 4 character!';

?>