<b>Diff&eacute;rer l&rsquo;envoi d&rsquo;un message (Embargo)</b>
<p>Vous pouvez diff&eacute;rer l&rsquo;envoi d&rsquo;un message jusqu&rsquo;&agrave; la date et heure de votre choix.
Par d&eacute;faut, le message sera envoy&eacute; imm&eacute;diatement, car la date et heure sera fix&eacute;e en fonction de l&rsquo;heure pr&eacute;sente. </p>
<p><b>Note importante</b>: l&rsquo;envoi en diff&eacute;r&eacute; n&rsquo;affecte que le moment du d&eacute;but de l&rsquo;envoi du message.
Ceci ne signifie pas que les messages vont arriver dans la Bo&icirc;te aux lettres de vos utilisateurs &agrave; ce moment-l&agrave;.
</p>