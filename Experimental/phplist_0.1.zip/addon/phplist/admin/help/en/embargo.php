<b>Embargo a message</b>
<p>You can embargo a message so it is not sent before the date and time you indicate.
By default it will be set to today at 0:00, so it will be sent immediately. </p>
<p><b>Please note</b>: the embargo has an effect on the time sending of your message will start.
This does not mean the messages will actually arrive in the users' Inboxes at that time.
</p>