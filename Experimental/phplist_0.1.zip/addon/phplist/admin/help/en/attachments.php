<p>You can add as many attachments to your message as you like, but the number listed here
is defined in your configuration.</p>
<p><b>Please Note:</b> Attachments will be included in HTML emails, and will be added as a link to the website in Text emails</p>
<p>The description field will be used in the text messages only</p>