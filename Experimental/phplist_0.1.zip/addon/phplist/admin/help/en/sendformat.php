If this message has been formatted in HTML,
indicate how you want to send it:<br />
<ul>
<li><b>HTML</b> - HTML with hidden text opnly to users who have indicated that they want to receive their emails in HTML format, and text only to everyone else</li>
<li><b>text</b> - text-only to everyone</li>
<!-- li><b>text and HTML</b> - One big email that contains both the HTML and the text only format.</li> -->
<li><b>PDF</b> - The text message as a PDF attachment</li>
<li><b>text and PDF</b> - One email that contains the text only message with a PDF attachment</li>
</ul>

<b>Please note:</b> the PDF version will be a conversion of the text message, not of the HTML message.