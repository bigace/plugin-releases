<b>Plannen (embargo) van een bericht</b>
<p>Je kan een bericht plannen zodat het niet wordt verzonden voor de datum en tijd die jij hebt aangegeven.
Standaard wordt dit op vandaag om 0:00 geplaatst, dus het zal onmiddellijk verzonden worden. </p>
<p><b>Let op</b>: Het plannen heeft enkel invloed op de tijd dat het verzenden van het bericht begint.
Dit wil niet zeggen dat de berichten echt op dat moment zullen aankomen bij de gebruikers.
</p>