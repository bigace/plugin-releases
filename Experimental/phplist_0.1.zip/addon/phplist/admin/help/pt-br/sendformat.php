Se a sua mensagem foi formatada em HTLM,
indique como voc&ecirc; quer envi&aacute;-la:<br />
<ul>
<li><b>HTML</b> - HTML para usu&aacute;rios que querem receber seus emails em formato HTML e em texto para todos os outros</li>
<li><b>text</b> - somente texto para todos</li>
<li><b>text e HTML</b> - Um grande email contendo ambos formatos HTML e somente texto (os emails s&aatilde;o maiores, mas funciona melhor para a maioria dos usu&aacute;rios)</li>
<li><b>PDF</b> - O texto da mensagem ser&aacute; enviado como um anexo PDF</li>
<li><b>text e PDF</b> - Um email que contenha a mensagem somente texto e com um anexo em PDF</li>
</ul>

<b>Aten&ccedil;&atilde;o:</b> a vers&atilde;o PDF converte o texto da mensagem, mas n&atilde;o os c&oacute;digos HTML.
