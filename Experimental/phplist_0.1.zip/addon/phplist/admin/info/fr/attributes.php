<p>Vous pouvez choisir ici les attributs que vous voulez que le public puisse renseigner pour s&rsquo;inscrire sur vos listes.
<br />Les attributs sont "globaux", c&rsquo;est-&agrave;-dire qu&rsquo;ils s&rsquo;appliquent &agrave; toutes les listes.</p>
<p><a href="#new">Ajouter un nouvel attribut</a></p>