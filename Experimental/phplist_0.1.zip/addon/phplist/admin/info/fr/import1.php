Vous pouvez ajouter plusieurs adresses email &agrave; vos listes.  Tous les emails doivent avoir les m&ecirc;mes attributs que votre base actuelle, et vous pouvez les identifier ci-dessous.
