<hr/>
<h2>Zugriffsrechte</h2>
<p>Rechte eines Administrators beim Zugriff auf die einzelnen Seiten im System</p>
<ul>
  <li><strong>Alle:</strong> Der Administrator hat uneingeschr&auml;nkten Zugriff auf die Seite (lesen und schreiben).</li>
  <li><strong>Lesen:</strong> Der Administrator kann die Seite sehen, aber keine &Auml;nderungen daran vornehmen. Diese Einstellung funktioniert derzeit erst f�r die Seiten "user", "users" und "members".</li>
  <li><strong>Keine:</strong> Der Administrator kann die Seite nicht sehen.</li>
  <li><strong>Eigene:</strong> Der Administrator kann die Seite sehen, allerdings nur den Inhalt seiner eigenen Listen.</li>
</ul>