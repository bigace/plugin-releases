<p>Hier k&ouml;nnen Sie die Daten der Abonnenten als Textdatei exportieren.
Dabei besteht die M&ouml;glichkeit, die Abonnenten nach Anmelde- bzw. &Auml;nderungsdatum zu selektieren.
Ausserdem k&ouml;nnen Sie ausw&auml;hlen, welche Spalten (d.h. Attribute) exportiert werden sollen.</p>

<p>Wenn Sie auf [Exportieren] klicken, wird die Datei mit den gew&auml;hlten Abonnenten/Attributen herunteruntergeladen.
Es handelt sich um eine Textdatei mit 1 Zeile pro Abonnent, wobei die Attributwerte durch Tabulatoren getrennt sind.
Eine solche Textdatei kann mit den meisten Tabellenkalkulationsprogrammen ge&ouml;ffnet und weiterverarbeitet werden.</p>

<b>Auswahl nach Datum</b>