<p>W&auml;hlen Sie die vordefinierten Attribute, die Sie den Abonnentenkonten hinzuf&uuml;gen m&ouml;chten.</p>
<p>Um eigene vordefinierte Attribute zu erstellen legen Sie eine Liste mit den Attributwerten als Textdatei in das Verzeichnis /admin/data/.
Auf diesem Weg k&ouml;nnen Sie auch Attributwerte importieren statt sie von Hand zu erfassen.
Sie ben&ouml;tigen dazu allerdings einen FTP-Zugang zu Ihrer PHPlist-Installation.</p>
