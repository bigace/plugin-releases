Diese Importmethode empfiehlt sich, wenn Sie eine einfache Liste mit E-Mail-Adressen aus einer Textdatei importieren.
Sie k&ouml;nnen dabei f&uuml;r jedes im System existierende Attribut einen Standardwert bestimmen,
der dann f&uuml;r s&auml;mtliche importierten Adressen einheitlich gesetzt wird.
Allf&auml;llige Daten, die in der Importdatei hinter der E-Mail-Adresse stehen, werden als Attribut "Info" des jeweiligen Benutzers gespeichert.
<br /><br />
<?php echo PageLink2("import","Andere Importmethode w&auml;hlen");?><br />
