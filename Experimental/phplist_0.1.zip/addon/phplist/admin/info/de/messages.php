<p>Hier finden Sie alle im System vorhanden Nachrichten, geordnet nach ihrem Status:</p>
<p><strong>sent</strong> = gesendet<br />
<strong>draft</strong> = Entwurf (noch kein Versand geplant)<br />
<strong>submitted</strong> = Versand geplant (Nachricht befindet sich in der Wartschlange, wird zur Zeit verschickt oder wartet eine Sperrfrist ab)<br />
<strong>prepared</strong> = Vorlage (fertig erstellt, aber noch kein Versand geplant)
</p>
<p>Um eine Nachricht nochmals an diejenigen Abonnenten zu senden, welche sich erst nach einem Versand f&uuml;r diese Liste angemeldet haben,
benutzen Sie den Befehl "erneut senden". Abonnenten, welche die Nachricht schon fr&uuml;her erhalten haben, erhalten sie dadurch kein zweites Mal.</p>
<p>Um eine Nachricht an eine andere Liste zu senden, benutzen Sie die entsprechende Funktion in der Detailansicht dieser Nachricht.</p>
<?php if (TEST) { ?>
<br /><b>Hinweis:</b> Das System befindet sich im Test-Modus. Dadurch werden Nachrichten auch an Abonnenten gesendet, welche diese bereits erhalten haben.
<?php } ?>
