<p>Hier finden Sie alle Funktionen f&uuml;r die Verwaltung der Abonnenten.
Sie k&ouml;nnen Abonnenten suchen, anzeigen, importieren und exportieren.
Zudem stehen Ihnen verschiedene Funktionen zur Bereinigung der Abonnenten-Datenbank zur Verf&uuml;gung, um ung&uuml;ltige Eintr&auml;ge zu finden.</p>
<p>Falls Sie hingegen die Abonnenten einer bestimmten Liste anzeigen m&ouml;chten, dann <?php echo PageLink2("list","gehen Sie zur betreffenden Liste")?>  und klicken Sie "Abonnenten bearbeiten".</p>