<h1>Esta p&aacute;gina muestra una lista de cosas que hay que instalar
para poner <?php echo NAME?> en marcha correctamente</h1>

