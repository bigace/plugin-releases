<p><h1>Esta p&aacute;gina le permite limpiar la base de datos de usuarios</h1></p>
