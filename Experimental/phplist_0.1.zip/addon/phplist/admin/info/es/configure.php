<p>Aqu&iacute; tiene que especificar los valores adecuados para su
sitio web.<br/>
Puede usar ciertos <b>Marcadores</b> en sus valores.
Los marcadores tienen este aspecto: <b>[TEXTO]</b>, teniendo en cuenta
que en lugar de <i>TEXTO</i> van una serie de palabras clave.
Algunos marcadores &uacute;tiles son:
<ul>
<li>WEBSITE - la direcci&oacute;n p&uacute;blica de su sitio web
<li>DOMAIN - el nombre de su dominio
<li>SUBSCRIBEURL - la direcci&oacute;n de su p&aacute;gina de inscripci&oacute;n
<li>UNSUBSCRIBEURL - la direcci&oacute;n de su p&aacute;gina para desinscribirse
<li>PREFERENCESURL - la direcci&oacute;n de la p&aacute;gina donde los
usuarios pueden poner al d&iacute;a su informaci&oacute;n
<li>CONFIRMATIONURL - la direcci&oacute;n de la p&aacute;gina donde los
usuarios deben confirmar su inscripci&oacute;n
</ul>
<!--Para la cabecera y el pie puede usar el siguiente c&oacute;digo
para incluir documentos externos:
<br/>
<b>[URL:&lt;URL completa de la p&aacute;gina que hay que cargar&gt;]</b>-->
</p>
