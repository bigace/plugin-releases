<hr/>
<p>Establecer permisos para ver p&aacute;ginas del sistema:</p>
<ul>
<li>Todos: el administrador tiene aaceso a la p&aacute;gina sin restricciones</li>
<li>Ver: el administrador puede ver las p&aacute;ginas, pero no puede
cambiar nada. De momento esto solo funciona en las p&aacute;ginas
&#171;usuario&#187;, &#171;usuarios&#187; y &#171;miembros&#187;.</li>
<li>Ninguno: el administrador no puede ver esta p&aacute;gina</li>
<li>Due&ntilde;o: el administrador puede ver esta p&aacute;gina, pero
solo puede ver el contenido de las listas de las que es due&ntilde;o</li>
</ul>
