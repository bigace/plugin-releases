<br/>
<p>Thank you for using <?php echo NAME?>.<br>We hope you achieved your aim.</p>
<p>You are now logged out.</p>
<p>To log in again, click <a href='?page=home'>here</a>.</p>

