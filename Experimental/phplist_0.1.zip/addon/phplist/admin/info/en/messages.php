You can use "Requeue" to resend a message. This will cause the message to be sent to users who have subscribed after you sent the message. It will not be sent to users who have already received the message.
<p>If you view a message, you will be able to resend it to a different list</p>
<?php if (TEST) { ?>
<br /><b>Note:</b> You are operating in test mode, so messages will be "resend" to users who have received it.
<?php } ?>
