<p>Here you can identify the attributes you want people to enter, in order to sign up for the lists.
<br />Attributes are "global" ie, they apply to all lists.</p>
<p><a href="#new">Add a new one</a></p>
