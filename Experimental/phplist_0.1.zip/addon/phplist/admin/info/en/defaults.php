<h1>Add some possible useful attributes</h1>
Choose the attributes you want to add to your mailinglist system: