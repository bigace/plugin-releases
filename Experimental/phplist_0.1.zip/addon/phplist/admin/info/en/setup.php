<h1>This page show a quick checklist of things to set up in order to get <?php echo NAME?> working correctly</h1>

