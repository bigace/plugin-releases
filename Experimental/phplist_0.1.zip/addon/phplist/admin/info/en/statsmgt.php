
<p>This page shows the available statistics for retrieval. It is currently still a bit rough and will need updating in future versions.</p>
<p>Post your comments and suggestions to <a href="http://mantis.tincan.co.uk">Mantis</a></p>