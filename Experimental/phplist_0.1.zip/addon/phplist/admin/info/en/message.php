<br /><?php echo PageLink2("messages","Back to the list of Messages")?>
<br /><a href="#resend">Send this message to a different list</a>
