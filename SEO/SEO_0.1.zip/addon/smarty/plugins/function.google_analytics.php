<?php
/*
 * Smarty plugin
 * -------------------------------------------------------------
 * File:     function.google_analytics.php
 * Type:     function
 * Name:     google_analytics
 * 
 * Prints or assigns the *NEW* Javascript Code for Google Analytics. 
 *
 * @license http://opensource.org/licenses/gpl-license.php GNU Public License
 * @author Swen Wendler, Kevin Papst
 * @copyright Copyright (C) Swen Wendler, Kevin Papst
 * @version $Id: function.google_analytics.php,v 1.1 2008/04/23 23:34:55 kpapst Exp $
 * -------------------------------------------------------------
 * Parameter:
 * 'id' 	= googles analytics id (UA-xxxxxx-x)
 * 'assign' = name of tpl variable to assign the javascript code to 
 */
function smarty_function_google_analytics($params, &$smarty)
{
    if(!isset($params['id'])) {
        $smarty->trigger_error("google_analytics: missing 'id' attribute");
        return;
    }

    $badge  = "<script type=\"text/javascript\">\n";
    $badge .= "  var gaJsHost = ((\"https:\" == document.location.protocol) ? \"https://ssl.\" : \"http://www.\");\n";   
    $badge .= "  document.write(unescape(\"%3Cscript src='\" + gaJsHost + \"google-analytics.com/ga.js' type='text/javascript'%3E%3C/script%3E\"));\n";   
    $badge .= "  var pageTracker = _gat._getTracker(\"".trim($params['id'])."\");\n";   
    $badge .= "  pageTracker._initData();\n";   
    $badge .= "  pageTracker._trackPageview();\n";   
    $badge .= "</script>\n";

    
	if(isset($params['assign'])) {
		$smarty->assign($params['assign'], $badge);
		return;
	}
	
	return $badge;
}

?>