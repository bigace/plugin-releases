<?php
/**
* Translation file for Administration - TipOfTheDay
*
* Language: deutsch (default)
* Locale:   de
*
* Copyright (C) 2003-2004 Kevin Papst. 
*
* For further information go to http://www.kevinpapst.de/ 
* or contact bigace@kevinpapst.de.
*
* @version $Id: translation.lang.php,v 1.1 2005/10/20 20:33:11 kpapst Exp $
* @author Kevin Papst <bigace@kevinpapst.de>
* @package bigace.translation
*/

$LANG['menu_tipoftheday']   	  = 'Tip des Tages';
$LANG['title_tipoftheday']        = 'Tip des Tages';
$LANG['description_tipoftheday']  = 'Hier k&ouml;nnen Sie Ihre rotierenden Tips bearbeiten.';

$LANG['totd_delete_entry']      	= 'Eintrag entfernen';
$LANG['totd_edit_entry']        	= 'Eintrag bearbeiten';

$LANG['totd_name']              = 'Titel';
$LANG['totd_link']            	= 'Link';
$LANG['totd_tip']            	= 'Eintrag';

$LANG['totd_Create']            = 'Anlegen';
$LANG['totd_Edit']            	= '&Auml;ndern';
$LANG['totd_Save']            	= 'Speichern';
$LANG['totd_Delete']            = 'L&ouml;schen';

?>