INSERT INTO {DB_PREFIX}frights (cid,name,defaultvalue,description) VALUES 
({CID}, 'tipoftheday', 'N', 'Allow User to administrate the TIPs for TIP-OF-THE-DAY.');
