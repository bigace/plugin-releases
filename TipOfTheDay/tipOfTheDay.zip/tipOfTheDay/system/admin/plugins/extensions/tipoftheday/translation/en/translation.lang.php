<?php
/**
* Translation file for Administration - TipOfTheDay
*
* Language: english
* Locale:   en
*
* Copyright (C) 2003-2004 Kevin Papst. 
*
* For further information go to http://www.kevinpapst.de/ 
* or contact bigace@kevinpapst.de.
*
* @version $Id: translation.lang.php,v 1.1 2005/05/31 18:22:42 Kevin Exp $
* @author Kevin Papst <bigace@kevinpapst.de>
* @package bigace.translation
*/

$LANG['menu_tipoftheday']   	    = 'Tip of the Day';
$LANG['title_tipoftheday']          = 'Tip of the Day';
$LANG['description_tipoftheday']    = 'Administrate your Tips.';

$LANG['totd_delete_entry']          = 'Delete entry';
$LANG['totd_edit_entry']            = 'Edit entry';

$LANG['totd_name']                  = 'Title';
$LANG['totd_link']            	    = 'Link';
$LANG['totd_tip']            	    = 'Tip';

$LANG['totd_Create']                = 'Create';
$LANG['totd_Edit']            	    = 'Change';
$LANG['totd_Save']            	    = 'Save';
$LANG['totd_Delete']                = 'Delete';

?>