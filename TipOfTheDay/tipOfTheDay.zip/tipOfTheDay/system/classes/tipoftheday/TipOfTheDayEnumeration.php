<?php

loadClass('tipoftheday', 'TipOfTheDay');

/**
* Can be used to receive all or a list of Guestbook Entrys
*
* Copyright (C) 2003-2004 Kevin Papst. 
*
* For further information go to {@link http://www.kevinpapst.de www.kevinpapst.de}.
*
* @version $Id: TipOfTheDayEnumeration.php,v 1.1 2005/05/31 18:23:02 Kevin Exp $
* @author Kevin Papst <bigace@kevinpapst.de>
* @package bigace.classes.tipoftheday
*/
class TipOfTheDayEnumeration
{

	var $all;
	
	function TipOfTheDayEnumeration($from = '0', $limit = '-1')
	{
	    $LIM = '';
	    if ($limit != '-1') {
	        $LIM = " LIMIT ".$from.",".$limit;
	    }
	    $sql = $GLOBALS['_BIGACE']['SQL_HELPER']->loadAndPrepareStatement('tipoftheday_enum', array('CID' => _CID_, 'LIMIT' => $LIM));
		$this->all = $GLOBALS['_BIGACE']['SQL_HELPER']->execute($sql);
		unset ($sql);
	}

	function next()
	{
		$temp = $this->all->getNextResult();
		return new TipOfTheDay($temp["id"]);
	}

	function count()
	{
	    if ($this->all) {
    		return $this->all->countResult();
	    } else {
	        return 0;
	    }
	}
	
}

?>