<?php

/**
* Adminservice for your rotating Tips.
*
* Copyright (C) 2003-2004 Kevin Papst. 
*
* For further information go to {@link http://www.kevinpapst.de www.kevinpapst.de}.
*
* @version $Id: TipOfTheDayAdminService.php,v 1.1 2005/05/31 18:23:02 Kevin Exp $
* @author Kevin Papst <bigace@kevinpapst.de>
* @package bigace.classes.tipoftheday
*/

class TipOfTheDayAdminService 
{

    /**
    * Creates a new Tip-of-the-Day Entry
    *
    * @param    String  the Name
    * @param    String  the Link
    * @param    String  the Tip
    * @return   int     the new generated Tip-of-the-Day Entry ID
    */
    function createEntry($name, $link, $tip)
    {
	    $values = array( 'NAME'     => $name,
	                     'LINK'     => $link,
	                     'TIP'      => $tip );
        $sqlString = $GLOBALS['_BIGACE']['SQL_HELPER']->loadStatement('tipoftheday_create');
	    $sqlString = $GLOBALS['_BIGACE']['SQL_HELPER']->prepareStatement($sqlString, $values);
        return $GLOBALS['_BIGACE']['SQL_HELPER']->insert($sqlString);
    }

    /**
    * This changes a single Tip-of-the-Day Entry
    *
    * @param    int     the Entry ID to change
    * @param    String  the Name
    * @param    String  the Link
    * @param    String  the Tip
    * @return   Object  the DB Result for this UPDATE
    */
    function changeEntry($id, $name, $link, $tip)
    {
	    $values = array( 'ID'       => $id,
	                     'NAME'     => $name,
	                     'LINK'     => $link,
	                     'TIP'      => $tip );
        $sqlString = $GLOBALS['_BIGACE']['SQL_HELPER']->loadStatement('tipoftheday_change');
	    $sqlString = $GLOBALS['_BIGACE']['SQL_HELPER']->prepareStatement($sqlString, $values);
        return $GLOBALS['_BIGACE']['SQL_HELPER']->execute($sqlString);
    }

    /**
    * Deletes a Tip-of-the-Day Entry
    *
    * @param    int     the Tip-of-the-Day Entry ID
    * @return   Object  the DB Result for this DELETE
    */
    function deleteEntry($id)
    {
	    $values = array( 'ID' => $id );
        $sqlString = $GLOBALS['_BIGACE']['SQL_HELPER']->loadStatement('tipoftheday_delete');
	    $sqlString = $GLOBALS['_BIGACE']['SQL_HELPER']->prepareStatement($sqlString, $values);
        return $GLOBALS['_BIGACE']['SQL_HELPER']->execute($sqlString);
    }
    
    
}


?>