CREATE TABLE `tipoftheday` (
  `id` int(11) NOT NULL auto_increment,
  `cid` int(11) NOT NULL default '0',
  `name` varchar(255) NOT NULL default '',
  `link` varchar(255) default '',
  `tip` text NOT NULL,
  PRIMARY KEY  (`id`)
) TYPE=MyISAM ;
