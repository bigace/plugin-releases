<?php
/**
* Translation file for Modul - Tip of the Day
*
* Language: deutsch (default)
* Locale:   de
*
* Copyright (C) 2003-2004 Kevin Papst. 
*
* For further information go to http://www.kevinpapst.de/ 
* or contact bigace@kevinpapst.de.
*
* @version $Id: modul.lang.php,v 1.1 2005/04/30 21:28:28 Kevin Exp $
* @author Kevin Papst <bigace@kevinpapst.de>
* @package bigace.translation
*/

$LANG['modul_name_tipOfTheDay']    		    = 'Tip des Tages';
$LANG['modul_title_tipOfTheDay']    		= 'Tip of the Day';
$LANG['modul_description_tipOfTheDay']  	= 'Mit diesem Modul zeigen Sie einen zuf�llig gew�hlten Eintrag aus der Tip-des-Tages Datenbank!';

?>