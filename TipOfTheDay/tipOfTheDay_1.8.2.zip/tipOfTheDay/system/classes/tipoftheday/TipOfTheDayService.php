<?php

/**
* Tip of the Day Service Implementation
*
* Copyright (C) 2003-2004 Kevin Papst. 
*
* For further information go to {@link http://www.kevinpapst.de www.kevinpapst.de}.
*
* @version $Id: TipOfTheDayService.php,v 1.1 2005/10/20 20:33:25 kpapst Exp $
* @author Kevin Papst <bigace@kevinpapst.de>
* @package bigace.classes.tipoftheday
*/
class TipOfTheDayService
{
    
    var $tips;

    function TipOfTheDayService()
    {
    }
    
    function getMaxTip()
    {
        return $this->getAny('max(id)');
    }
    
    function getMinTip() 
    {
        return $this->getAny('min(id)');
    }
    
    function getAny($what) 
    {
		$sqlString = $GLOBALS['_BIGACE']['SQL_HELPER']->loadStatement('tipOfTheDay_selectAny');
	    $sqlString = $GLOBALS['_BIGACE']['SQL_HELPER']->prepareStatement($sqlString, array('CID' => _CID_, 'WHAT' => $what));
	    $temp = $GLOBALS['_BIGACE']['SQL_HELPER']->execute($sqlString);
		$temp = $temp->getNextResult();
		return $temp[0];
    }
    
    function existsTip($id)
    {
		$sqlString = $GLOBALS['_BIGACE']['SQL_HELPER']->loadStatement('tipOfTheDay_loadTip');
	    $sqlString = $GLOBALS['_BIGACE']['SQL_HELPER']->prepareStatement($sqlString, array('CID' => _CID_, 'ID' => $id));
	    $temp = $GLOBALS['_BIGACE']['SQL_HELPER']->execute($sqlString);
		if ($temp && $temp->countResult() > 0) {
		    return true;
		}
        return false;
    }

    function make_seed() {
        list($usec, $sec) = explode(' ', microtime());
        return (float) $sec + ((float) $usec * 100000);
    }
    
    function getRandomNumber($min, $max)
    {
        srand($this->make_seed());
        return rand($min, $max);
    }

    function getRandomTip()
    {
        $min = $this->getMinTip();
        $max = $this->getMaxTip();
        
        if ($min >= 0 && $max >= 0 && $max >= $min) {
            do {
                $id = $this->getRandomNumber($this->getMinTip(), $this->getMaxTip());
            } while ( !$this->existsTip($id) );

            return $this->getTip($id);
        }
        return null;
    }
    
    function getTip($id)
    {
        return new TipOfTheDay($id);
    }

}

?>