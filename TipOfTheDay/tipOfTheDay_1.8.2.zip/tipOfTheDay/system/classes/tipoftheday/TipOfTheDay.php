<?php

/**
* A small Tip of the Day Implementation
*
* Copyright (C) Kevin Papst. 
*
* For further information go to {@link http://www.kevinpapst.de www.kevinpapst.de}.
*
* @version $Id: TipOfTheDay.php,v 1.1 2005/10/20 20:33:25 kpapst Exp $
* @author Kevin Papst <bigace@kevinpapst.de>
* @package bigace.classes.tipoftheday
*/

class TipOfTheDay
{
    
    var $tip;

    function TipOfTheDay($id)
    {
		$sqlString = $GLOBALS['_BIGACE']['SQL_HELPER']->loadStatement('tipOfTheDay_loadTip');
	    $sqlString = $GLOBALS['_BIGACE']['SQL_HELPER']->prepareStatement($sqlString, array('CID' => _CID_, 'ID' => $id));
	    $this->tip = $GLOBALS['_BIGACE']['SQL_HELPER']->execute($sqlString);
	    $this->tip = $this->tip->getNextResult();
    }
    
    function getID()
    {
        return $this->tip["id"];
    }

    function getName()
    {
        return $this->tip["name"];
    }
    
    function getLink()
    {
        return $this->tip["link"];
    }
    
    function getTip()
    {
        return $this->tip["tip"];
    }
    
}

?>