<?php
/**
* Translation file for Administration - TipOfTheDay
*
* Language: english
* Locale:   en
*
* Copyright (C) Kevin Papst. 
*
* For further information go to http://www.bigace.de/ 
*
* @version $Id: tipoftheday.lang.php,v 1.1 2009/05/12 14:27:47 kpapst Exp $
* @author Kevin Papst 
* @package bigace.translation
*/

$LANG['menu_tipoftheday']   	    = 'Tip of the Day';
$LANG['title_tipoftheday']          = 'Tip of the Day';
$LANG['description_tipoftheday']    = 'Administrate your Tips.';

$LANG['totd_delete_entry']          = 'Delete entry';
$LANG['totd_edit_entry']            = 'Edit entry';

$LANG['totd_name']                  = 'Title';
$LANG['totd_link']            	    = 'Link';
$LANG['totd_tip']            	    = 'Tip';

$LANG['totd_Create']                = 'Create';
$LANG['totd_Edit']            	    = 'Change';
$LANG['totd_Save']            	    = 'Save';
$LANG['totd_Delete']                = 'Delete';

?>