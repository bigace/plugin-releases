UPDATE {DB_PREFIX}tipoftheday SET namespace={NAMESPACE}, title={TITLE}, link={LINK}, tip={TIP} WHERE id={ID} AND cid={CID}
