INSERT INTO {DB_PREFIX}tipoftheday (cid, namespace, title, link, tip) VALUES ({CID}, {NAMESPACE}, {TITLE}, {LINK}, {TIP})
