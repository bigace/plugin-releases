  README FOR TIP-OF-THE-DAY
-----------------------------
Current Version: $Id: readme.txt,v 1.1 2005/10/20 20:33:25 kpapst Exp $
Author: Kevin Papst
################################################################################

Tip of the Day is a Modul, which stores its Tip in the DB. Tips can be added,
modified or deleted via an Extension in the Standard Administration.
For each request the Modul fetches a random TIP from the Pool and displays it.
If you want to customze this behavior go ahead, edit the TipOfTheDay Classes!

Functional Right:
------------------
After the installation of the tipOfTheDay Update, you have to manually create
a Functional Right called "tipoftheday".
Assign this right to each group that may edit your Tips.

Modul:
-------
Now go ahead, create a new Page or simply assign the new Modul to an existing 
Menu and see what happens ;)

Look & Feel:
-------------
If you want to customize the Output, please take a look on the Moduls 
Sourcecode or simply add the following "TAGs" (which will be replaced by the 
Modul) to the Menus Content:

{TIP-OF-THE-DAY}        = the text of the randomized TIP
{NAME-OF-THE-DAY}       = the title of the randomized TIP
{LINK-OF-THE-DAY}

The replacement will be done if and only if the TAG {TIP-OF-THE-DAY} can be 
found within the Menus Content!
Otherwise the Tip will be appended at the Pages Bottom. Please test both 
versions, currently the Support for Links is better in the "automatic"
version!

Please share any Comment with the Author!