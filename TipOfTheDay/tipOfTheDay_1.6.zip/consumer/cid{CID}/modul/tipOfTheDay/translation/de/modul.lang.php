<?php
/**
 * Translation file for Modul - Tip of the Day
 *
 * Language: deutsch (default)
 * Locale:   de
 *
 * Copyright (C) Kevin Papst. 
 * 
 * For further information go to http://www.bigace.de/
 *
 * @version $Id: modul.lang.php,v 1.3 2008/01/25 10:31:25 kpapst Exp $
 * @author Kevin Papst 
 * @package bigace.translation
 */

$LANG['name']    		= 'Tip des Tages';
$LANG['title']    		= 'Tip des Tages';
$LANG['description']  	= 'Mit diesem Modul zeigen Sie einen zuf&auml;llig gew&auml;hlten Eintrag aus der Tip-des-Tages Datenbank!';

?>