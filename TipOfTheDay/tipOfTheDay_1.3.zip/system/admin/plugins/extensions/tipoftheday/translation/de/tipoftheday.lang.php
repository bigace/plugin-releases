<?php
/**
* Translation file for Administration - TipOfTheDay
*
* Language: deutsch (default)
* Locale:   de
*
* Copyright (C) Kevin Papst. 
*
* For further information go to http://www.bigace.de/ 
*
* @version $Id: tipoftheday.lang.php,v 1.2 2006/11/26 21:59:01 kpapst Exp $
* @author Kevin Papst 
* @package bigace.translation
*/

$LANG['menu_tipoftheday']   	  = 'Tip des Tages';
$LANG['title_tipoftheday']        = 'Tip des Tages';
$LANG['description_tipoftheday']  = 'Hier k&ouml;nnen Sie Ihre rotierenden Tips bearbeiten.';

$LANG['totd_delete_entry']      	= 'Eintrag entfernen';
$LANG['totd_edit_entry']        	= 'Eintrag bearbeiten';

$LANG['totd_name']              = 'Titel';
$LANG['totd_link']            	= 'Link';
$LANG['totd_tip']            	= 'Eintrag';

$LANG['totd_Create']            = 'Anlegen';
$LANG['totd_Edit']            	= '&Auml;ndern';
$LANG['totd_Save']            	= 'Speichern';
$LANG['totd_Delete']            = 'L&ouml;schen';

?>