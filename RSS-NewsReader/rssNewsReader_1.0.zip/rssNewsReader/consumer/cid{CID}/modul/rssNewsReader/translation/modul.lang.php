<?php
/**
* Translation file for Modul - Aktuell.ru
*
* Language: deutsch (default)
* Locale:   de
*
* Copyright (C) 2003-2004 Kevin Papst. 
*
* For further information go to http://www.kevinpapst.de/ 
* or contact bigace@kevinpapst.de.
*
* @version $Id: modul.lang.php,v 1.1 2005/10/20 20:32:09 kpapst Exp $
* @author Kevin Papst <bigace@kevinpapst.de>
* @package bigace.translation
*/

$LANG['modul_name_rssNewsReader']    		= 'RSS News Reader';
$LANG['modul_title_rssNewsReader']    		= 'RSS Reader - mit konfigurierbaren RSS NewsFeeds';
$LANG['modul_description_rssNewsReader']  	= 'Mit diesem konfigurierbaren RSS Reader bieten Sie Ihren Besuchern eine Vorschau verschiedenster News Feeds.';

?>