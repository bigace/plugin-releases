<?php
/**
* Simple RSS News Reader
*
* Copyright (C) Kevin Papst. 
*
* For further information go to http://www.kevinpapst.de/ 
* or contact bigace@kevinpapst.de.
*
* @version $Id: modul.php,v 1.2 2006/04/09 21:28:53 kpapst Exp $
* @author Kevin Papst <bigace@kevinpapst.de>
* @package bigace.modul
*/

loadClass('rss','RSSParser');

$feedFileName = dirname(__FILE__) . '/rssList.ini' ;
$newsFeedURLs = parse_ini_file ( $feedFileName, TRUE);

// Configuration array
$_NEWS                      = array();
$_NEWS['PARAM_URL']         = 'newsfeedUrl';
$_NEWS['PARAM_ACTION']      = 'newsAction';
$_NEWS['ACTION_READ']       = 'newsRead';

$newsAction         = isset($_POST[$_NEWS['PARAM_ACTION']]) ? $_POST[$_NEWS['PARAM_ACTION']] : '-1';
$feedUrl            = isset($_POST[$_NEWS['PARAM_URL']]) ? $_POST[$_NEWS['PARAM_URL']] : '';

$colspan = count($newsFeedURLs);
?>
<div>
<form name="newfeedForm" action="<?php echo createMenuLink($MENU->getID()); ?>" method="POST">
<input type="hidden" name="<?php echo $_NEWS['PARAM_ACTION']; ?>" value="<?php echo $_NEWS['ACTION_READ']; ?>">
<table align="center" class="ct" cellpadding="2" cellspacing="2" width="90%">
    <tr>
        <th colspan="<?php echo count($newsFeedURLs); ?>">
            <table border="0" width="100%">
            <tr>
                <td>Newsquelle aussuchen:</td>
                <td align="right" valign="top"><img src="<?php echo $GLOBALS['_BIGACE']['DIR']['public']; ?>system/images/rss.png" border="0" alt="RSS News lesen"></td>
            </tr>
            </table>
        </th>
    </tr>
    <tr>
        <td colspan="<?php echo $colspan; ?>">&nbsp;</td>
    </tr>
    <tr>
    <?php
    
    foreach ($newsFeedURLs AS $desc => $urls)
    {
        ?>
        <td>
            <b><?php echo $desc; ?></b>
        </td>
        <?php
    }
    
    ?>
    </tr>
    <tr>
    <?php
    
    foreach ($newsFeedURLs AS $desc => $urls)
    {
        ?>
        <td valign="top">
            <?php
            
                foreach ($urls as $newsName => $newsUrl)
                {
                    echo '<input type="radio" name="' . $_NEWS['PARAM_URL'] . '" value="' . $newsUrl . '"';
                    if ($newsUrl == $feedUrl) {
                        echo ' checked';
                    }
                    echo '>' . $newsName . '<br>'."\n";
                }
                
            ?>
        </td>
        <?php
    
        unset ($urls);
        unset ($desc);
    
    }
    
    ?>
    </tr>
    <tr>
        <td colspan="<?php echo $colspan; ?>">&nbsp;</td>
    </tr>
    <tr>
        <td colspan="<?php echo $colspan; ?>" align="left"><input type="submit" value="Lesen"></td>
    </tr>
</table>

</form>
</div>

<?php

if ($newsAction == $_NEWS['ACTION_READ'])
{

    $message = '';
    $seenFeed = false;
    $parseUrl = $feedUrl;
    
    if ($parseUrl != '')
    {
        $rss = new RSSParserCache($GLOBALS['_BIGACE']['DIR']['cache']);
        $rss->enableCaching();
        $rss->setLifetime(3600);
        $rss->OutputOptions(array('ChannelDesc' => TRUE,   // Channel - Beschreibung
                                  'ItemDesc'    => TRUE,   // Item - Beschreibung
                                  'Image'       => true,   // eventuell 'enthaltene' Grafik
                                  'Textinput'   => false    // eventuell 'enthaltenes' Formular
                                  ));
        $rss->OutputStyles(array('maxItem'        => 15,           // maximale Anzahl von angezeigten Items, wenn der Channel mehr enth�lt
                                 'ItemSeparator'  => '&nbsp;',       // Trenner zwischen den Items
                                 'DescSeparator'  => '<br>',        // Trenner zwischen Titel, Beschreibung und Link
                                 'ChannelTitle'   => '',           // CSS class f�r Channel-Titel
                                 'ChannelDesc'    => '',           // CSS class f�r Channel-Beschreibung
                                 'ChannelLink'    => '',           // CSS class f�r Channel-Link
                                 'ItemTitle'      => '',           // CSS class f�r Item-Titel
                                 'ItemDesc'       => '',           // CSS class f�r Item-Beschreibung
                                 'ItemLink'       => '',           // CSS class f�r Item-Link
                                 'TextInputTitle' => '',           // CSS class f�r TextInput-Titel
                                 'TextInputDesc'  => '',           // CSS class f�r TextInput-Beschreibung
                                 'TextInput'      => '',           // CSS class f�r TextInput-Feld
                                 'Submit'         => '',           // CSS class f�r TextInput-Submit
                                 'SubmitValue'    => 'GO',         // Submit Button Beschriftung
                                 'TableWidth'     => '90%',       // Tabellenbreite des Channels
                                 'TableClass'     => 'ct',         
                                 'TableAlign'     => 'center',
                                 'LinkTarget'     => '_blank'      // Linkziel f�r Links, die im channel enthalten sind
                                 ));
        
        
        $seenFeed = true;
        if ($out = $rss->parseRSS($parseUrl)) 
        {
            echo '<div>' . $out . '</div><br>';
        } 
        else 
        {
            $message .= 'URL: <i>' . $parseUrl . '</i><br>Fehlercode: '.$rss->getErrorCode().'<br>Fehlermeldung: '.$rss->getErrorMessage();
        }
    } // if ($parseUrl != '')


    if (!$seenFeed)
    {
        $message .= 'Bitte geben Sie ein Newsfeed an!';
    }
    

    echo '<div><table align="center" style="border-width:1px; border-style=dashed"><tr><td><b>' . $message . '</b></td></tr></table></div><br>';
}

?>