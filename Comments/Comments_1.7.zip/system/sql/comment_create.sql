INSERT INTO {DB_PREFIX}comments 
(`cid`, `itemtype`, `itemid`, `language`, `name`, `email`, `homepage`, `ip`, `comment`, `timestamp`, `activated`, `type`) 
VALUES 
({CID}, {ITEMTYPE}, {ITEMID}, {LANGUAGE}, {NAME}, {EMAIL}, {HOMEPAGE}, {IP}, {COMMENT}, {TIMESTAMP}, {ACTIVE}, {TYPE})
