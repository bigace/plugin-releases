<?php

/*
 * Smarty modifier
 * -------------------------------------------------------------
 * File:     modifier.utf8.php
 * Type:     function
 * Name:     utf8
 * Purpose:  UTF8 encodes the given String    
 * -------------------------------------------------------------
 */
function smarty_modifier_utf8($str)
{
    return utf8_encode($str);
}

?> 