<?php
/*
Plugin Name: Comments Plugin 
Plugin URI: http://wiki.bigace.de/bigace:extensions:addon:comments
Description: This plugins brings per-page configuration for comments, an administration page and a template include to display comment forms. Please read the <a href="http://wiki.bigace.de/bigace:extensions:addon:comments" target="_blank">Comments Documentation</a> on how to install and configure this Plugin properly.
Author: Kevin Papst
Version: 0.2
Author URI: http://www.kevinpapst.de/
$Id: comments.php,v 1.1 2009/02/28 00:51:32 kpapst Exp $
*/

if(!defined('_BIGACE_ID'))
    die('Ooops');

Hooks::add_filter('admin_menu', 'comment_admin_menu', 10, 1);
Hooks::add_filter('edit_item_meta', 'comment_item_attributes', 10, 2);
Hooks::add_filter('create_item_meta', 'comment_create_item_attributes', 10, 2);
Hooks::add_action('update_item', 'update_comment_item', 10, 5);

// activates the comment admin menu
function comment_admin_menu($menu)
{
    $menu['extensions']['childs']['comments'] = array(
            'permission'    => 'comments.activate,comments.edit,comments.delete', 
            'menu.translate'=> true,
            'pluginpath'    => 'comments'
    );
    return $menu;
}

function comment_create_item_attributes($values, $itemtype)
{
    if($itemtype == _BIGACE_ITEM_MENU)
    {
		$values['Comments'] = '
                <table border="0">
                    <col width="170"/>
                    <col />
                <tr>
                    <td valign="top">Allow Comments</td>
                    <td>
                        <input type="radio" id="allow_comments_yes" name="allow_comments" value="'.intval(true).'" checked />
                        <label for="allow_comments_yes">Yes</label>
                        <br/>
                        <input type="radio" id="allow_comments_no" name="allow_comments" value="'.intval(false).'" />
                        <label for="allow_comments_no">No</label>
                    </td>
                </tr>
                </table>
        ';
    }
	return $values;        
}

function comment_item_attributes($values, $item)
{
    if($item->getItemtypeID() == _BIGACE_ITEM_MENU)
    {
        import('classes.item.ItemProjectService');

        $ips = new ItemProjectService(_BIGACE_ITEM_MENU);
        $commentsAllowed = $ips->getBool($item->getID(), $item->getLanguageID(), 'allow_comments', true);
        
        $values['Comments'] = '
                <table border="0">
                    <col width="170"/>
                    <col />
	                <tr>
	                    <td valign="top">Allow Comments</td>
	                    <td>
	                        <input type="radio" id="allow_comments_yes" name="allow_comments" value="'.intval(true).'" '.($commentsAllowed ? 'checked ' : '').'/>
	                        <label for="allow_comments_yes">Yes</label>
	                        <br/>
	                        <input type="radio" id="allow_comments_no" name="allow_comments" value="'.intval(false).'" '.(!$commentsAllowed ? 'checked ' : '').'/>
	                        <label for="allow_comments_no">No</label>
	                    </td>
	                </tr>
                </table>
        ';
    }
    
    return $values;
}

// update item which was submitted with the general item attribute admin screen
function update_comment_item($itemtype, $id, $langid, $val, $timestamp)
{
    import('classes.item.ItemAdminService');
    if(isset($_POST['allow_comments']))
    {
        $ias = new ItemAdminService($itemtype);
        $ias->setProjectNum($id, $langid, 'allow_comments', $_POST['allow_comments']);
    }
}
