SELECT `counter` 
FROM {DB_PREFIX}comment_spam_counter 
WHERE `cid` = {CID}
