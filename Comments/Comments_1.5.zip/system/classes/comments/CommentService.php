<?php
/**
 * BIGACE - a PHP and MySQL based Web CMS.
 * Copyright (C) Kevin Papst.
 *
 * BIGACE is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * BIGACE is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software Foundation,
 * Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 *
 * For further information visit {@link http://www.bigace.de http://www.bigace.de}.
 *
 * @package bigace.classes
 * @subpackage comments
 */

import('classes.item.ItemProjectService');

/**
 * Some standard functions for handling trackbacks and comments
 *
 * @license http://opensource.org/licenses/gpl-license.php GNU Public License
 * @author Kevin Papst 
 * @copyright Copyright (C) Kevin Papst
 * @version $Id: CommentService.php,v 1.1 2009/02/28 00:51:32 kpapst Exp $
 * @package bigace.classes
 * @subpackage comments
 */
class CommentService
{

	public static function checkTrackbackDuplicate($itemtype, $id, $language, $url)
	{
		$values = array('ITEMTYPE' => $itemtype, 'ID' => $id, 'LANGUAGE' => $language, 'URL' => $url);
		$res = $GLOBALS['_BIGACE']['SQL_HELPER']->sql('comment_find_duplicate_trackback', $values);
		if($res->count() > 0)
			return true;
		return false;
	}

	public static function checkCommentDuplicate($itemtype, $id, $language, $name, $content)
	{
		$values = array('ITEMTYPE' => $itemtype, 'ID' => $id, 'LANGUAGE' => $language, 'NAME' => $url, 'COMMENT' => $content);
		$res = $GLOBALS['_BIGACE']['SQL_HELPER']->sql('comment_find_duplicate', $values);
		if($res->count() > 0)
			return true;
		return false;
	}
	
	/**
	 * Check if trackbacks are allowed for this item.
	 */
	public static function activeTrackbacks($itemtype, $id, $language) 
	{
		$ips = new ItemProjectService($itemtype);
		return $ips->getBool($id, $language, 'trackbacks', false);
	}
	
	/**
	 * Check if comments are allowed for this item.
	 */
	public static function activeComments($itemtype, $id, $language) 
	{
		$ips = new ItemProjectService($itemtype);
		return $ips->getBool($id, $language, 'comments', false);
	}
}

?>