SELECT * FROM 
	{DB_PREFIX}comments 
WHERE
	`cid` = {CID} AND `id` = {ID}
