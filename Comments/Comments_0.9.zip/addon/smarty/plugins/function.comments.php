<?php

/*
 * Smarty plugin
 * -------------------------------------------------------------
 * File:     function.comments.php
 * Type:     function
 * Name:     comments
 * Purpose:  Fetches an array of Comments for an Item. Is also
 *           capable to create Comments items.
 * -------------------------------------------------------------
 * - assign
 * - preview
 * 
 * - item 
 *   OR 
 * - id
 * - language
 * - itemtype (default: _BIGACE_ITEM_MENU) 
 */
function smarty_function_comments($params, &$smarty)
{	
	if(!isset($params['assign'])) {
		$smarty->trigger_error("comments: missing 'assign' attribute");
		return;
	}
	if(!isset($params['preview'])) {
		$smarty->trigger_error("comments: missing 'preview' attribute");
		return;
	}
	
	if(isset($params['item']))
	{
		$itemtype = $params['item']->getItemTypeID(); 
		$id = $params['item']->getID();
		$language = $params['item']->getLanguageID();
	}
	else
	{
		if(!isset($params['id']) || !isset($params['language']) ) {
			$smarty->trigger_error("comments: missing 'id' or 'language' attribute");
			return;
		}
		$itemtype = (isset($params['itemtype']) ? $params['itemtype'] : _BIGACE_ITEM_MENU); 
		$id = $params['id'];
		$language = $params['language'];
	}
	
	// empty preview
	$preview = array(
		'name' 		=> '',
		'email'		=> '',
		'homepage'	=> '',
		'comment'	=> ''
	);
	
	if(isset($_POST['comment']))
	{
		if(!isset($params['admin'])) {
			$smarty->trigger_error("comments: tried to post comment, but 'admin' attribute was missing");
			return;
		}
		$result = array('missing' => array());
		if(!isset($_POST['name']) || strlen(trim($_POST['name'])) == 0)
			$result['missing'][] = 'name'; 
		if(ConfigurationReader::getConfigurationValue('comments', 'email.required', false) && (!isset($_POST['email']) || trim(strlen($_POST['email'])) == 0))
			$result['missing'][] = 'email'; 
		if(!isset($_POST['comment']) || strlen(trim($_POST['comment'])) == 0)
			$result['missing'][] = 'comment'; 
		
		$allowHtml = ConfigurationReader::getConfigurationValue("comments", "allow.html", false);
		$comment = (isset($_POST['comment']) ? ($allowHtml ? $_POST['comment'] : strip_tags($_POST['comment'])) : '');
		$name = (isset($_POST['name']) ? strip_tags($_POST['name']) : '');
		$email = (isset($_POST['email']) ? strip_tags($_POST['email']) : '');
		$homepage = (isset($_POST['homepage']) ? strip_tags($_POST['homepage']) : '');
		if(strlen(trim($homepage)) > 0 && strpos($homepage, "http://") === false)
			$homepage = "http://" . $homepage; 
		
		if(count($result['missing']) == 0 && (!isset($_POST['mode']) || $_POST['mode'] == 'create'))
		{
			// erstelle neues kommentar
			import('classes.comments.CommentAdminService');
			
			$cas = new CommentAdminService($itemtype);
			$r = $cas->createComment($id,$language,$name,$comment,$email,$homepage);
			if(intval($r) == intval(COMMENT_IS_SPAM))
				$result['spam'] = true;  
			$result['mode'] = 'create';
		}
		else {
			$preview = array(
				'name' 		=> $name,
				'email'		=> $email,
				'homepage'	=> $homepage,
				'comment'	=> $comment,
				'ip'		=> $_SERVER['REMOTE_ADDR'],
				'timestamp'	=> time(),
				'activated'	=> false,
				'anonymous' => $GLOBALS['_BIGACE']['SESSION']->isAnonymous()
			);
			$result['mode'] = 'preview';
		}
		$smarty->assign($params['admin'], $result);
	}
	
	$smarty->assign($params['preview'], $preview);

	$values = array(
		'ITEMID' 	=> $id,
		'LANGUAGE'	=> $language,
		'ITEMTYPE'	=> $itemtype,
		'IP'		=> $_SERVER['REMOTE_ADDR']
	);
    $sqlString = $GLOBALS['_BIGACE']['SQL_HELPER']->loadStatement('comment_select_language');
    $sqlString = $GLOBALS['_BIGACE']['SQL_HELPER']->prepareStatement($sqlString, $values, true);
    $res = $GLOBALS['_BIGACE']['SQL_HELPER']->execute($sqlString);
	
    $comments = array();
    for($i=0; $i < $res->count(); $i++)
    	$comments[] = $res->next();
    
    $smarty->assign($params['assign'], $comments);
}
?> 