<?php
/**
 * BIGACE - a PHP and MySQL based Web CMS.
 * Copyright (C) Kevin Papst.
 *
 * BIGACE is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * BIGACE is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software Foundation,
 * Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 *
 * For further information visit {@link http://www.bigace.de http://www.bigace.de}.
 *
 * @package bigace.classes
 * @subpackage menu
 */

import('classes.util.IdentifierHelper');

/**
 * Class used for administrating "Comments"
 *
 * @license http://opensource.org/licenses/gpl-license.php GNU Public License
 * @author Kevin Papst 
 * @copyright Copyright (C) Kevin Papst
 * @version $Id: CommentAdminService.php,v 1.1 2008/03/26 00:29:42 kpapst Exp $
 * @package bigace.classes
 * @subpackage news
 */
class CommentAdminService
{
	var $itemtype = _BIGACE_ITEM_MENU;
	
    /**
    * Instantiates a CommentAdminService.
    */
    function CommentAdminService($itemtype = null)
    {
    	if(!is_null($itemtype))
    		$this->itemtype = $itemtype;
    }
    
    function createComment($itemid, $language, $name, $comment, $email = '', $homepage = '')
    {
    	$activate = false;
		if($GLOBALS['_BIGACE']['SESSION']->isAnonymous())
			$activate = ConfigurationReader::getConfigurationValue("comments", "auto.activate.unregistered", false);
		else
			$activate = ConfigurationReader::getConfigurationValue("comments", "auto.activate.registered", false);
		
			
		// TODO send info email if configured 
       	$values = array(
    				'ID' 			=> (IdentifierHelper::getMaximumID('comments') + 1), 
    				'ITEMTYPE' 		=> $this->itemtype, 
    				'ITEMID' 		=> $itemid, 
    				'LANGUAGE' 		=> $language, 
    				'NAME' 			=> $name, 
    				'EMAIL' 		=> $email, 
    				'HOMEPAGE' 		=> $homepage, 
    				'IP' 			=> $_SERVER['REMOTE_ADDR'], 
       				'COMMENT' 		=> $comment, 
    				'TIMESTAMP' 	=> time(),
    				'ACTIVE'		=> $activate,
       				'ANONYMOUS'		=> $GLOBALS['_BIGACE']['SESSION']->isAnonymous());
        $sqlString = $GLOBALS['_BIGACE']['SQL_HELPER']->loadStatement('comment_create');
        $sqlString = $GLOBALS['_BIGACE']['SQL_HELPER']->prepareStatement($sqlString, $values, true);
        $res = $GLOBALS['_BIGACE']['SQL_HELPER']->execute($sqlString);
    }
    
    /**
     * Deletes the Comment entry with the given ID.
     */
    function delete($id) 
    {
        $sqlString = $GLOBALS['_BIGACE']['SQL_HELPER']->loadStatement('comment_delete');
        $sqlString = $GLOBALS['_BIGACE']['SQL_HELPER']->prepareStatement($sqlString, array('ID' => $id), true);
        $res = $GLOBALS['_BIGACE']['SQL_HELPER']->execute($sqlString);
        return !$res->isError();
    }

    /**
     * Updates the Comment with the given ID.
     */
    function update($id, $name, $comment, $email = '', $homepage = '') 
    {
       	$values = array(
    				'ID' 			=> $id, 
    				'NAME' 			=> $name, 
    				'EMAIL' 		=> $email, 
    				'HOMEPAGE' 		=> $homepage, 
       				'COMMENT' 		=> $comment
       	);
        $sqlString = $GLOBALS['_BIGACE']['SQL_HELPER']->loadStatement('comment_update');
        $sqlString = $GLOBALS['_BIGACE']['SQL_HELPER']->prepareStatement($sqlString, $values, true);
        $res = $GLOBALS['_BIGACE']['SQL_HELPER']->execute($sqlString);
    }
    
    /**
     * Delete all Comments entry with the given ID and Language.
     */
    function deleteAll($itemid, $language) 
    {
    	// TODO delete all comments for one language
    }

	function activate($id) {
        $sqlString = $GLOBALS['_BIGACE']['SQL_HELPER']->loadStatement('comment_activate');
        $sqlString = $GLOBALS['_BIGACE']['SQL_HELPER']->prepareStatement($sqlString, array('ID' => $id), true);
        $res = $GLOBALS['_BIGACE']['SQL_HELPER']->execute($sqlString);
        return !$res->isError();
	}
}

?>