INSERT INTO {DB_PREFIX}comments 
(`id`, `cid`, `itemtype`, `itemid`, `language`, `name`, `email`, `homepage`, `ip`, `comment`, `timestamp`, `activated`) 
VALUES 
({ID}, {CID}, {ITEMTYPE}, {ITEMID}, {LANGUAGE}, {NAME}, {EMAIL}, {HOMEPAGE}, {IP}, {COMMENT}, {TIMESTAMP}, {ACTIVE})