<?php
/**
 * BIGACE - a PHP and MySQL based Web CMS.
 * Copyright (C) Kevin Papst.
 * 
 * BIGACE is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * BIGACE is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software Foundation, 
 * Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 * 
 * For further information visit {@link http://www.bigace.de http://www.bigace.de}.
 *
 * @version $Id: browser.php,v 1.2 2008/03/30 22:06:28 kpapst Exp $
 * @author Kevin Papst 
 * @package bigace.addon.filemanager
 */

/*
 * FCKeditor - The text editor for internet
 * Copyright (C) 2003-2005 Frederico Caldeira Knabben
 * 
 * Licensed under the terms of the GNU Lesser General Public License:
 *      http://www.opensource.org/licenses/lgpl-license.php
 * 
 * Original File Authors:
 *      Frederico Caldeira Knabben (fredck@fckeditor.net)
 *
 * ----------------------------------------------------------------------
 *
 * Some Code is taken from the original Browser supplied with the FCKeditor. 
 *
 * Customized by Kevin Papst for BIGACE.
 */

require_once(dirname(__FILE__).'/environment.php');
if(!defined('_BIGACE_FILEMANAGER'))	die('An error occured.');

if ($itemtype != null) {
	$parameter .= '&itemtype='.$itemtype;
}

import('classes.util.ApplicationLinks');

define('JS_FUNCTION_URL', (isset($_GET['jsFunc']) ? $_GET['jsFunc'] : 'SetUrl'));
define('JS_FUNCTION_INFOS', (isset($_GET['imgInfos']) ? $_GET['imgInfos'] : 'SetImageInfos'));

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
    <head>
        <title>File Manager</title>
        <link href="browser.css" type="text/css" rel="stylesheet">
		<script type="text/javascript" src="<?php echo $GLOBALS['_BIGACE']['DIR']['public']; ?>system/javascript/ajax_xml.js"></script>
		<script type="text/javascript" src="<?php echo $GLOBALS['_BIGACE']['DIR']['public']; ?>system/javascript/bigace_ajax.js"></script>
		<script type="text/javascript">
		var oIcons = new Object() ;
		oIcons.AvailableIcons = new Object() ;

		oIcons.AvailableIconsArray = [ 
			'ai','avi','bmp','cs','dll','doc','exe','fla','gif','htm','html','jpg','js',
			'mdb','mp3','pdf','ppt','rdp','swf','swt','txt','vsd','xls','xml','zip' ] ;
		

		for ( var i = 0 ; i < oIcons.AvailableIconsArray.length ; i++ )
			oIcons.AvailableIcons[ oIcons.AvailableIconsArray[i] ] = true ;

		function GetUrlParam( paramName )
		{
			var oRegex = new RegExp( '[\?&]' + paramName + '=([^&]+)', 'i' ) ;
			var oMatch = oRegex.exec( window.top.location.search ) ;
		
			if ( oMatch && oMatch.length > 1 )
				return oMatch[1] ;
			else
				return '' ;
		}

		function getItem(itemtype, itemid, languageid)
		{
		  var itemRequestUrl = "<?php echo ApplicationLinks::getAjaxItemInfoURL('"+itemtype+"', '"+itemid+"', '"+languageid+"'); ?>";
		  return loadItem(itemRequestUrl, false);
		}

		var sActiveItem = {
		    itemID          : null,
		    languageID      : null,
		    name            : '',
		    filename        : '',
		    url             : '',
		    setName         : function (name) { this.name = name; },
		    getName         : function()    { return this.name; },
		    setFilename     : function (name) { this.filename = name; },
		    getFilename     : function()    { return this.filename; },
		    setItemID       : function (id) { this.itemID = id; },
		    getItemID       : function()    { return this.itemID; },
		    setLanguageID   : function (id) { this.languageID = id; },
		    getLanguageID   : function()    { return this.languageID; },
		    setURL          : function (url) { this.url = url; },
		    getURL          : function()    { return this.url; }
		}

		function acceptItem() 
		{
		    if(sActiveItem.getURL() == null || sActiveItem.getURL() == '') {
		        alert('<?php getTranslation('no_image_selected'); ?>.');
		        return false;
		    }
		        
		    if (typeof(window.top.opener.<?php echo JS_FUNCTION_URL; ?>) == "undefined")
		    {
		        alert('<?php getTranslation('undefined_js_function'); ?>: "<?php echo JS_FUNCTION_URL; ?>"');
		    }
		    else
		    {
		        window.top.opener.<?php echo JS_FUNCTION_URL; ?>(encodeURI(sActiveItem.getURL()));
			    if (typeof(window.top.opener.<?php echo JS_FUNCTION_INFOS; ?>) != "undefined")
			        window.top.opener.<?php echo JS_FUNCTION_INFOS; ?>(sActiveItem.getItemID(), sActiveItem.getFilename());
		    	window.top.close();
		    	window.top.opener.focus();
		    }
		}


		function setSelectedItem(itemtype, itemid, languageid, filename, itemUrl)
		{
			simpleItem = getItem(itemtype, itemid, languageid)

			// todo - what if permission failed?
			// todo - what if session timed out?

		    if (simpleItem != null) {
		        sActiveItem.setItemID(simpleItem.id);
		        sActiveItem.setLanguageID(simpleItem.language);
		        sActiveItem.setName(simpleItem.name);
		        sActiveItem.setFilename(filename);
				sActiveItem.setURL(itemUrl);
				extension = oIcons.GetIcon("."+filename);
				window.frames['itemDisplay'].setCurrentItem(extension,simpleItem,itemUrl);
		    }
		}

		oIcons.GetIcon = function( fileName )
		{
			var sExtension = fileName.substr( fileName.lastIndexOf('.') + 1 ).toLowerCase() ;
		//  alert(sExtension);

			if ( this.AvailableIcons[ sExtension ] == true )
				return sExtension ;
			else
				return 'default.icon' ;
		}
        </script>
    </head>
    
    <frameset cols="150,*" class="Frame" framespacing="3" style="border-color:#f1f1e3" bordercolor="#f1f1e3" frameborder="yes">
        <frameset rows="50,*" framespacing="0">
            <frame name="upperLeft" src="html/upperleft.html?<?php echo $parameter; ?>" scrolling="no" frameborder="no">
            <frame name="folders" src="folder.php?<?php echo $parameter; ?>" scrolling="auto" frameborder="yes">
        </frameset>
        <frameset id="extensions" rows="50,*" framespacing="0" noresize>
            <frame name="itemDisplay" src="iteminfos.php?<?php echo $parameter; ?>" scrolling="no" frameborder="no">
            <frame name="main" src="html/startscreen.html?<?php echo $parameter; ?>" scrolling="auto" frameborder="1" border="1" style="border-top:3px;">
        </frameset>
    </frameset>
</html>
