<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
	<head>
		<link href="browser.css" type="text/css" rel="stylesheet">
		<script type="text/javascript">
		function OnResize()
		{
			divName.style.width = "1px" ;
			divName.style.width = tdName.offsetWidth + "px" ;
		}

		function buttonAccept() {
			parent.window.acceptItem();
		}

		function setCurrentItem( extension, item, url )
		{
			extImg = "icons/32/" + extension + ".gif";
			document.getElementById('tdName').innerHTML = item.getName();
			document.getElementById('prevLink').href = url;
			document.getElementById('itemtypeImg').src = extImg;
			document.getElementById('infoDiv').style.visibility = "visible";
		}
		</script>
	</head>
	<body style="margin:4px">
		<table height="100%" cellSpacing="0" cellPadding="0" width="100%" border="0">
			<tr>
				<td class="button" width="100%">
						<table id="infoDiv" style="visibility:hidden" height="42" cellSpacing="0" cellPadding="0" width="100%" border="0">
							<tr>
								<td width="38px" align="center" id="itemtype">
									<a id="prevLink" href="#" target="main"><img border="0" height="32" width="32" id="itemtypeImg" alt="" src="icons/32/default.icon.gif"></a>
								</td>
								<td id="tdName" align="left" class="ActualFolder"></td>
								<td id="tools" width="70" align="right">
									<button style="margin-right:2px;" class="info" type="button" onclick="buttonAccept();return false;"><img border="0" height="16" width="16" src="images/accept.png"><br>&Uuml;bernehmen</button> 
								</td>
							</tr>
						</table>
				</td>
			</tr>
		</table>
	</body>
</html>
