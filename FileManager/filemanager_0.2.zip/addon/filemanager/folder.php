<?php
/**
 * BIGACE - a PHP and MySQL based Web CMS.
 * Copyright (C) Kevin Papst.
 * 
 * BIGACE is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * BIGACE is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software Foundation, 
 * Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 * 
 * For further information visit {@link http://www.bigace.de http://www.bigace.de}.
 *
 * @version $Id: folder.php,v 1.2 2008/03/30 22:06:28 kpapst Exp $
 * @author Kevin Papst 
 * @package bigace.addon.filemanager
 */

require_once(dirname(__FILE__).'/environment.php');
if(!defined('_BIGACE_FILEMANAGER'))	die('An error occured.');

?><!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
	<head>
		<link href="browser.css" type="text/css" rel="stylesheet">
		<script type="text/javascript" src="js/common.js"></script>
	</head>
	<body class="FileArea" bottomMargin="10" leftMargin="10" topMargin="10" rightMargin="10">
	<?php
		if($itemtype == null || $itemtype == _BIGACE_ITEM_MENU)
		{ 
		?>
		<h1><?php echo getTranslation('item_1'); ?></h1>
			<ul>
				<li><a target="main" href="by_itemtype.php?itemtype=1&<?php echo $parameter; ?>">Ausw&auml;hlen</a></li>
				<li><a target="main" href="by_categories.php?itemtype=1&<?php echo $parameter; ?>">Nach Kategorien</a></li>
				<!--  li><?php echo getTranslation('search_menu'); ?></li -->
			</ul>
	<?php
		}
	
		if($itemtype == null || $itemtype == _BIGACE_ITEM_IMAGE)
		{ 
		?>
		<h1><?php echo getTranslation('item_4'); ?></h1>
			<ul>
				<li><a target="main" href="by_itemtype.php?itemtype=4&<?php echo $parameter; ?>">Ausw&auml;hlen</a></li>
				<li><a target="main" href="by_categories.php?itemtype=4&<?php echo $parameter; ?>">Nach Kategorien</a></li>
				<!--  li><?php echo getTranslation('search_image'); ?></li -->
				<!--  li><?php echo getTranslation('upload_image'); ?></li -->
			</ul>
	<?php
		}
	
		if($itemtype == null || $itemtype == _BIGACE_ITEM_FILE)
		{ 
		?>
		<h1><?php echo getTranslation('item_5'); ?></h1>
			<ul>
				<li><a target="main" href="by_itemtype.php?itemtype=5&<?php echo $parameter; ?>">Ausw&auml;hlen</a></li>
				<li><a target="main" href="by_categories.php?itemtype=5&<?php echo $parameter; ?>">Nach Kategorien</a></li>
				<!--  li><?php echo getTranslation('search_file'); ?></li -->
				<!--  li><?php echo getTranslation('upload_file'); ?></li -->
			</ul>
	<?php
		}
		?>
	</body>
</html>
