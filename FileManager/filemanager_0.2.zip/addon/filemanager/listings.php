<?php
/**
 * BIGACE - a PHP and MySQL based Web CMS.<br>Copyright (C) Kevin Papst.
 * 
 * BIGACE is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * BIGACE is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software Foundation, 
 * Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 * 
 * For further information visit {@link http://www.bigace.de http://www.bigace.de}.
 *
 * @version $Id: listings.php,v 1.2 2008/03/30 22:06:28 kpapst Exp $
 * @author Kevin Papst 
 * @package bigace.addon.filemanager
 */

if(!defined('_BIGACE_FILEMANAGER'))	die('An error occured.');

function render_thumbnails($items)
{
}

function render_listing($itemtype, $items)
{
    if(!is_array($items) || count($items) == 0)
    {
        echo '<b>'.getTranslation('no_items_available_'.$itemtype, getTranslation('no_items_available')).'</b>';
        return;
    }
    $ts = getTemplateService();
	if($itemtype == _BIGACE_ITEM_MENU)
	    $tpl = $ts->loadTemplatefile("html/MenuListing.tpl.html", false, true);
	else
	    $tpl = $ts->loadTemplatefile("html/ItemListing.tpl.html", false, true);
    $tpl->setVariable("LISTING_WIDTH", '100%');

    $cssClass = "row1";

    foreach($items AS $item)
    {
        $tpl->setCurrentBlock("row");
		if($itemtype == _BIGACE_ITEM_MENU) {
			$extension = 'html';
			if(!$item->hasChilds())
		        $tpl->setVariable("FOLDER", '');
			else
		        $tpl->setVariable("FOLDER", '<a href="'.getFilemanagerUrl('by_itemtype.php', array('itemtype'=>'1', 'selectedID' => $item->getID())).'"><img border="0" src="images/folder.png"></a>');
		}else {
			$extension = getFileExtension(strtolower($item->getOriginalName()));
		}
        $tpl->setVariable("CSS", $cssClass);
        $tpl->setVariable("ITEM_ID", $item->getID());
        $tpl->setVariable("ITEM_LANGUAGE", $item->getLanguageID());
        $tpl->setVariable("ITEM_TYPE", $item->getItemtypeID());
        $tpl->setVariable("ITEM_NAME", prepareJSName($item->getName()));
        $tpl->setVariable("ITEM_URL", LinkHelper::getUrlFromCMSLink(LinkHelper::getCMSLinkFromItem($item)));
        $tpl->setVariable("ITEM_FILENAME", $item->getOriginalName());
        $tpl->setVariable("ITEM_MIMETYPE", $extension);
        $tpl->parseCurrentBlock("row");

        $cssClass = ($cssClass == "row1") ? "row2" : "row1";
    }

    $tpl->show();
}

function render_search($items)
{
}


function prepareJSName($str) {
    $str = htmlspecialchars($str);
    $str = str_replace('"', '&quot;', $str);
    //$str = addSlashes($str);
    //$str = str_replace("'", '\%27', $str);
    $str = str_replace("'", '&#039;', $str);
    return $str;
}

function showHtmlHeader()
{
    $lang = new Language($GLOBALS['_BIGACE']['SESSION']->getLanguageID());

    $ts = getTemplateService();
    $tpl = $ts->loadTemplatefile("html/BrowserHtmlHeader.tpl.html", false, true);
    $tpl->setVariable("LANGUAGE_CHARSET", $lang->getCharset());
    $tpl->show();
}

function showHtmlFooter()
{
	?>
		</body>
	</html>
	<?php
}

?>
