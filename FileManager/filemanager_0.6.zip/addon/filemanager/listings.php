<?php
/**
 * BIGACE - a PHP and MySQL based Web CMS.
 * Copyright (C) Kevin Papst.
 * 
 * BIGACE is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * BIGACE is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software Foundation, 
 * Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 * 
 * For further information visit {@link http://www.bigace.de http://www.bigace.de}.
 *
 * @version $Id: listings.php,v 1.8 2009/03/23 01:24:10 kpapst Exp $
 * @author Kevin Papst 
 * @package bigace.addon.filemanager
 */

if(!defined('_BIGACE_FILEMANAGER'))	die('An error occured.');

function render_thumbnails($items)
{
}

function render_listing($itemtype, $items, $folder = true)
{
    if(!is_array($items) || count($items) == 0)
    {
        echo '<b>'.getTranslation('no_items_available_'.$itemtype, getTranslation('no_items_available')).'</b>';
        return;
    }
    
    $tpl = getTemplateService();

    $cssClass = "row1";
    
    $entries = array();

    foreach($items AS $item)
    {
    	$folder = "";
		if($itemtype == _BIGACE_ITEM_MENU) {
			$extension = 'html';
			if($item->hasChildren())
			$folder = '<a href="'.getFilemanagerUrl('by_itemtype.php', array('itemtype'=>'1', 'selectedID' => $item->getID())).'"><img border="0" src="images/folder.png"></a>';
		}else {
			$extension = getFileExtension(strtolower($item->getOriginalName()));
		}
		
		$entries[] = array(
			"FOLDER" => $folder, 
			"CSS" => $cssClass,
            "ITEM" => $item,
        	"ITEM_ID" => $item->getID(),
            "ITEM_LANGUAGE" => $item->getLanguageID(),
            "ITEM_TYPE" => $item->getItemtypeID(),
            "ITEM_NAME" => prepareJSName($item->getName()),
            "ITEM_URL" => LinkHelper::getUrlFromCMSLink(LinkHelper::getCMSLinkFromItem($item)),
            "ITEM_FILENAME" => $item->getOriginalName(),
            "ITEM_MIMETYPE" => $extension
		);

        $cssClass = ($cssClass == "row1") ? "row2" : "row1";
    }
    
    $tpl->assign("ITEMS", $entries);

	if($itemtype == _BIGACE_ITEM_MENU)
	    $tpl->display("MenuListing.tpl");
	else if($itemtype == _BIGACE_ITEM_IMAGE)
	    $tpl->display("ImageListing.tpl");
	else
	    $tpl->display("ItemListing.tpl");
}

function render_search($items)
{
}


function prepareJSName($str) {
    $str = htmlspecialchars($str);
    $str = str_replace('"', '&quot;', $str);
    //$str = addSlashes($str);
    //$str = str_replace("'", '\%27', $str);
    $str = str_replace("'", '&#039;', $str);
    return $str;
}

function showHtmlHeader()
{
    $lang = new Language($GLOBALS['_BIGACE']['SESSION']->getLanguageID());

    $ts = getTemplateService();
    $ts->assign("LANGUAGE", $lang);
    $ts->display('BrowserHtmlHeader.tpl');
}


function showHtmlFooter()
{
	echo '
	
		</body>
	</html>
	';
}

?>
