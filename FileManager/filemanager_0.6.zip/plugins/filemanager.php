<?php
/*
Plugin Name: Filemanager
Plugin URI: http://wiki.bigace.de/bigace:extensions:editor:filemanager
Description: Replaces the default dialogs to select CMS URLs and images.
Author: Kevin Papst
Version: 0.1
Author URI: http://www.kevinpapst.de/
*/

if(!defined('_BIGACE_ID'))
    die('Ooops');

Hooks::add_filter('dialog_setting_images', 'filemanager_image_settings', 10, 2);
Hooks::add_filter('dialog_setting_links', 'filemanager_link_settings', 10, 2);

function filemanager_image_settings($vars, $id = null)
{
	$param = "";
	if(!is_null($id)) {
		$param = "&parent=".$id.'&'.$param;
	}

	$vars = array(
		'url' => $GLOBALS['_BIGACE']['DIR']['addon_web'] . 'filemanager/browser.php?itemtype=4&'.bigace_session_name() . "=" . bigace_session_id() . $param,
		'width' => '800',
		'height' => '500'
	);	
	
	return $vars;
}


function filemanager_link_settings($vars, $id = null)
{
	$param = "";
	if(!is_null($id)) {
		$param = "&parent=".$id.'&'.$param;
	}
	
	$vars = array(
		'url' => $GLOBALS['_BIGACE']['DIR']['addon_web'] . 'filemanager/browser.php?'.bigace_session_name() . "=" . bigace_session_id() . $param,
		'width' => '800',
		'height' => '500'
	);
	
	return $vars;
}

