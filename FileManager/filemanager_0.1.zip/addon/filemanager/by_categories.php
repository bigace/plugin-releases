<?php
/**
 * BIGACE - a PHP and MySQL based Web CMS.
 * Copyright (C) Kevin Papst.
 * 
 * BIGACE is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * BIGACE is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software Foundation, 
 * Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 * 
 * For further information visit {@link http://www.bigace.de http://www.bigace.de}.
 *
 * @version $Id: imagebrowser.php,v 1.6 2008/02/12 17:57:17 kpapst Exp $
 * @author Kevin Papst 
 * @package bigace.addon.filemanager
 */
require_once(dirname(__FILE__).'/environment.php');
require_once(dirname(__FILE__).'/listings.php');
if(!defined('_BIGACE_FILEMANAGER'))	die('An error occured.');
if($itemtype == null) die('No Itemtype selected.');

import('classes.util.CMSLink');
import('classes.util.LinkHelper');

import('classes.item.ItemRequest');
import('classes.item.SimpleItemTreeWalker');
import('classes.category.Category');
import('classes.category.CategoryService');

import('classes.menu.Menu');
import('classes.menu.MenuService');
import('classes.image.Image');
import('classes.image.ImageService');
import('classes.file.File');
import('classes.file.FileService');

$selectedCategory = (isset($_GET['showCatID']) ? $_GET['showCatID'] : null);

$selfLink = "by_categories.php?itemtype=".$itemtype.'&'.$parameter;

showHtmlHeader();

if($selectedCategory == null)
{
	$categoryID = (isset($_GET['catID']) ? $_GET['catID'] : _BIGACE_TOP_LEVEL);

    $ts = getTemplateService();
    $tpl = $ts->loadTemplatefile("html/CategoryMenu.tpl.htm", true, true);
    $tpl->setVariable("LISTING_WIDTH", '100%');

    $catService = new CategoryService();
    $category = $catService->getCategory($categoryID);

	$cssClass = "row1";

    // Current Category
    $name = '<b>'.$category->getName().'</b>';
    $parent = $category->getParent();
    if ($category->getID() != _BIGACE_TOP_LEVEL)
    {
      $name = '<a href="'.$selfLink.'&catID=' . $parent->getID().'" title="'.$parent->getName().'"><img src="'.$GLOBALS['_BIGACE']['DIR']['public'].'system/images/arrow_up.gif" border="0" alt="'.$parent->getName().'">&nbsp;' . $name.'</a>';
    }

    $catEnum = $catService->getItemsForCategory($itemtype, $category->getID());

    $tlink = '';
    if($catEnum->count() > 0)
        $tlink = '<a href="'.$selfLink.'&catID=' . $category->getID().'">'.getTranslation('show_linked').'</a>';

    $tpl->setCurrentBlock("row");
    $tpl->setVariable("CSS", $cssClass);
    $tpl->setVariable("CATEGORY_NAME", $name);
    $tpl->setVariable("ACTION_LINKED", $tlink);
    $tpl->setVariable("AMOUNT", $catEnum->count());
    $tpl->parseCurrentBlock("row");

    $enum = $category->getChilds();
    $val = $enum->count();

    for ($i = 0; $i < $val; $i++)
    {
		$cssClass = ($cssClass == "row1") ? "row2" : "row1";

        $temp = $enum->next();
        $name = $temp->getName();
        if ($temp->hasChilds()) {
            $name = '<a href="'.$selfLink.'&catID='.$temp->getID().'" title="'.$temp->getName().'"><img src="'.$GLOBALS['_BIGACE']['DIR']['public'].'system/images/arrow_down.gif" border="0" alt="'.$name.'">&nbsp;' . $name . '</a>';
        }

        $catEnum = $catService->getItemsForCategory($itemtype, $temp->getID());

        $tlink = '';
        if($catEnum->count() > 0)
            $tlink = '<a href="'.$selfLink.'&showCatID='. $temp->getID().'">'.getTranslation('show_linked').'</a>';

        $tpl->setCurrentBlock("row");
        $tpl->setVariable("CSS", $cssClass);
        $tpl->setVariable("CATEGORY_NAME", $name);
        $tpl->setVariable("ACTION_LINKED", $tlink);
        $tpl->setVariable("AMOUNT", $catEnum->count());
        $tpl->parseCurrentBlock("row");
    }

    $tpl->show();
}
else
{
    $items = array();
    $itemGetter = new Itemtype($itemtype);
    $catService = new CategoryService();
    $catEnum = $catService->getItemsForCategory($itemtype, $selectedCategory);
    for($i=0; $i < $catEnum->count(); $i++)
    {
        $temp = $catEnum->next();
        $items[] = $itemGetter->getClass($temp['itemid']);
    }
	
	render_listing($items);
}

showHtmlFooter();

?>
