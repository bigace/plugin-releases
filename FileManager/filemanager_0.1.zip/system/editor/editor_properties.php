<?php
/**
 * BIGACE - a PHP and MySQL based Web CMS.
 * Copyright (C) Kevin Papst.
 *
 * BIGACE is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * BIGACE is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software Foundation,
 * Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 *
 * For further information visit {@link http://www.bigace.de http://www.bigace.de}.
 *
 * @version $Id: javascript.php,v 1.30 2008/02/11 22:07:11 kpapst Exp $
 * @author Kevin Papst 
 * @package bigace.editor
 */

/**
 * Customized Cross-Editor Dialog settings, for easier handling of items.
 */

$GLOBALS['BIGACE']['editor']['image']['url'] = $GLOBALS['_BIGACE']['DIR']['addon_web'] . 'filemanager/browser.php?itemtype=4&' . bigace_session_name() . "=" . bigace_session_id();
$GLOBALS['BIGACE']['editor']['image']['width'] = '800';
$GLOBALS['BIGACE']['editor']['image']['height'] = '500';

$GLOBALS['BIGACE']['editor']['link']['url'] = $GLOBALS['_BIGACE']['DIR']['addon_web'] . 'filemanager/browser.php?' . bigace_session_name() . "=" . bigace_session_id();
$GLOBALS['BIGACE']['editor']['link']['width'] = '800';
$GLOBALS['BIGACE']['editor']['link']['height'] = '500';
	
?>