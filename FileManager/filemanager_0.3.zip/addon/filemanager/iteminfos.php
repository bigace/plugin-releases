<?php
/**
 * BIGACE - a PHP and MySQL based Web CMS.
 * Copyright (C) Kevin Papst.
 * 
 * BIGACE is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * BIGACE is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software Foundation, 
 * Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 * 
 * For further information visit {@link http://www.bigace.de http://www.bigace.de}.
 *
 * @version $Id: iteminfos.php,v 1.3 2008/06/08 15:24:30 kpapst Exp $
 * @author Kevin Papst 
 * @package bigace.addon.filemanager
 */
require_once(dirname(__FILE__).'/environment.php');

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
	<head>
		<link href="browser.css" type="text/css" rel="stylesheet">
		<script type="text/javascript">
		function OnResize()
		{
			divName.style.width = "1px" ;
			divName.style.width = tdName.offsetWidth + "px" ;
		}

		function buttonAccept() {
			parent.window.acceptItem();
		}

		function setCurrentItem( extension, item, url )
		{
			extImg = "icons/32/" + extension + ".gif";
			document.getElementById('tdName').innerHTML = item.getName();
			document.getElementById('prevLink').href = url;
			document.getElementById('itemtypeImg').src = extImg;
			document.getElementById('infoDiv').style.visibility = "visible";
		}
		</script>
	</head>
	<body style="margin:4px">
		<table height="100%" cellSpacing="0" cellPadding="0" width="100%" border="0">
			<tr>
				<td class="button" width="100%">
						<table id="infoDiv" style="visibility:hidden" height="42" cellSpacing="0" cellPadding="0" width="100%" border="0">
							<tr>
								<td width="38px" align="center" id="itemtype">
									<a id="prevLink" href="#" target="main"><img border="0" height="32" width="32" id="itemtypeImg" alt="" src="icons/32/default.icon.gif"></a>
								</td>
								<td id="tdName" align="left" class="ActualFolder"><i><?php echo getTranslation('no_file_selected'); ?></i></td>
								<td id="tools" width="70" align="right">
									<button style="margin-right:2px;" class="info" type="button" onclick="buttonAccept();return false;"><img border="0" height="16" width="16" src="images/accept.png"><br><?php echo getTranslation('item_button_use'); ?></button> 
								</td>
							</tr>
						</table>
				</td>
			</tr>
		</table>
	</body>
</html>