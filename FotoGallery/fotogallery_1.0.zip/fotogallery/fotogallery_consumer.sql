INSERT INTO {DB_PREFIX}frights (cid,name,defaultvalue,description) VALUES 
({CID}, 'fotogallery_admin', 'N', 'Allow User to administrate the Foto Gallery settings.');

