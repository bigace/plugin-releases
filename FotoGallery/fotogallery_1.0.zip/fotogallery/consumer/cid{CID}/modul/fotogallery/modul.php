<?php
/**
 * FOTOGALLERY
 *
 * The Fotoalbum displays all Images of a choosen Category in a List.
 * The List displays a resized version of the original Image and on click,
 * opens a Javascript wdget with the full size version.
 *
 * Copyright (C) Kevin Papst
 *
 * For further information go to http://www.kevinpapst.de/ 
 * or contact bigace@kevinpapst.de.
 *
 * @version $Id: modul.php,v 1.6 2006/04/17 09:47:29 kpapst Exp $
 * @author Kevin Papst <bigace@kevinpapst.de>
 * @package bigace.modul
 */

loadClass('image', 'ImageService');
loadClass('image', 'Image');
loadClass('category', 'Category');
loadClass('category', 'CategoryService');
loadClass('item', 'ItemProjectService');
loadClass('fright', 'FrightService');

define('GALLERY_ADMIN_FRIGHT',      'fotogallery_admin'); // fright for the administration
define('MODUL_ADMIN_FRIGHT',        'module_all_rights'); // fright for every modul administration

define('LIGHTBOX_WEB', $GLOBALS['_BIGACE']['DIR']['public'].'modul/fotogallery/');

$FRIGHTSERVICE = new FrightService();
// this key defines if the current user is allowed to administrate the settings
define('_ALLOW_GALLERY_ADMIN', $FRIGHTSERVICE->hasFright($USER->getID(), GALLERY_ADMIN_FRIGHT) || $FRIGHTSERVICE->hasFright($USER->getID(), MODUL_ADMIN_FRIGHT));
unset($FRIGHTSERVICE);

define('_GALLERY_MODE_LIST', 1);
define('_GALLERY_MODE_ADMIN', 3);
define('_GALLERY_MODE_SAVE', 4);

define('_GALLERY_THUMBNAIL_HEIGHT', '100');
define('_GALLERY_SHOW_DESCRIPTION', FALSE);

$CAT_SERVICE    = new CategoryService();
$IMG_SERVICE    = new ImageService();
$projectService = new ItemProjectService(_BIGACE_ITEM_MENU);

$_FOTOALBUM     = array();
$mode           = extractVar('mode', _GALLERY_MODE_LIST);
$CUR_CAT        = -1;
$isConfigured   = $projectService->existsProjectNum($MENU->getID(), $MENU->getLanguageID(), '1');

if ($isConfigured) 
{
    $CUR_CAT = $projectService->getProjectNum($MENU->getID(), $MENU->getLanguageID(), '1');
    ?>
        
        <link rel="stylesheet" href="<?php echo LIGHTBOX_WEB; ?>lightbox.css" type="text/css" media="screen">
        <style type="text/css" media="screen">
        #overlay{ background-image: url(<?php echo LIGHTBOX_WEB; ?>overlay.png); }
        
        * html #overlay{
            background-color: #333;
            back\ground-color: transparent;
            background-image: url(blank.gif);
            filter: progid:DXImageTransform.Microsoft.AlphaImageLoader(src="<?php echo LIGHTBOX_WEB; ?>overlay.png", sizingMethod="scale");
            }
        </style>
        
        <script type="text/javascript">
        var loadingImage = '<?php echo LIGHTBOX_WEB; ?>loading.gif';
        var closeButton = '<?php echo LIGHTBOX_WEB; ?>close.gif';
        </script>
        <script type="text/javascript" src="<?php echo LIGHTBOX_WEB; ?>lightbox.js"></script>
        
    <?php
}
    
if (_ALLOW_GALLERY_ADMIN)
{
    // Show Administration Link
    if($mode != _GALLERY_MODE_ADMIN) 
    {
        echo '<center><a href="'.createMenuLink($GLOBALS['MENU']->getID(),array('mode' => _GALLERY_MODE_ADMIN)).'">'.getTranslation('admin','Administration').'</a></center>';
        echo '<br/>';
    } 
    
    if($mode == _GALLERY_MODE_SAVE)
    {
        /* #########################################################################
         * #######################  4: Save category settings  #####################
         * ######################################################################### 
         */
        include_once ($_BIGACE['DIR']['libs'].'htmlhelper.inc.php');
        $data = extractVar('data', array('category' => $CUR_CAT));
        $title = 'Settings did not change!';
        $temp = $CAT_SERVICE->getCategory($CUR_CAT);
        $entrys = array('Old:' => $temp->getName() .' (' . $temp->getID() . ')');
        $temp = $CAT_SERVICE->getCategory($data['category']);
        $entrys['New:'] = $temp->getName() .' (' . $temp->getID() . ')';

        if (isset($data['category'])) 
        {
            if ($data['category'] != $CUR_CAT) 
            {
                loadClass('item', 'ItemAdminService');
                $ADMIN_SERVICE = new ItemAdminService(_BIGACE_ITEM_MENU);
                if ( $ADMIN_SERVICE->setProjectNum($GLOBALS['MENU']->getID(),$GLOBALS['MENU']->getLanguageID(),'1',$data['category']) ) 
                {
                    $title =  'Saved settings successful!';
                    $isConfigured = true;
                }
                unset($ADMIN_SERVICE);
                $CUR_CAT = $data['category'];
            }
        } else {
            $title =  'Saving failed!';
        }

        $config = array(
                        'width'         =>  '500',
                        'align'         =>  array (
                                                'table'     => 'center',
                                                'left'      => 'left',
                                                'bottom'    => 'left'
                                            ),
                        'title'         =>  $title,
                        'form_hide'     =>  true,
                        'entries'       =>  $entrys
        );
        echo createTable($config) . '<br/>';
        unset($title);
        unset($config);
        unset($entrys);
        unset($temp);
        unset($data);
        $mode = _GALLERY_MODE_ADMIN;
    }
    
    if ($mode == _GALLERY_MODE_ADMIN)
    {
        /* #########################################################################
         * ###########################  Show Administration  #######################
         * ######################################################################### 
         */
        include_once ($_BIGACE['DIR']['libs'].'htmlhelper.inc.php');
        $opts = array();
        loadClass('category', 'CategoryList');
        $CAT_LIST = new CategoryList();
        for ($a = 0; $a < $CAT_LIST->count(); $a++)  {
            $temp = $CAT_LIST->next();
            $opts[$temp->getName()] = $temp->getID();
            unset ($temp);
        }
        
        $html = array(
                        'width'         =>  '500',
                        'align'         =>  array (
                                                'table'     =>  'center',
                                                'left'      =>  'left'
                                            ),
                        'title'         =>  getTranslation('admin','Administration'),
                        'form_action'   =>  createMenuLink($GLOBALS['MENU']->getID()),
                        'form_method'   =>  'post',
                        'form_hidden'   =>  array(
                                                'mode' => '4'
                                        ),
                        'entries'       =>  array(
                                                'Category'  => createSelectBox('category', $opts, $CUR_CAT, '')
                                        ),
                        'form_submit'   =>  true,
                        'form_reset'    =>  "location.href='".createMenuLink($GLOBALS['MENU']->getID())."'",
                        'reset_label'   =>  getTranslation('back','Back'),
                        'submit_label'  =>  getTranslation('save','Save')
        );
        echo createTable($html) . '<br/>';
        unset($opts);
        unset($CAT_LIST);
        unset($html);
    } 

}
else
{
    // no function rights to access
    $mode = _GALLERY_MODE_LIST;
}



/* #########################################################################
 * ##################  Show List of all categorized Images  ################
 * ######################################################################### 
 */
if ($mode == _GALLERY_MODE_LIST)
{
    if(!$isConfigured)
    {
        echo '<br><b>'.getTranslation('gallery_unconfigured').'</b><br>';
    }
    else
    {
        $search = $CAT_SERVICE->getItemsForCategory($IMG_SERVICE->getItemtype(), $CUR_CAT);
        
        ?>
        
        <p><?php echo $MENU->getContent(); ?></p>
        <div class="section clearfix">
        <?php
        
        while ($search->hasNext())
        {
            $temp = $search->next();
            $temp_image = $IMG_SERVICE->getClass($temp['itemid']);
            $imgLink = createCommandLink('image', $temp_image->getID(), array(), $temp_image->getOriginalName());
            ?> 
            <div class="thumbnail">
                <a href="<?php echo $imgLink; ?>" rel="lightbox" title="<?php echo $temp_image->getName(); ?>"><img src="<?php echo createCommandLink('image', $temp_image->getID(), array('resizeHeight' => _GALLERY_THUMBNAIL_HEIGHT), $temp_image->getOriginalName()); ?>" alt="<?php echo $temp_image->getName(); ?>" height="<?php echo _GALLERY_THUMBNAIL_HEIGHT; ?>"></a>
                <div class="caption">
                    <a href="<?php echo $imgLink; ?>" rel="lightbox" class="thumnailLink" title="<?php echo $temp_image->getName(); ?>"><?php echo $temp_image->getName(); ?></a>
                    <?php 
                    if(_GALLERY_SHOW_DESCRIPTION)
                    {
                        echo '<br>';
                        echo $temp_image->getDescription();
                    }
                    ?>
                </div>
            </div>
            <?php
        }
        
        echo '</div>';
    }

}

?>