<?php
/**
* Modul Translation file 
*
* Language: deutsch (default)
* Locale:   de
*
* Copyright (C) Kevin Papst. 
*
* For further information go to http://www.kevinpapst.de/ 
* or contact bigace@kevinpapst.de.
*
* @version $Id: modul.lang.php,v 1.2 2006/04/09 22:06:39 kpapst Exp $
* @author Kevin Papst <bigace@kevinpapst.de>
* @package bigace.translation
*/

$LANG['modul_name_fotogallery']    		= 'Foto Gallery';
$LANG['modul_title_fotogallery']    	= 'Easy Foto Gallery';
$LANG['modul_description_fotogallery']  = 'Script to display a simple Foto Gallery. Creates the List of Items by selecting all Images linked to a special category.';
$LANG['gallery_unconfigured']           = 'This Modul is not properly configured. Please call your Administrator.';

?>