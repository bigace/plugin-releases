<?php
/**
* Modul Translation file 
*
* Language: deutsch (default)
* Locale:   de
*
* Copyright (C) Kevin Papst. 
*
* For further information go to http://www.kevinpapst.de/ 
* or contact bigace@kevinpapst.de.
*
* @version $Id: modul.lang.php,v 1.2 2006/04/09 22:06:39 kpapst Exp $
* @author Kevin Papst <bigace@kevinpapst.de>
* @package bigace.translation
*/

$LANG['modul_name_fotogallery']    		= 'Foto Gallery';
$LANG['modul_title_fotogallery']    	= 'Easy Foto Gallery';
$LANG['modul_description_fotogallery']  = 'Hiermit k�nnen Sie eine Bildergalerie anzeigen. Generiert die Bilder�bersicht anhand einer konfigurierbaren Kategorie.';
$LANG['gallery_unconfigured']           = 'Dieses Modul ist nicht vollst�ndig konfiguriert. Bitte kontaktieren Sie Ihren Administrator.';

?>