<?php
/**
* Modul Translation file 
*
* Language: russian
* Locale:   ru
*
* Copyright (C) Kevin Papst. 
*
* For further information go to http://www.bigace.de/ 
*
* @version $Id: modul.lang.php 77 2011-05-18 13:51:30Z oleg $
* @author $Author: oleg $ 
* @package bigace.translation
*/

$LANG['name']    		= 'Фотогалерея';
$LANG['title']    		= 'Простая фотогалерея';
$LANG['description']  	= 'Скрипт для отображения простой фотогалереи. Создает список из изображений объединенных в одну категорию.';

?>