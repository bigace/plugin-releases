<?php
/**
 * FOTOGALLERY
 *
 * The Fotoalbum displays all Images of a choosen Category in a List.
 * The List displays a resized version of the original Image and on click,
 * opens a Javascript wdget with the full size version.
 *
 * Copyright (C) Kevin Papst
 *
 * For further information go to http://www.bigace.de/
 *
 * @version $Id: modul.php,v 1.11 2006/11/26 21:58:52 kpapst Exp $
 * @author Kevin Papst 
 * @package bigace.modul
 */

loadClass('image', 'ImageService');
loadClass('image', 'Image');
loadClass('category', 'Category');
loadClass('category', 'CategoryService');
loadClass('item', 'ItemProjectService');

define('LIGHTBOX_WEB', $GLOBALS['_BIGACE']['DIR']['public'].'modul/fotogallery/');

define('GALLERY_PROJECT_NUM_CATEGORY', 'fotogallery_image_category');
define('GALLERY_PROJECT_NUM_DESCRIPTION', 'fotogallery_show_description');
define('GALLERY_PROJECT_NUM_THUMB', 'fotogallery_thumb_height_px');

$modul          = new Modul($MENU->getModulID());
$CAT_SERVICE    = new CategoryService();
$IMG_SERVICE    = new ImageService();
$projectService = new ItemProjectService(_BIGACE_ITEM_MENU);

/* #########################################################################
 * ############################  Show Admin Link  ##########################
 * #########################################################################
 */
if ($modul->isModulAdmin())
{

    import('classes.util.links.ModulAdminLink');
    import('classes.util.LinkHelper');
    $mdl = new ModulAdminLink();
    $mdl->setItemID($MENU->getID());
    $mdl->setLanguageID($MENU->getLanguageID());

    ?>
    <script type="text/javascript">
    <!--
    function openAdmin()
    {
        fenster = open("<?php echo LinkHelper::getUrlFromCMSLink($mdl); ?>","ModulAdmin","menubar=no,toolbar=no,statusbar=no,directories=no,location=no,scrollbars=yes,resizable=no,height=350,width=400,screenX=0,screenY=0");
        bBreite=screen.width;
        bHoehe=screen.height;
        fenster.moveTo((bBreite-400)/2,(bHoehe-350)/2);
    }
    // -->
    </script>
    <?php

    echo '<div align="left"><a onClick="openAdmin(); return false;" href="'.LinkHelper::getUrlFromCMSLink($mdl).'"><img src="'.$GLOBALS['_BIGACE']['DIR']['public'].'system/images/preferences.gif" border="0" align="top"> '.getTranslation('gallery_admin').'</a></div>';
}


/* #########################################################################
 * ##################  Show List of all categorized Images  ################
 * #########################################################################
 */
if(!$projectService->existsProjectNum($MENU->getID(), $MENU->getLanguageID(), GALLERY_PROJECT_NUM_CATEGORY))
{
    echo '<br><b>'.getTranslation('gallery_unconfigured').'</b><br>';
}
else
{
    // Get configured height of thumbnails
    if($projectService->existsProjectNum($MENU->getID(), $MENU->getLanguageID(), GALLERY_PROJECT_NUM_THUMB))
        $thumbHeight = $projectService->getProjectNum($MENU->getID(), $MENU->getLanguageID(), GALLERY_PROJECT_NUM_THUMB);
    else
        $thumbHeight = 100;

    if($thumbHeight == 0)
        $thumbHeight = 100;

    // show description of images?
    if($projectService->existsProjectNum($MENU->getID(), $MENU->getLanguageID(), GALLERY_PROJECT_NUM_DESCRIPTION))
        $showDesc = $projectService->getProjectNum($MENU->getID(), $MENU->getLanguageID(), GALLERY_PROJECT_NUM_DESCRIPTION);
    else
        $showDesc = FALSE;

    // get image category
    $CUR_CAT = $projectService->getProjectNum($MENU->getID(), $MENU->getLanguageID(), GALLERY_PROJECT_NUM_CATEGORY);

    // ... and now fetch all linked images
    $search = $CAT_SERVICE->getItemsForCategory($IMG_SERVICE->getItemtype(), $CUR_CAT);

    ?>
    <link rel="stylesheet" href="<?php echo LIGHTBOX_WEB; ?>lightbox.css" type="text/css" media="screen">
    <style type="text/css" media="screen">
    #overlay{ background-image: url(<?php echo LIGHTBOX_WEB; ?>overlay.png); }

    * html #overlay{
        background-color: #333;
        back\ground-color: transparent;
        background-image: url(blank.gif);
        filter: progid:DXImageTransform.Microsoft.AlphaImageLoader(src="<?php echo LIGHTBOX_WEB; ?>overlay.png", sizingMethod="scale");
        }
    </style>

    <script type="text/javascript">
    <!--
    var loadingImage = '<?php echo LIGHTBOX_WEB; ?>loading.gif';
    var closeButton = '<?php echo LIGHTBOX_WEB; ?>close.gif';
    // -->
    </script>
    <script type="text/javascript" src="<?php echo LIGHTBOX_WEB; ?>lightbox.js"></script>

    <p><?php echo $MENU->getContent(); ?></p>
    <?php

    if($search->count() > 0)
    {
        echo '<div class="section clearfix">';
        while ($search->hasNext())
        {
            $temp = $search->next();
            $temp_image = $IMG_SERVICE->getClass($temp['itemid']);
            $imgLink = createCommandLink('image', $temp_image->getID(), array(), $temp_image->getOriginalName());
            ?>
            <div class="thumbnail">
                <a href="<?php echo $imgLink; ?>" rel="lightbox" title="<?php echo $temp_image->getName(); ?>"><img src="<?php echo createCommandLink('image', $temp_image->getID(), array('resizeHeight' => $thumbHeight), $temp_image->getOriginalName()); ?>" alt="<?php echo $temp_image->getName(); ?>" height="<?php echo $thumbHeight; ?>"></a>
                <div class="caption">
                    <a href="<?php echo $imgLink; ?>" rel="lightbox" class="thumnailLink" title="<?php echo $temp_image->getName(); ?>"><?php echo $temp_image->getName(); ?></a>
                    <?php
                    if($showDesc)
                    {
                        echo '<br>';
                        echo $temp_image->getDescription();
                    }
                    ?>
                </div>
            </div>
            <?php
        }
        echo '</div>';
    }
    else
    {
        echo '<b>'.getTranslation('gallery_empty').'</b>';
    }
}

?>