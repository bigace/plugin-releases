INSERT INTO {DB_PREFIX}frights (cid,name,defaultvalue,description) VALUES 
({CID}, 'fotogallery_admin', 'N', 'Allow User to administrate the Foto Gallery settings.');

update {DB_PREFIX}item_project_num a, {DB_PREFIX}item_1 b set a.project_key = 'fotogallery_image_category'
where b.text_3='fotogallery' and a.id=b.id and a.language = b.language and a.cid = b.cid and a.project_key = '1';
